/**
 * Formatting utilities for Brazilian real estate portal
 */

export function formatCurrency(value: number): string {
  return new Intl.NumberFormat('pt-BR', {
    style: 'currency',
    currency: 'BRL',
    maximumFractionDigits: 0
  }).format(value);
}

export function formatArea(area: number): string {
  return `${area.toLocaleString('pt-BR')} m²`;
}

export function generateWhatsAppLink(
  propertyTitle?: string,
  propertyCode?: string,
  price?: number,
  purpose?: string
): string {
  const phone = '5535997435840';
  let message = 'Olá, JHS Imobiliária! Gostaria de falar com um corretor.';

  if (propertyTitle && propertyCode) {
    const formattedPrice = price ? ` (${purpose === 'locacao' ? 'Aluguel' : 'Valor'}: ${formatCurrency(price)})` : '';
    message = `Olá, JHS Imobiliária! Gostaria de mais informações sobre o imóvel: "${propertyTitle}" (Código: ${propertyCode})${formattedPrice}.`;
  }

  return `https://wa.me/${phone}?text=${encodeURIComponent(message)}`;
}

export function generateDirectCallLink(): string {
  return 'tel:+5535997435840';
}
