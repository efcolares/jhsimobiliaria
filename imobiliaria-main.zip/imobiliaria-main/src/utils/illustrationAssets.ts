/**
 * High-fidelity vector illustrations and visual assets matching
 * JHS Corretor de Imóveis visual reference.
 */

// 1. HERO BACKGROUND: Twilight waterfront city skyline with glowing street lamp
export const HERO_WATERFRONT_ILLUSTRATION = `data:image/svg+xml;charset=utf-8,${encodeURIComponent(`
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1920 800" width="100%" height="100%" preserveAspectRatio="xMidYMid slice">
  <defs>
    <!-- Sky Twilight Gradient -->
    <linearGradient id="twilightSky" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" stop-color="#04101e" />
      <stop offset="35%" stop-color="#081e36" />
      <stop offset="65%" stop-color="#0e2c4d" />
      <stop offset="85%" stop-color="#183652" />
      <stop offset="95%" stop-color="#2a3d4f" />
      <stop offset="100%" stop-color="#253545" />
    </linearGradient>

    <!-- Sunset Horizon Glow -->
    <linearGradient id="horizonGlow" x1="0%" y1="100%" x2="0%" y2="0%">
      <stop offset="0%" stop-color="#e07a22" stop-opacity="0.6" />
      <stop offset="25%" stop-color="#d97706" stop-opacity="0.35" />
      <stop offset="60%" stop-color="#b45309" stop-opacity="0.1" />
      <stop offset="100%" stop-color="#04101e" stop-opacity="0" />
    </linearGradient>

    <!-- Water Surface Gradient -->
    <linearGradient id="waterSurface" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" stop-color="#102538" />
      <stop offset="30%" stop-color="#0a1a2b" />
      <stop offset="70%" stop-color="#061320" />
      <stop offset="100%" stop-color="#030b14" />
    </linearGradient>

    <!-- Water Reflection Light -->
    <linearGradient id="waterRipples" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" stop-color="#f59e0b" stop-opacity="0.45" />
      <stop offset="40%" stop-color="#d97706" stop-opacity="0.25" />
      <stop offset="100%" stop-color="#0284c7" stop-opacity="0.05" />
    </linearGradient>

    <!-- Lamp Bulb Glow Filter -->
    <filter id="lampGlow" x="-50%" y="-50%" width="200%" height="200%">
      <feGaussianBlur in="SourceGraphic" stdDeviation="16" result="blur1" />
      <feGaussianBlur in="SourceGraphic" stdDeviation="30" result="blur2" />
      <feMerge>
        <feMergeNode in="blur2" />
        <feMergeNode in="blur1" />
        <feMergeNode in="SourceGraphic" />
      </feMerge>
    </filter>

    <radialGradient id="lampHalo" cx="50%" cy="50%" r="50%">
      <stop offset="0%" stop-color="#fffbeb" stop-opacity="1" />
      <stop offset="20%" stop-color="#fef08a" stop-opacity="0.9" />
      <stop offset="45%" stop-color="#f59e0b" stop-opacity="0.6" />
      <stop offset="75%" stop-color="#d97706" stop-opacity="0.2" />
      <stop offset="100%" stop-color="#b45309" stop-opacity="0" />
    </radialGradient>
  </defs>

  <!-- Sky Canvas -->
  <rect width="100%" height="520" fill="url(#twilightSky)" />
  <rect y="300" width="100%" height="220" fill="url(#horizonGlow)" />

  <!-- Stars in Upper Sky -->
  <g fill="#ffffff" opacity="0.6">
    <circle cx="120" cy="45" r="1.5" />
    <circle cx="280" cy="80" r="1" />
    <circle cx="450" cy="30" r="1.8" />
    <circle cx="620" cy="70" r="1.2" />
    <circle cx="780" cy="40" r="1.4" />
    <circle cx="950" cy="90" r="1.1" />
    <circle cx="1120" cy="35" r="1.6" />
    <circle cx="1340" cy="65" r="1.3" />
    <circle cx="1520" cy="25" r="1.5" />
    <circle cx="1780" cy="85" r="1.2" />
    <circle cx="340" cy="130" r="1.2" />
    <circle cx="890" cy="120" r="1.4" />
    <circle cx="1680" cy="140" r="1.3" />
  </g>

  <!-- Distant Mountain Ridge -->
  <path d="M 0 490 Q 200 450 450 475 T 900 460 T 1350 470 T 1700 455 T 1920 480 L 1920 520 L 0 520 Z" fill="#071728" opacity="0.8" />
  <path d="M 0 500 Q 300 470 650 490 T 1200 480 T 1650 485 T 1920 495 L 1920 520 L 0 520 Z" fill="#0b2034" />

  <!-- Radio/TV antenna tower on mountain -->
  <line x1="1150" y1="460" x2="1150" y2="400" stroke="#f59e0b" stroke-width="1.5" opacity="0.7" />
  <line x1="1145" y1="440" x2="1155" y2="440" stroke="#f59e0b" stroke-width="1" opacity="0.7" />
  <line x1="1147" y1="420" x2="1153" y2="420" stroke="#f59e0b" stroke-width="1" opacity="0.7" />
  <circle cx="1150" cy="398" r="2.5" fill="#ef4444" />

  <!-- Distant City Skyline Across the Water -->
  <g fill="#061625">
    <rect x="50" y="470" width="30" height="45" />
    <rect x="90" y="460" width="45" height="55" />
    <rect x="145" y="475" width="25" height="40" />
    <rect x="180" y="450" width="50" height="65" />
    <polygon points="180,450 205,430 230,450" />
    <rect x="240" y="465" width="35" height="50" />
    <rect x="300" y="475" width="40" height="40" />
    <rect x="360" y="455" width="60" height="60" />
    <rect x="430" y="465" width="45" height="50" />
    <rect x="490" y="445" width="50" height="70" />
    <rect x="550" y="470" width="35" height="45" />
    <rect x="600" y="450" width="70" height="65" />
    <rect x="680" y="465" width="40" height="50" />
    <rect x="730" y="440" width="65" height="75" />
    <polygon points="730,440 762,420 795,440" />
    <rect x="810" y="460" width="55" height="55" />
    <rect x="880" y="450" width="45" height="65" />
    <rect x="940" y="465" width="60" height="50" />
    <rect x="1010" y="455" width="50" height="60" />
    <rect x="1070" y="440" width="70" height="75" />
    <rect x="1150" y="460" width="45" height="55" />
    <rect x="1210" y="450" width="55" height="65" />
    <rect x="1280" y="465" width="50" height="50" />
    <rect x="1340" y="445" width="65" height="70" />
    <rect x="1420" y="460" width="40" height="55" />
    <rect x="1470" y="450" width="60" height="65" />
    <rect x="1540" y="465" width="55" height="50" />
    <rect x="1610" y="455" width="45" height="60" />
    <rect x="1670" y="465" width="60" height="50" />
    <rect x="1740" y="450" width="50" height="65" />
    <rect x="1800" y="460" width="65" height="55" />
  </g>

  <!-- Glowing City Window Lights (Warm Yellow, Amber, Orange, Cyan) -->
  <g fill="#fde047" opacity="0.85">
    <circle cx="105" cy="475" r="1.5" /><circle cx="120" cy="485" r="1.5" /><circle cx="105" cy="495" r="1.5" />
    <circle cx="195" cy="465" r="1.8" /><circle cx="215" cy="475" r="1.8" /><circle cx="195" cy="490" r="1.8" />
    <circle cx="380" cy="470" r="1.8" /><circle cx="400" cy="485" r="1.8" /><circle cx="380" cy="500" r="1.8" />
    <circle cx="510" cy="460" r="2" /><circle cx="525" cy="475" r="2" /><circle cx="510" cy="495" r="2" />
    <circle cx="630" cy="465" r="1.8" /><circle cx="650" cy="480" r="1.8" /><circle cx="630" cy="495" r="1.8" />
    <circle cx="750" cy="455" r="2" /><circle cx="770" cy="470" r="2" /><circle cx="750" cy="490" r="2" />
    <circle cx="900" cy="465" r="1.8" /><circle cx="915" cy="485" r="1.8" />
    <circle cx="1030" cy="470" r="2" /><circle cx="1045" cy="490" r="2" />
    <circle cx="1100" cy="455" r="2" /><circle cx="1120" cy="475" r="2" /><circle cx="1100" cy="495" r="2" />
    <circle cx="1230" cy="465" r="1.8" /><circle cx="1245" cy="485" r="1.8" />
    <circle cx="1360" cy="460" r="2" /><circle cx="1380" cy="480" r="2" />
    <circle cx="1490" cy="465" r="1.8" /><circle cx="1510" cy="485" r="1.8" />
    <circle cx="1630" cy="470" r="1.8" />
    <circle cx="1760" cy="465" r="1.8" /><circle cx="1775" cy="485" r="1.8" />
  </g>

  <!-- Glowing Waterfront Street Light Line -->
  <path d="M 0 514 L 1920 514" stroke="#f59e0b" stroke-width="2" opacity="0.6" />
  <g fill="#fbbf24" opacity="0.9">
    <circle cx="70" cy="514" r="2.5" /><circle cx="130" cy="514" r="2.5" /><circle cx="210" cy="514" r="2.5" />
    <circle cx="290" cy="514" r="2.5" /><circle cx="370" cy="514" r="2.5" /><circle cx="450" cy="514" r="2.5" />
    <circle cx="530" cy="514" r="2.5" /><circle cx="610" cy="514" r="2.5" /><circle cx="690" cy="514" r="2.5" />
    <circle cx="770" cy="514" r="2.5" /><circle cx="850" cy="514" r="2.5" /><circle cx="930" cy="514" r="2.5" />
    <circle cx="1010" cy="514" r="2.5" /><circle cx="1090" cy="514" r="2.5" /><circle cx="1170" cy="514" r="2.5" />
    <circle cx="1250" cy="514" r="2.5" /><circle cx="1330" cy="514" r="2.5" /><circle cx="1410" cy="514" r="2.5" />
    <circle cx="1490" cy="514" r="2.5" /><circle cx="1570" cy="514" r="2.5" /><circle cx="1650" cy="514" r="2.5" />
    <circle cx="1730" cy="514" r="2.5" /><circle cx="1810" cy="514" r="2.5" /><circle cx="1890" cy="514" r="2.5" />
  </g>

  <!-- Water Body in Foreground -->
  <rect y="515" width="100%" height="285" fill="url(#waterSurface)" />

  <!-- City Lights Reflections on Water -->
  <g fill="none" stroke="url(#waterRipples)" stroke-linecap="round">
    <ellipse cx="210" cy="540" rx="35" ry="3" stroke-width="2" />
    <ellipse cx="370" cy="550" rx="45" ry="3.5" stroke-width="2.5" />
    <ellipse cx="530" cy="560" rx="55" ry="4" stroke-width="3" />
    <ellipse cx="770" cy="570" rx="70" ry="4.5" stroke-width="3.5" />
    <ellipse cx="1090" cy="580" rx="65" ry="4" stroke-width="3" />
    <ellipse cx="1330" cy="590" rx="60" ry="4" stroke-width="3" />
    <ellipse cx="1570" cy="600" rx="50" ry="3.5" stroke-width="2.5" />
    <ellipse cx="1730" cy="610" rx="40" ry="3" stroke-width="2" />

    <ellipse cx="300" cy="630" rx="65" ry="4.5" stroke-width="2" />
    <ellipse cx="650" cy="645" rx="90" ry="5.5" stroke-width="3" />
    <ellipse cx="980" cy="660" rx="110" ry="6" stroke-width="3" />
    <ellipse cx="1400" cy="670" rx="95" ry="5.5" stroke-width="2.5" />

    <ellipse cx="550" cy="720" rx="120" ry="7" stroke-width="3" />
    <ellipse cx="1100" cy="735" rx="140" ry="8" stroke-width="3" />
  </g>

  <!-- Foreground Waterfront Embankment Promenade (Right Side) -->
  <path d="M 1520 800 L 1650 550 L 1920 550 L 1920 800 Z" fill="#081827" />
  <line x1="1650" y1="550" x2="1920" y2="550" stroke="#1e293b" stroke-width="4" />
  <!-- Promenade Railing Balustrade -->
  <line x1="1650" y1="520" x2="1920" y2="520" stroke="#334155" stroke-width="3" />
  <line x1="1670" y1="520" x2="1670" y2="550" stroke="#334155" stroke-width="2" />
  <line x1="1720" y1="520" x2="1720" y2="550" stroke="#334155" stroke-width="2" />
  <line x1="1770" y1="520" x2="1770" y2="550" stroke="#334155" stroke-width="2" />
  <line x1="1820" y1="520" x2="1820" y2="550" stroke="#334155" stroke-width="2" />
  <line x1="1870" y1="520" x2="1870" y2="550" stroke="#334155" stroke-width="2" />

  <!-- Prominent Vintage Wrought-Iron Street Lamp in Right Foreground -->
  <g transform="translate(1820, 180)">
    <!-- Cast Iron Base & Tall Fluted Column -->
    <rect x="-8" y="100" width="16" height="420" fill="#0f172a" stroke="#1e293b" stroke-width="1.5" />
    <rect x="-14" y="500" width="28" height="25" rx="3" fill="#0f172a" />
    <rect x="-18" y="520" width="36" height="15" rx="2" fill="#0f172a" />
    <!-- Decorative Ring Collars on Pole -->
    <rect x="-12" y="240" width="24" height="8" rx="2" fill="#1e293b" />
    <rect x="-12" y="380" width="24" height="8" rx="2" fill="#1e293b" />

    <!-- Ornate Scrollwork Bracket Under Lamp -->
    <path d="M -8 115 C -25 105 -35 85 -20 65 C -10 50 0 55 0 50" fill="none" stroke="#1e293b" stroke-width="4" />
    <path d="M 8 115 C 25 105 35 85 20 65 C 10 50 0 55 0 50" fill="none" stroke="#1e293b" stroke-width="4" />

    <!-- Lamp Housing Head -->
    <polygon points="-28,50 28,50 35,-15 -35,-15" fill="#020617" stroke="#334155" stroke-width="2" />
    <!-- Glass Pane Backdrop -->
    <polygon points="-24,46 24,46 31,-12 -31,-12" fill="#fef08a" opacity="0.9" />

    <!-- Glowing Bulb & Aura Flare -->
    <circle cx="0" cy="15" r="75" fill="url(#lampHalo)" filter="url(#lampGlow)" />
    <ellipse cx="0" cy="15" rx="14" ry="20" fill="#ffffff" filter="url(#lampGlow)" />

    <!-- Glass Pane Framing Bars -->
    <line x1="0" y1="-15" x2="0" y2="50" stroke="#0f172a" stroke-width="3" />
    <line x1="-31" y1="-12" x2="-24" y2="46" stroke="#0f172a" stroke-width="3" />
    <line x1="31" y1="-12" x2="24" y2="46" stroke="#0f172a" stroke-width="3" />

    <!-- Ornate Lantern Roof Cap & Finial -->
    <polygon points="-38,-15 38,-15 0,-60" fill="#09101d" stroke="#334155" stroke-width="2" />
    <circle cx="0" cy="-65" r="7" fill="#f59e0b" />
    <polygon points="-3,-72 3,-72 0,-85" fill="#f59e0b" />
  </g>
</svg>
`)}`;

// 2. CARD 1: CASA NO CENTRO (Charming home with lawn, sidewalk, blue sky & clouds)
export const CASA_NO_CENTRO_ILLUSTRATION = `data:image/svg+xml;charset=utf-8,${encodeURIComponent(`
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 800 550" width="100%" height="100%">
  <defs>
    <linearGradient id="skyGrad1" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" stop-color="#38bdf8" />
      <stop offset="50%" stop-color="#7dd3fc" />
      <stop offset="100%" stop-color="#bae6fd" />
    </linearGradient>
    <linearGradient id="wallGrad1" x1="0%" y1="0%" x2="100%" y2="0%">
      <stop offset="0%" stop-color="#fdfbf7" />
      <stop offset="60%" stop-color="#f5efe6" />
      <stop offset="100%" stop-color="#e7ded0" />
    </linearGradient>
    <linearGradient id="roofGrad1" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" stop-color="#991b1b" />
      <stop offset="60%" stop-color="#b91c1c" />
      <stop offset="100%" stop-color="#7f1d1d" />
    </linearGradient>
    <linearGradient id="grassGrad1" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" stop-color="#4ade80" />
      <stop offset="40%" stop-color="#22c55e" />
      <stop offset="100%" stop-color="#15803d" />
    </linearGradient>
    <linearGradient id="glassReflect" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#0284c7" />
      <stop offset="50%" stop-color="#38bdf8" />
      <stop offset="100%" stop-color="#e0f2fe" />
    </linearGradient>
  </defs>

  <!-- Sky -->
  <rect width="100%" height="340" fill="url(#skyGrad1)" />

  <!-- Clouds -->
  <g fill="#ffffff" opacity="0.85">
    <ellipse cx="140" cy="90" rx="60" ry="25" />
    <ellipse cx="170" cy="75" rx="45" ry="30" />
    <ellipse cx="200" cy="90" rx="55" ry="22" />

    <ellipse cx="620" cy="80" rx="70" ry="28" />
    <ellipse cx="660" cy="65" rx="50" ry="32" />
    <ellipse cx="700" cy="80" rx="60" ry="24" />
  </g>

  <!-- Distant Trees & Greenery -->
  <g fill="#166534">
    <circle cx="60" cy="320" r="50" />
    <circle cx="110" cy="300" r="60" />
    <circle cx="160" cy="315" r="45" />
    <circle cx="680" cy="315" r="55" />
    <circle cx="730" cy="300" r="65" />
    <circle cx="780" cy="320" r="50" />
  </g>

  <!-- Main House Structure -->
  <!-- Left Wing -->
  <rect x="180" y="240" width="180" height="150" fill="url(#wallGrad1)" stroke="#d6cbb8" stroke-width="1.5" />
  <polygon points="170,240 270,160 370,240" fill="url(#roofGrad1)" stroke="#5f1313" stroke-width="2" />
  
  <!-- Main Center & Right Wing -->
  <rect x="350" y="210" width="280" height="180" fill="url(#wallGrad1)" stroke="#d6cbb8" stroke-width="1.5" />
  <polygon points="340,210 490,130 640,210" fill="url(#roofGrad1)" stroke="#5f1313" stroke-width="2" />

  <!-- Stone Accent Facade on Entrance -->
  <rect x="330" y="250" width="60" height="140" fill="#a8a29e" />
  <line x1="330" y1="280" x2="390" y2="280" stroke="#78716c" />
  <line x1="330" y1="310" x2="390" y2="310" stroke="#78716c" />
  <line x1="330" y1="340" x2="390" y2="340" stroke="#78716c" />
  <line x1="330" y1="370" x2="390" y2="370" stroke="#78716c" />

  <!-- Front Door -->
  <rect x="340" y="280" width="40" height="105" rx="3" fill="#78350f" stroke="#451a03" stroke-width="2" />
  <circle cx="348" cy="335" r="3" fill="#fbbf24" />

  <!-- Garage Door on Left -->
  <rect x="200" y="280" width="120" height="105" rx="2" fill="#f8fafc" stroke="#94a3b8" stroke-width="2" />
  <line x1="200" y1="305" x2="320" y2="305" stroke="#cbd5e1" stroke-width="1.5" />
  <line x1="200" y1="330" x2="320" y2="330" stroke="#cbd5e1" stroke-width="1.5" />
  <line x1="200" y1="355" x2="320" y2="355" stroke="#cbd5e1" stroke-width="1.5" />

  <!-- Modern Windows with Reflective Glass -->
  <!-- Upper Right Window -->
  <rect x="420" y="240" width="90" height="60" rx="3" fill="url(#glassReflect)" stroke="#1e293b" stroke-width="3" />
  <line x1="465" y1="240" x2="465" y2="300" stroke="#1e293b" stroke-width="2" />

  <!-- Large Picture Window -->
  <rect x="535" y="240" width="75" height="90" rx="3" fill="url(#glassReflect)" stroke="#1e293b" stroke-width="3" />
  <line x1="572" y1="240" x2="572" y2="330" stroke="#1e293b" stroke-width="2" />

  <!-- Attic Round Window -->
  <circle cx="490" cy="180" r="16" fill="url(#glassReflect)" stroke="#1e293b" stroke-width="2" />
  <line x1="490" y1="164" x2="490" y2="196" stroke="#1e293b" stroke-width="1.5" />
  <line x1="474" y1="180" x2="506" y2="180" stroke="#1e293b" stroke-width="1.5" />

  <!-- Front Garden Grass -->
  <rect y="380" width="100%" height="170" fill="url(#grassGrad1)" />

  <!-- Paved Front Walkway to Door & Driveway -->
  <polygon points="180,390 340,390 320,550 120,550" fill="#e2e8f0" stroke="#cbd5e1" stroke-width="1.5" />
  <polygon points="340,390 380,390 400,550 360,550" fill="#cbd5e1" stroke="#94a3b8" stroke-width="1" />

  <!-- Garden Shrubs & Flowers -->
  <g fill="#15803d">
    <ellipse cx="430" cy="385" rx="30" ry="18" />
    <ellipse cx="480" cy="385" rx="25" ry="15" />
    <ellipse cx="530" cy="385" rx="32" ry="18" />
    <ellipse cx="590" cy="385" rx="28" ry="16" />
  </g>
  <circle cx="430" cy="375" r="4" fill="#f43f5e" />
  <circle cx="480" cy="378" r="4" fill="#fbbf24" />
  <circle cx="530" cy="374" r="4" fill="#f43f5e" />
  <circle cx="590" cy="377" r="4" fill="#fbbf24" />

  <!-- Sidewalk & Street in Foreground -->
  <rect y="500" width="100%" height="50" fill="#64748b" />
  <line x1="0" y1="500" x2="800" y2="500" stroke="#94a3b8" stroke-width="4" />
</svg>
`)}`;

// 3. CARD 2: APARTAMENTO (Contemporary Multi-Story Apartment Building)
export const APARTAMENTO_ILLUSTRATION = `data:image/svg+xml;charset=utf-8,${encodeURIComponent(`
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 800 550" width="100%" height="100%">
  <defs>
    <linearGradient id="skyGrad2" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" stop-color="#0284c7" />
      <stop offset="45%" stop-color="#38bdf8" />
      <stop offset="100%" stop-color="#bae6fd" />
    </linearGradient>
    <linearGradient id="buildingGrad" x1="0%" y1="0%" x2="100%" y2="0%">
      <stop offset="0%" stop-color="#f8fafc" />
      <stop offset="50%" stop-color="#f1f5f9" />
      <stop offset="100%" stop-color="#e2e8f0" />
    </linearGradient>
    <linearGradient id="balconyGlass" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" stop-color="#38bdf8" stop-opacity="0.8" />
      <stop offset="100%" stop-color="#0284c7" stop-opacity="0.9" />
    </linearGradient>
  </defs>

  <!-- Sky Canvas -->
  <rect width="100%" height="550" fill="url(#skyGrad2)" />

  <!-- Clouds -->
  <g fill="#ffffff" opacity="0.9">
    <ellipse cx="200" cy="80" rx="80" ry="30" />
    <ellipse cx="250" cy="65" rx="60" ry="35" />
    <ellipse cx="650" cy="110" rx="70" ry="25" />
  </g>

  <!-- Neighboring Buildings Outline -->
  <rect x="60" y="240" width="140" height="270" fill="#94a3b8" opacity="0.7" />
  <rect x="600" y="200" width="150" height="310" fill="#94a3b8" opacity="0.7" />

  <!-- Main Luxury Residential Tower -->
  <rect x="220" y="60" width="360" height="450" fill="url(#buildingGrad)" stroke="#cbd5e1" stroke-width="2" />

  <!-- Top Roof Pergola / Terrace -->
  <rect x="235" y="45" width="330" height="15" fill="#334155" />
  <rect x="260" y="30" width="80" height="15" fill="#475569" />

  <!-- Architectural Vertical Accent Columns (Warm Bronze/Wood Look) -->
  <rect x="230" y="60" width="18" height="450" fill="#c2410c" />
  <rect x="552" y="60" width="18" height="450" fill="#c2410c" />

  <!-- Balconies Floor 5 -->
  <rect x="270" y="90" width="120" height="55" fill="#f8fafc" stroke="#cbd5e1" />
  <rect x="270" y="115" width="120" height="30" fill="url(#balconyGlass)" rx="2" />
  <rect x="410" y="90" width="120" height="55" fill="#f8fafc" stroke="#cbd5e1" />
  <rect x="410" y="115" width="120" height="30" fill="url(#balconyGlass)" rx="2" />

  <!-- Balconies Floor 4 -->
  <rect x="270" y="165" width="120" height="55" fill="#f8fafc" stroke="#cbd5e1" />
  <rect x="270" y="190" width="120" height="30" fill="url(#balconyGlass)" rx="2" />
  <rect x="410" y="165" width="120" height="55" fill="#f8fafc" stroke="#cbd5e1" />
  <rect x="410" y="190" width="120" height="30" fill="url(#balconyGlass)" rx="2" />

  <!-- Balconies Floor 3 -->
  <rect x="270" y="240" width="120" height="55" fill="#f8fafc" stroke="#cbd5e1" />
  <rect x="270" y="265" width="120" height="30" fill="url(#balconyGlass)" rx="2" />
  <rect x="410" y="240" width="120" height="55" fill="#f8fafc" stroke="#cbd5e1" />
  <rect x="410" y="265" width="120" height="30" fill="url(#balconyGlass)" rx="2" />

  <!-- Balconies Floor 2 -->
  <rect x="270" y="315" width="120" height="55" fill="#f8fafc" stroke="#cbd5e1" />
  <rect x="270" y="340" width="120" height="30" fill="url(#balconyGlass)" rx="2" />
  <rect x="410" y="315" width="120" height="55" fill="#f8fafc" stroke="#cbd5e1" />
  <rect x="410" y="340" width="120" height="30" fill="url(#balconyGlass)" rx="2" />

  <!-- Balconies Floor 1 -->
  <rect x="270" y="390" width="120" height="55" fill="#f8fafc" stroke="#cbd5e1" />
  <rect x="270" y="415" width="120" height="30" fill="url(#balconyGlass)" rx="2" />
  <rect x="410" y="390" width="120" height="55" fill="#f8fafc" stroke="#cbd5e1" />
  <rect x="410" y="415" width="120" height="30" fill="url(#balconyGlass)" rx="2" />

  <!-- Ground Floor Entrance Lobby & Glass Gate -->
  <rect x="220" y="460" width="360" height="50" fill="#0f172a" />
  <rect x="350" y="465" width="100" height="45" fill="#38bdf8" opacity="0.6" stroke="#ffffff" stroke-width="1.5" />

  <!-- Landscaping, Palms & Trees -->
  <g fill="#15803d">
    <ellipse cx="140" cy="480" rx="35" ry="30" />
    <ellipse cx="200" cy="470" rx="40" ry="35" />
    <ellipse cx="610" cy="470" rx="45" ry="38" />
    <ellipse cx="670" cy="480" rx="35" ry="28" />
  </g>

  <!-- Pavement Base -->
  <rect y="500" width="100%" height="50" fill="#475569" />
  <line x1="0" y1="500" x2="800" y2="500" stroke="#94a3b8" stroke-width="4" />
</svg>
`)}`;

// 4. CARD 3: CASA DE TEMPORADA (Vacation Home with Swimming Pool & Deck)
export const CASA_TEMPORADA_ILLUSTRATION = `data:image/svg+xml;charset=utf-8,${encodeURIComponent(`
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 800 550" width="100%" height="100%">
  <defs>
    <linearGradient id="skyGrad3" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" stop-color="#0284c7" />
      <stop offset="60%" stop-color="#7dd3fc" />
      <stop offset="100%" stop-color="#bae6fd" />
    </linearGradient>
    <linearGradient id="poolWater" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" stop-color="#06b6d4" />
      <stop offset="35%" stop-color="#0891b2" />
      <stop offset="70%" stop-color="#0e7490" />
      <stop offset="100%" stop-color="#155e75" />
    </linearGradient>
    <linearGradient id="deckWood" x1="0%" y1="0%" x2="100%" y2="0%">
      <stop offset="0%" stop-color="#d97706" />
      <stop offset="50%" stop-color="#f59e0b" />
      <stop offset="100%" stop-color="#b45309" />
    </linearGradient>
  </defs>

  <!-- Blue Sunny Sky -->
  <rect width="100%" height="240" fill="url(#skyGrad3)" />

  <!-- Sunny Glow in Sky -->
  <circle cx="700" cy="70" r="45" fill="#fef08a" opacity="0.8" />
  <circle cx="700" cy="70" r="70" fill="#fef08a" opacity="0.3" />

  <!-- Tropical Trees Behind Villa -->
  <g fill="#166534">
    <ellipse cx="120" cy="180" rx="45" ry="50" />
    <ellipse cx="170" cy="165" rx="55" ry="60" />
    <ellipse cx="630" cy="170" rx="50" ry="55" />
    <ellipse cx="680" cy="180" rx="45" ry="45" />
  </g>

  <!-- Modern Luxury Vacation Villa in Background -->
  <rect x="180" y="130" width="440" height="150" fill="#fdfbf7" stroke="#e2e8f0" stroke-width="2" />
  <!-- Overhanging Flat Roof Terrace -->
  <rect x="160" y="115" width="480" height="18" fill="#1e293b" />
  
  <!-- Villa Glass Sliders & Veranda -->
  <rect x="210" y="160" width="130" height="100" fill="#38bdf8" opacity="0.8" stroke="#1e293b" stroke-width="2" />
  <rect x="360" y="160" width="130" height="100" fill="#38bdf8" opacity="0.8" stroke="#1e293b" stroke-width="2" />
  <rect x="510" y="160" width="90" height="100" fill="#38bdf8" opacity="0.8" stroke="#1e293b" stroke-width="2" />

  <!-- Stone Tiled Pool Deck -->
  <rect y="270" width="100%" height="280" fill="#f1f5f9" />
  <line x1="0" y1="310" x2="800" y2="310" stroke="#cbd5e1" stroke-dasharray="10,10" />
  <line x1="0" y1="360" x2="800" y2="360" stroke="#cbd5e1" stroke-dasharray="10,10" />
  <line x1="0" y1="410" x2="800" y2="410" stroke="#cbd5e1" stroke-dasharray="10,10" />

  <!-- Large Sparkling Swimming Pool -->
  <!-- Pool Coping Border -->
  <rect x="140" y="320" width="520" height="200" rx="10" fill="#e2e8f0" stroke="#94a3b8" stroke-width="3" />
  <!-- Blue Pool Water -->
  <rect x="150" y="330" width="500" height="180" rx="6" fill="url(#poolWater)" />

  <!-- Water Reflections & Wave Caustics -->
  <g stroke="#67e8f9" stroke-width="2" fill="none" opacity="0.75" stroke-linecap="round">
    <path d="M 180 360 Q 220 350 260 360 T 340 360 T 420 360 T 500 360 T 580 360" />
    <path d="M 200 400 Q 240 390 280 400 T 360 400 T 440 400 T 520 400 T 600 400" />
    <path d="M 170 440 Q 210 430 250 440 T 330 440 T 410 440 T 490 440 T 570 440" />
    <path d="M 220 480 Q 260 470 300 480 T 380 480 T 460 480 T 540 480 T 620 480" />
  </g>

  <!-- Pool Steps on Left -->
  <rect x="150" y="330" width="60" height="30" fill="#0891b2" />
  <rect x="150" y="330" width="40" height="20" fill="#06b6d4" />
  <rect x="150" y="330" width="20" height="10" fill="#22d3ee" />

  <!-- Lounge Sunbeds on Deck Side -->
  <g transform="translate(670, 360)">
    <rect x="0" y="0" width="80" height="35" rx="3" fill="#ffffff" stroke="#cbd5e1" stroke-width="2" />
    <polygon points="0,0 20,-20 35,-20 15,0" fill="#ffffff" stroke="#cbd5e1" stroke-width="1.5" />
    <rect x="5" y="5" width="70" height="10" fill="#0284c7" />
  </g>

  <g transform="translate(670, 420)">
    <rect x="0" y="0" width="80" height="35" rx="3" fill="#ffffff" stroke="#cbd5e1" stroke-width="2" />
    <polygon points="0,0 20,-20 35,-20 15,0" fill="#ffffff" stroke="#cbd5e1" stroke-width="1.5" />
    <rect x="5" y="5" width="70" height="10" fill="#0284c7" />
  </g>

  <!-- Patio Sun Umbrella -->
  <circle cx="75" cy="380" r="50" fill="#f59e0b" />
  <polygon points="75,380 50,340 100,340" fill="#fbbf24" />
  <polygon points="75,380 50,420 100,420" fill="#fbbf24" />
</svg>
`)}`;

// 5. CARD 4: TERRENO (Residential Lot with Panoramic Mountain View)
export const TERRENO_ILLUSTRATION = `data:image/svg+xml;charset=utf-8,${encodeURIComponent(`
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 800 550" width="100%" height="100%">
  <defs>
    <linearGradient id="skyGrad4" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" stop-color="#0284c7" />
      <stop offset="40%" stop-color="#38bdf8" />
      <stop offset="80%" stop-color="#7dd3fc" />
      <stop offset="100%" stop-color="#bae6fd" />
    </linearGradient>
    <linearGradient id="mountainFar" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" stop-color="#1e3a8a" />
      <stop offset="100%" stop-color="#3b82f6" />
    </linearGradient>
    <linearGradient id="mountainMid" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" stop-color="#14532d" />
      <stop offset="100%" stop-color="#16a34a" />
    </linearGradient>
    <linearGradient id="grassField" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" stop-color="#84cc16" />
      <stop offset="40%" stop-color="#65a30d" />
      <stop offset="100%" stop-color="#4d7c0f" />
    </linearGradient>
  </defs>

  <!-- Sky -->
  <rect width="100%" height="320" fill="url(#skyGrad4)" />

  <!-- Sun -->
  <circle cx="150" cy="90" r="35" fill="#fde047" opacity="0.9" />

  <!-- Clouds -->
  <g fill="#ffffff" opacity="0.85">
    <ellipse cx="380" cy="110" rx="70" ry="25" />
    <ellipse cx="420" cy="95" rx="55" ry="30" />
    <ellipse cx="460" cy="110" rx="60" ry="22" />
  </g>

  <!-- Distant Blue Mantiqueira Mountains -->
  <path d="M 0 260 Q 150 160 350 220 T 700 170 T 800 230 L 800 340 L 0 340 Z" fill="url(#mountainFar)" opacity="0.65" />

  <!-- Midground Green Hills & Town Silhouette -->
  <path d="M 0 290 Q 200 220 420 270 T 800 240 L 800 360 L 0 360 Z" fill="url(#mountainMid)" />

  <!-- Distant City Houses Dotting the Valley -->
  <g fill="#f8fafc">
    <rect x="220" y="275" width="12" height="10" />
    <rect x="240" y="270" width="15" height="12" />
    <rect x="270" y="278" width="10" height="9" />
    <rect x="340" y="270" width="14" height="12" />
    <rect x="365" y="276" width="16" height="10" />
    <rect x="450" y="265" width="12" height="11" />
    <rect x="470" y="272" width="15" height="13" />
    <rect x="520" y="260" width="14" height="12" />
  </g>

  <!-- Sloping Residential Land Lot (Foreground) -->
  <path d="M 0 340 Q 250 310 500 330 T 800 310 L 800 550 L 0 550 Z" fill="url(#grassField)" />

  <!-- Boundary Survey Marker Stakes & Plot Outline (White/Orange Flags) -->
  <!-- Boundary lines marking the 360m² lot -->
  <polygon points="160,370 640,350 720,510 80,520" fill="rgba(255,255,255,0.12)" stroke="#ffffff" stroke-width="2.5" stroke-dasharray="10,6" />

  <!-- Stake Top Left -->
  <line x1="160" y1="370" x2="160" y2="330" stroke="#ea580c" stroke-width="4" />
  <polygon points="160,330 185,340 160,350" fill="#f97316" />

  <!-- Stake Top Right -->
  <line x1="640" y1="350" x2="640" y2="310" stroke="#ea580c" stroke-width="4" />
  <polygon points="640,310 665,320 640,330" fill="#f97316" />

  <!-- Stake Bottom Left -->
  <line x1="80" y1="520" x2="80" y2="470" stroke="#ea580c" stroke-width="5" />
  <polygon points="80,470 115,485 80,500" fill="#f97316" />

  <!-- Stake Bottom Right -->
  <line x1="720" y1="510" x2="720" y2="460" stroke="#ea580c" stroke-width="5" />
  <polygon points="720,460 755,475 720,490" fill="#f97316" />

  <!-- Lot Dimensions Tag Overlay -->
  <g transform="translate(400, 440)" text-anchor="middle">
    <rect x="-90" y="-24" width="180" height="48" rx="24" fill="#0B2545" stroke="#f59e0b" stroke-width="2" />
    <text x="0" y="6" fill="#fef08a" font-family="'Outfit', sans-serif" font-weight="900" font-size="18" letter-spacing="1">
      ÁREA: 360 m²
    </text>
  </g>
</svg>
`)}`;

// 6. TRADIÇÃO, EXPERIÊNCIA E CREDIBILIDADE: Hands holding keys with wooden house keychain
export const HANDS_KEYS_ILLUSTRATION = `data:image/svg+xml;charset=utf-8,${encodeURIComponent(`
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 800 600" width="100%" height="100%">
  <defs>
    <linearGradient id="warmBg" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#1e293b" />
      <stop offset="50%" stop-color="#0f172a" />
      <stop offset="100%" stop-color="#020617" />
    </linearGradient>
    <radialGradient id="bokeh1" cx="30%" cy="30%" r="50%">
      <stop offset="0%" stop-color="#f59e0b" stop-opacity="0.3" />
      <stop offset="100%" stop-color="#0f172a" stop-opacity="0" />
    </radialGradient>
    <radialGradient id="bokeh2" cx="70%" cy="60%" r="60%">
      <stop offset="0%" stop-color="#38bdf8" stop-opacity="0.25" />
      <stop offset="100%" stop-color="#0f172a" stop-opacity="0" />
    </radialGradient>
    <linearGradient id="goldKey" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#fef08a" />
      <stop offset="40%" stop-color="#fbbf24" />
      <stop offset="80%" stop-color="#d97706" />
      <stop offset="100%" stop-color="#92400e" />
    </linearGradient>
    <linearGradient id="woodKeychain" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#fef3c7" />
      <stop offset="50%" stop-color="#d97706" />
      <stop offset="100%" stop-color="#78350f" />
    </linearGradient>
  </defs>

  <!-- Background with cozy interior bokeh lights -->
  <rect width="100%" height="100%" fill="url(#warmBg)" />
  <circle cx="200" cy="180" r="140" fill="url(#bokeh1)" />
  <circle cx="620" cy="380" r="160" fill="url(#bokeh2)" />
  <circle cx="500" cy="150" r="90" fill="url(#bokeh1)" />

  <!-- Hands Silhouettes in delivery gesture -->
  <!-- Left Hand (Broker giving keys) -->
  <path d="M 0 450 Q 150 420 280 380 Q 340 370 370 390 Q 350 420 280 460 Q 180 500 0 540 Z" fill="#d4a373" stroke="#b07d4b" stroke-width="3" />
  <!-- Cuff Suit Sleeve Navy Blue -->
  <path d="M 0 420 L 120 400 L 90 560 L 0 570 Z" fill="#0B2545" stroke="#1e3a8a" stroke-width="2" />
  <rect x="110" y="400" width="16" height="155" fill="#f8fafc" /> <!-- White shirt cuff -->

  <!-- Right Hand (Client receiving keys) -->
  <path d="M 800 480 Q 650 450 520 400 Q 460 380 430 420 Q 460 460 550 500 Q 680 540 800 560 Z" fill="#e0afa0" stroke="#c48a79" stroke-width="3" />

  <!-- Miniature Wooden House Keychain (Central Focus) -->
  <g transform="translate(400, 310)">
    <!-- House Body -->
    <polygon points="0,-70 55,-25 55,50 -55,50 -55,-25" fill="url(#woodKeychain)" stroke="#451a03" stroke-width="4" />
    <!-- Cutout Door in Keychain -->
    <rect x="-12" y="10" width="24" height="40" rx="3" fill="#451a03" />
    <!-- Cutout Windows in Keychain -->
    <rect x="-35" y="-12" width="16" height="16" rx="2" fill="#451a03" />
    <rect x="19" y="-12" width="16" height="16" rx="2" fill="#451a03" />
    <!-- Keychain Hanging Hole -->
    <circle cx="0" cy="-50" r="6" fill="#1e293b" />
    
    <!-- Metal Ring connecting key and keychain -->
    <circle cx="0" cy="-65" r="18" fill="none" stroke="url(#goldKey)" stroke-width="5" />
    
    <!-- Brass / Golden Key 1 -->
    <g transform="translate(-15, -45) rotate(25)">
      <circle cx="0" cy="0" r="16" fill="none" stroke="url(#goldKey)" stroke-width="5" />
      <rect x="-3" y="16" width="6" height="60" fill="url(#goldKey)" />
      <rect x="3" y="55" width="14" height="6" fill="url(#goldKey)" />
      <rect x="3" y="66" width="10" height="6" fill="url(#goldKey)" />
    </g>

    <!-- Brass / Golden Key 2 -->
    <g transform="translate(15, -45) rotate(-35)">
      <circle cx="0" cy="0" r="16" fill="none" stroke="url(#goldKey)" stroke-width="5" />
      <rect x="-3" y="16" width="6" height="55" fill="url(#goldKey)" />
      <rect x="3" y="50" width="12" height="5" fill="url(#goldKey)" />
      <rect x="3" y="60" width="8" height="5" fill="url(#goldKey)" />
    </g>

    <!-- Warm Golden Light Glow over Key and Lock -->
    <circle cx="0" cy="-10" r="100" fill="url(#bokeh1)" />
  </g>
</svg>
`)}`;
