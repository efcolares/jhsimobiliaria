import React from 'react';
import { AboutSection } from '../components/AboutSection';
import { ShieldCheck, Award, MapPin, Phone, Mail, Clock, MessageCircle, ArrowRight } from 'lucide-react';
import { useProperty } from '../context/PropertyContext';
import { generateWhatsAppLink, generateDirectCallLink } from '../utils/formatters';

export const AboutPage: React.FC = () => {
  const { setCurrentView } = useProperty();

  return (
    <div className="bg-slate-50 min-h-screen">
      {/* Hero Header */}
      <div className="bg-[#0B2545] text-white py-14 px-4 sm:px-6">
        <div className="max-w-4xl mx-auto text-center space-y-4">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/10 text-amber-400 text-xs font-semibold">
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>CRECI-MG 24.891 · Tradição em Itajubá e Região</span>
          </div>
          <h1 className="font-heading text-3xl sm:text-5xl font-extrabold tracking-tight">
            Conheça a JHS Imobiliária
          </h1>
          <p className="text-sm sm:text-base text-slate-300 max-w-2xl mx-auto leading-relaxed">
            Mais que intermediar negócios, assessoramos famílias e investidores com dedicação técnica, conformidade documental e ética inegociável.
          </p>
        </div>
      </div>

      {/* Main About Component */}
      <AboutSection />

      {/* Direct Contact Banner */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 pb-16">
        <div className="bg-white rounded-2xl p-8 border border-slate-200 shadow-sm flex flex-col md:flex-row items-center justify-between gap-6">
          <div>
            <h3 className="font-heading text-xl font-bold text-slate-900">
              Deseja comprar, vender ou alugar em Itajubá?
            </h3>
            <p className="text-xs text-slate-500 mt-1">
              Converse com a nossa equipe especializada e receba consultoria personalizada.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => setCurrentView('search')}
              className="px-5 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold rounded-lg transition-colors"
            >
              Ver Imóveis
            </button>
            <a
              href={generateWhatsAppLink()}
              target="_blank"
              rel="noopener noreferrer"
              className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold rounded-lg transition-colors flex items-center gap-1.5"
            >
              <MessageCircle className="w-4 h-4" />
              <span>Chamar no WhatsApp</span>
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};
