import React from 'react';
import { 
  ArrowRight, 
  ShieldCheck, 
  Handshake, 
  Target, 
  MapPin, 
  MessageCircle,
  Phone
} from 'lucide-react';
import { useProperty } from '../context/PropertyContext';
import { HeroSearch } from '../components/HeroSearch';
import { PropertyCard } from '../components/PropertyCard';
import { generateWhatsAppLink } from '../utils/formatters';
import { HANDS_KEYS_ILLUSTRATION } from '../utils/illustrationAssets';

export const HomePage: React.FC = () => {
  const { properties, setCurrentView } = useProperty();

  // Pick the top 4 featured properties as shown in the reference image
  const featuredOpportunities = properties
    .filter(p => p.status === 'disponivel')
    .slice(0, 4);

  return (
    <div className="bg-slate-50 min-h-screen">
      {/* 1. Hero with Waterfront, Street Lamp, Logo and Search Bar */}
      <HeroSearch />

      {/* 2. Vitrine: IMÓVEIS EM DESTAQUE - Oportunidades imperdíveis */}
      <section className="py-14 sm:py-18 bg-white border-b border-slate-200/80">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          {/* Header Section */}
          <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-8">
            <div className="space-y-1">
              <span className="text-xs sm:text-sm font-black text-[#FF9E2C] tracking-widest uppercase block">
                IMÓVEIS EM DESTAQUE
              </span>
              <h2 className="font-heading text-2xl sm:text-3xl lg:text-4xl font-extrabold text-[#0B2545] tracking-tight">
                Oportunidades imperdíveis
              </h2>
            </div>

            {/* Link to view all properties */}
            <button
              type="button"
              onClick={() => {
                setCurrentView('search');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              className="inline-flex items-center gap-2 px-5 py-2 rounded-full border border-slate-300 hover:border-[#0B2545] hover:bg-slate-50 text-slate-800 text-xs font-bold tracking-wider uppercase transition-colors self-start sm:self-auto cursor-pointer"
            >
              <span>VER TODOS OS IMÓVEIS</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* 4 Cards Grid Row */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {featuredOpportunities.map(property => (
              <PropertyCard key={property.id} property={property} layout="grid" />
            ))}
          </div>
        </div>
      </section>

      {/* 3. Section: Tradição, experiência e credibilidade! */}
      <section id="avaliacoes-section" className="py-14 bg-[#06182C] text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            {/* Left: Keys with Wooden House Keychain Photo */}
            <div className="lg:col-span-4 overflow-hidden rounded-2xl shadow-xl aspect-4/3 lg:aspect-auto lg:h-72 border border-slate-700/50 bg-slate-900">
              <img
                src={HANDS_KEYS_ILLUSTRATION}
                alt="Entrega de chaves JHS Imóveis Itajubá"
                className="w-full h-full object-cover"
                loading="lazy"
              />
            </div>

            {/* Middle: Presentation text & Saiba mais button */}
            <div className="lg:col-span-5 space-y-4 text-left">
              <h3 className="font-heading text-2xl sm:text-3xl font-extrabold text-white leading-tight">
                Tradição, experiência <br /> e credibilidade!
              </h3>
              <p className="text-slate-300 text-xs sm:text-sm leading-relaxed max-w-md">
                A JHS Corretor de Imóveis é referência em Itajubá e região, oferecendo um atendimento personalizado, com foco em seus sonhos e na segurança de cada negócio.
              </p>
              <div className="pt-2">
                <button
                  type="button"
                  onClick={() => {
                    setCurrentView('about');
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  className="inline-flex items-center gap-2 px-6 py-2.5 rounded-full border border-slate-500 hover:border-white text-white text-xs font-bold uppercase tracking-wider transition-all hover:bg-white/10 cursor-pointer"
                >
                  <span>SAIBA MAIS SOBRE NÓS</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            {/* Right: 4 Trust Pillars with circular icons and lines */}
            <div className="lg:col-span-3 space-y-4 border-t lg:border-t-0 lg:border-l border-slate-700/60 pt-6 lg:pt-0 lg:pl-6">
              {/* Pillar 1 */}
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full border border-amber-400/40 text-amber-400 flex items-center justify-center shrink-0">
                  <ShieldCheck className="w-5 h-5" />
                </div>
                <div>
                  <strong className="block text-xs font-bold text-white">Segurança</strong>
                  <span className="text-[11px] text-slate-400">em todas as negociações</span>
                </div>
              </div>

              {/* Pillar 2 */}
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full border border-amber-400/40 text-amber-400 flex items-center justify-center shrink-0">
                  <Handshake className="w-5 h-5" />
                </div>
                <div>
                  <strong className="block text-xs font-bold text-white">Atendimento</strong>
                  <span className="text-[11px] text-slate-400">personalizado</span>
                </div>
              </div>

              {/* Pillar 3 */}
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full border border-amber-400/40 text-amber-400 flex items-center justify-center shrink-0">
                  <Target className="w-5 h-5" />
                </div>
                <div>
                  <strong className="block text-xs font-bold text-white">Avaliações precisas</strong>
                  <span className="text-[11px] text-slate-400">com laudos técnicos</span>
                </div>
              </div>

              {/* Pillar 4 */}
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full border border-amber-400/40 text-amber-400 flex items-center justify-center shrink-0">
                  <MapPin className="w-5 h-5" />
                </div>
                <div>
                  <strong className="block text-xs font-bold text-white">Atuação em Itajubá e região</strong>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 4. Section: Fale agora com a gente! & Brokers Contact Bar */}
      <section id="contato-bar" className="py-8 bg-[#041222] border-t border-[#0d2a4a] text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="flex flex-col lg:flex-row items-center justify-between gap-6">
            {/* Left: WhatsApp Callout */}
            <div className="flex items-center gap-4 text-left">
              <div className="w-14 h-14 rounded-full bg-gradient-to-br from-[#FF8A00] to-[#FF5500] text-white flex items-center justify-center shrink-0 shadow-lg shadow-orange-950/50">
                <MessageCircle className="w-8 h-8 fill-current" />
              </div>
              <div>
                <h4 className="font-heading text-lg sm:text-xl font-extrabold text-white">
                  Fale agora com a gente!
                </h4>
                <p className="text-xs text-slate-400">
                  Tire suas dúvidas, agende uma visita ou solicite uma avaliação.
                </p>
              </div>
            </div>

            {/* Right: Direct Brokers Badges */}
            <div className="flex flex-col sm:flex-row items-center gap-6 sm:gap-10">
              {/* Broker 1: José Hélio */}
              <div className="text-left border-l-2 border-slate-700/60 pl-4 space-y-1">
                <div className="flex items-center justify-between gap-3">
                  <span className="font-heading font-extrabold text-sm text-white">
                    José Hélio
                  </span>
                  <span className="text-[10px] text-slate-400 uppercase tracking-wider">
                    Corretor de Imóveis
                  </span>
                </div>
                <a
                  href="https://wa.me/5535991042131"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-1.5 text-xs text-emerald-400 hover:text-emerald-300 font-bold"
                >
                  <Phone className="w-3.5 h-3.5 text-emerald-400" />
                  <span>(35) 99104-2131</span>
                </a>
                <span className="block text-[10px] text-slate-500 font-mono">
                  CRECI MGF 11.606
                </span>
              </div>

              {/* Broker 2: Dayana */}
              <div className="text-left border-l-2 border-slate-700/60 pl-4 space-y-1">
                <div className="flex items-center justify-between gap-3">
                  <span className="font-heading font-extrabold text-sm text-white">
                    Dayana
                  </span>
                  <span className="text-[10px] text-slate-400 uppercase tracking-wider">
                    Corretora de Imóveis
                  </span>
                </div>
                <a
                  href="https://wa.me/5535997435840"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-1.5 text-xs text-emerald-400 hover:text-emerald-300 font-bold"
                >
                  <Phone className="w-3.5 h-3.5 text-emerald-400" />
                  <span>(35) 99743-5840</span>
                </a>
                <span className="block text-[10px] text-slate-500 font-mono">
                  CRECI MGF 30.881
                </span>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};
