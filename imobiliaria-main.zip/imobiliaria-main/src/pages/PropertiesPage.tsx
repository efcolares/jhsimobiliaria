import React, { useState } from 'react';
import { 
  SlidersHorizontal, 
  LayoutGrid, 
  List, 
  RotateCcw, 
  Search, 
  X, 
  ArrowUpDown, 
  ChevronLeft, 
  ChevronRight,
  Home,
  MessageCircle
} from 'lucide-react';
import { useProperty } from '../context/PropertyContext';
import { PropertyCard } from '../components/PropertyCard';
import { CITIES_LIST, NEIGHBORHOODS_LIST, PROPERTY_TYPES_LABELS, COMMON_FEATURES_LIST } from '../data/mockProperties';
import { formatCurrency, generateWhatsAppLink } from '../utils/formatters';

const ITEMS_PER_PAGE = 6;

export const PropertiesPage: React.FC = () => {
  const { 
    filters, 
    updateFilter, 
    resetFilters, 
    filteredProperties,
    setIsAdvancedSearchOpen,
    setCurrentView
  } = useProperty();

  const [layout, setLayout] = useState<'grid' | 'list'>('grid');
  const [mobileFilterOpen, setMobileFilterOpen] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);

  // Pagination
  const totalPages = Math.ceil(filteredProperties.length / ITEMS_PER_PAGE) || 1;
  const paginatedProps = filteredProperties.slice(
    (currentPage - 1) * ITEMS_PER_PAGE,
    currentPage * ITEMS_PER_PAGE
  );

  // Active filters count
  const activeFiltersCount = [
    filters.purpose !== 'todos',
    filters.type !== 'todos' && filters.type !== '',
    Boolean(filters.city),
    Boolean(filters.neighborhood),
    Boolean(filters.code.trim()),
    filters.minPrice !== null,
    filters.maxPrice !== null,
    filters.bedrooms !== null,
    filters.bathrooms !== null,
    filters.garages !== null,
    filters.minArea !== null,
    filters.selectedFeatures.length > 0
  ].filter(Boolean).length;

  const handlePageChange = (p: number) => {
    setCurrentPage(p);
    window.scrollTo({ top: 180, behavior: 'smooth' });
  };

  return (
    <div className="bg-slate-50 min-h-screen py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        {/* Page Header */}
        <div className="mb-6 pb-6 border-b border-slate-200 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 text-xs text-slate-500 mb-1">
              <button onClick={() => setCurrentView('home')} className="hover:text-slate-800">
                Início
              </button>
              <span>/</span>
              <span className="font-semibold text-slate-800">Imóveis</span>
              {filters.purpose !== 'todos' && (
                <>
                  <span>/</span>
                  <span className="capitalize text-amber-700 font-bold">{filters.purpose}</span>
                </>
              )}
            </div>

            <h1 className="font-heading text-2xl sm:text-3xl font-extrabold text-[#0B2545]">
              {filters.purpose === 'venda' 
                ? 'Imóveis à Venda em Itajubá e Região' 
                : filters.purpose === 'locacao' 
                ? 'Imóveis para Locação em Itajubá' 
                : 'Catálogo Completo de Imóveis'}
            </h1>
          </div>

          {/* Quick Stats & WhatsApp button */}
          <div className="flex items-center gap-3">
            <a
              href={generateWhatsAppLink()}
              target="_blank"
              rel="noopener noreferrer"
              className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-lg text-xs flex items-center gap-1.5 transition-colors shadow-xs"
            >
              <MessageCircle className="w-4 h-4" />
              <span>Plantão de Atendimento</span>
            </a>
          </div>
        </div>

        {/* Main Content Layout (Sidebar + Results) */}
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Desktop Filters Sidebar */}
          <aside className="hidden lg:block lg:col-span-1 space-y-6">
            <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs space-y-5 sticky top-24">
              <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                <span className="font-heading font-bold text-sm text-slate-900 flex items-center gap-1.5">
                  <SlidersHorizontal className="w-4 h-4 text-amber-600" />
                  Filtrar Imóveis
                </span>
                {activeFiltersCount > 0 && (
                  <button
                    type="button"
                    onClick={() => {
                      resetFilters();
                      setCurrentPage(1);
                    }}
                    className="text-[11px] font-semibold text-amber-700 hover:text-amber-800 flex items-center gap-1 cursor-pointer"
                  >
                    <RotateCcw className="w-3 h-3" />
                    Limpar ({activeFiltersCount})
                  </button>
                )}
              </div>

              {/* Purpose Switch */}
              <div>
                <label className="block text-[11px] font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                  Finalidade
                </label>
                <div className="grid grid-cols-3 gap-1 bg-slate-100 p-1 rounded-lg text-xs">
                  <button
                    type="button"
                    onClick={() => { updateFilter('purpose', 'todos'); setCurrentPage(1); }}
                    className={`py-1.5 font-bold rounded-md transition-all ${
                      filters.purpose === 'todos' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600'
                    }`}
                  >
                    Todos
                  </button>
                  <button
                    type="button"
                    onClick={() => { updateFilter('purpose', 'venda'); setCurrentPage(1); }}
                    className={`py-1.5 font-bold rounded-md transition-all ${
                      filters.purpose === 'venda' ? 'bg-[#0B2545] text-white shadow-xs' : 'text-slate-600'
                    }`}
                  >
                    Venda
                  </button>
                  <button
                    type="button"
                    onClick={() => { updateFilter('purpose', 'locacao'); setCurrentPage(1); }}
                    className={`py-1.5 font-bold rounded-md transition-all ${
                      filters.purpose === 'locacao' ? 'bg-[#0B2545] text-white shadow-xs' : 'text-slate-600'
                    }`}
                  >
                    Aluguel
                  </button>
                </div>
              </div>

              {/* Text Search or Code */}
              <div>
                <label className="block text-[11px] font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                  Buscar por Código ou Nome
                </label>
                <div className="relative">
                  <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={filters.code}
                    onChange={e => { updateFilter('code', e.target.value); setCurrentPage(1); }}
                    placeholder="Ex: JHS-101 ou Centro..."
                    className="w-full pl-8 pr-3 py-2 text-xs border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 outline-none"
                  />
                </div>
              </div>

              {/* Type */}
              <div>
                <label className="block text-[11px] font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                  Tipo de Imóvel
                </label>
                <select
                  value={filters.type}
                  onChange={e => { updateFilter('type', e.target.value); setCurrentPage(1); }}
                  className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg bg-slate-50 focus:bg-white focus:ring-2 focus:ring-amber-500 outline-none cursor-pointer"
                >
                  <option value="todos">Todos os Tipos</option>
                  {Object.entries(PROPERTY_TYPES_LABELS).map(([k, v]) => (
                    <option key={k} value={k}>{v}</option>
                  ))}
                </select>
              </div>

              {/* City */}
              <div>
                <label className="block text-[11px] font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                  Cidade
                </label>
                <select
                  value={filters.city}
                  onChange={e => { updateFilter('city', e.target.value); setCurrentPage(1); }}
                  className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg bg-slate-50 focus:bg-white focus:ring-2 focus:ring-amber-500 outline-none cursor-pointer"
                >
                  <option value="">Todas as Cidades</option>
                  {CITIES_LIST.map(c => <option key={c} value={c}>{c}</option>)}
                </select>
              </div>

              {/* Neighborhood */}
              <div>
                <label className="block text-[11px] font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                  Bairro em Itajubá
                </label>
                <select
                  value={filters.neighborhood}
                  onChange={e => { updateFilter('neighborhood', e.target.value); setCurrentPage(1); }}
                  className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg bg-slate-50 focus:bg-white focus:ring-2 focus:ring-amber-500 outline-none cursor-pointer"
                >
                  <option value="">Todos os Bairros</option>
                  {NEIGHBORHOODS_LIST.map(n => <option key={n} value={n}>{n}</option>)}
                </select>
              </div>

              {/* Bedrooms */}
              <div>
                <label className="block text-[11px] font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                  Quartos
                </label>
                <div className="grid grid-cols-5 gap-1 text-xs">
                  {[null, 1, 2, 3, 4].map(num => (
                    <button
                      key={num ?? 'all'}
                      type="button"
                      onClick={() => { updateFilter('bedrooms', num); setCurrentPage(1); }}
                      className={`py-1.5 font-bold rounded border transition-all ${
                        filters.bedrooms === num
                          ? 'bg-[#0B2545] text-white border-[#0B2545]'
                          : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100'
                      }`}
                    >
                      {num === null ? 'Todos' : `${num}+`}
                    </button>
                  ))}
                </div>
              </div>

              {/* Price Max */}
              <div>
                <label className="block text-[11px] font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                  Preço Máximo (R$)
                </label>
                <input
                  type="number"
                  placeholder="Ex: 800.000"
                  value={filters.maxPrice ?? ''}
                  onChange={e => {
                    updateFilter('maxPrice', e.target.value ? Number(e.target.value) : null);
                    setCurrentPage(1);
                  }}
                  className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg outline-none focus:ring-2 focus:ring-amber-500"
                />
              </div>

              {/* More Filters Trigger */}
              <button
                type="button"
                onClick={() => setIsAdvancedSearchOpen(true)}
                className="w-full py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold rounded-lg transition-colors border border-slate-300 flex items-center justify-center gap-1.5"
              >
                <SlidersHorizontal className="w-3.5 h-3.5 text-amber-600" />
                <span>Mais Filtros (Vagas, Lazer...)</span>
              </button>
            </div>
          </aside>

          {/* Results Main Column */}
          <main className="lg:col-span-3 space-y-5">
            {/* Top Results Controls Bar */}
            <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-2xs flex flex-wrap items-center justify-between gap-4">
              <div className="flex items-center gap-2">
                {/* Mobile Filter Toggle Button */}
                <button
                  type="button"
                  onClick={() => setMobileFilterOpen(true)}
                  className="lg:hidden px-3.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold rounded-lg flex items-center gap-1.5 border border-slate-300"
                >
                  <SlidersHorizontal className="w-4 h-4 text-amber-600" />
                  <span>Filtros</span>
                  {activeFiltersCount > 0 && (
                    <span className="w-4 h-4 bg-amber-500 text-slate-950 rounded-full text-[10px] font-bold flex items-center justify-center">
                      {activeFiltersCount}
                    </span>
                  )}
                </button>

                <div className="text-xs text-slate-600 font-medium">
                  Encontrados <strong className="text-slate-900 font-bold">{filteredProperties.length}</strong> {filteredProperties.length === 1 ? 'imóvel' : 'imóveis'}
                </div>
              </div>

              <div className="flex items-center gap-3">
                {/* Sort selector */}
                <div className="flex items-center gap-1.5 text-xs">
                  <span className="text-slate-500 hidden sm:inline">Ordenar:</span>
                  <select
                    value={filters.sortBy}
                    onChange={e => updateFilter('sortBy', e.target.value as any)}
                    className="px-2.5 py-1.5 bg-slate-50 border border-slate-300 rounded-lg text-xs font-semibold text-slate-700 outline-none cursor-pointer"
                  >
                    <option value="relevance">Destaques Primeiro</option>
                    <option value="price-asc">Menor Preço</option>
                    <option value="price-desc">Maior Preço</option>
                    <option value="recent">Mais Recentes</option>
                    <option value="area-desc">Maior Metragem</option>
                  </select>
                </div>

                {/* View Layout Toggle (Grid / List) */}
                <div className="flex items-center bg-slate-100 p-0.5 rounded-lg border border-slate-200">
                  <button
                    type="button"
                    onClick={() => setLayout('grid')}
                    className={`p-1.5 rounded transition-all cursor-pointer ${
                      layout === 'grid' ? 'bg-white text-slate-900 shadow-2xs' : 'text-slate-400 hover:text-slate-700'
                    }`}
                    title="Exibição em Grade"
                  >
                    <LayoutGrid className="w-4 h-4" />
                  </button>
                  <button
                    type="button"
                    onClick={() => setLayout('list')}
                    className={`p-1.5 rounded transition-all cursor-pointer ${
                      layout === 'list' ? 'bg-white text-slate-900 shadow-2xs' : 'text-slate-400 hover:text-slate-700'
                    }`}
                    title="Exibição em Lista"
                  >
                    <List className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>

            {/* Active Filter Badges */}
            {activeFiltersCount > 0 && (
              <div className="flex flex-wrap items-center gap-2 text-xs">
                <span className="text-slate-400 text-[11px] font-medium">Filtros ativos:</span>
                {filters.purpose !== 'todos' && (
                  <span className="inline-flex items-center gap-1 px-2.5 py-1 bg-blue-50 border border-blue-200 text-blue-900 rounded-md font-medium">
                    Finalidade: {filters.purpose}
                    <button onClick={() => updateFilter('purpose', 'todos')} className="hover:text-blue-950">
                      <X className="w-3 h-3" />
                    </button>
                  </span>
                )}
                {filters.type !== 'todos' && filters.type && (
                  <span className="inline-flex items-center gap-1 px-2.5 py-1 bg-blue-50 border border-blue-200 text-blue-900 rounded-md font-medium">
                    Tipo: {PROPERTY_TYPES_LABELS[filters.type] || filters.type}
                    <button onClick={() => updateFilter('type', 'todos')} className="hover:text-blue-950">
                      <X className="w-3 h-3" />
                    </button>
                  </span>
                )}
                {filters.city && (
                  <span className="inline-flex items-center gap-1 px-2.5 py-1 bg-blue-50 border border-blue-200 text-blue-900 rounded-md font-medium">
                    Cidade: {filters.city}
                    <button onClick={() => updateFilter('city', '')} className="hover:text-blue-950">
                      <X className="w-3 h-3" />
                    </button>
                  </span>
                )}
                {filters.neighborhood && (
                  <span className="inline-flex items-center gap-1 px-2.5 py-1 bg-blue-50 border border-blue-200 text-blue-900 rounded-md font-medium">
                    Bairro: {filters.neighborhood}
                    <button onClick={() => updateFilter('neighborhood', '')} className="hover:text-blue-950">
                      <X className="w-3 h-3" />
                    </button>
                  </span>
                )}
                {filters.code && (
                  <span className="inline-flex items-center gap-1 px-2.5 py-1 bg-blue-50 border border-blue-200 text-blue-900 rounded-md font-medium">
                    Busca: "{filters.code}"
                    <button onClick={() => updateFilter('code', '')} className="hover:text-blue-950">
                      <X className="w-3 h-3" />
                    </button>
                  </span>
                )}
                {filters.bedrooms && (
                  <span className="inline-flex items-center gap-1 px-2.5 py-1 bg-blue-50 border border-blue-200 text-blue-900 rounded-md font-medium">
                    {filters.bedrooms}+ Quartos
                    <button onClick={() => updateFilter('bedrooms', null)} className="hover:text-blue-950">
                      <X className="w-3 h-3" />
                    </button>
                  </span>
                )}
                {filters.maxPrice && (
                  <span className="inline-flex items-center gap-1 px-2.5 py-1 bg-blue-50 border border-blue-200 text-blue-900 rounded-md font-medium">
                    Até {formatCurrency(filters.maxPrice)}
                    <button onClick={() => updateFilter('maxPrice', null)} className="hover:text-blue-950">
                      <X className="w-3 h-3" />
                    </button>
                  </span>
                )}
                <button
                  onClick={() => resetFilters()}
                  className="text-amber-700 hover:text-amber-800 font-bold ml-1 text-[11px] underline"
                >
                  Limpar todos
                </button>
              </div>
            )}

            {/* Empty State */}
            {filteredProperties.length === 0 ? (
              <div className="bg-white rounded-2xl border border-slate-200 p-12 text-center space-y-4 shadow-xs">
                <div className="w-16 h-16 rounded-full bg-slate-100 flex items-center justify-center mx-auto text-slate-400">
                  <Search className="w-8 h-8" />
                </div>
                <h3 className="font-heading text-xl font-bold text-slate-900">
                  Nenhum imóvel encontrado com esses critérios
                </h3>
                <p className="text-xs text-slate-500 max-w-md mx-auto leading-relaxed">
                  Tente ajustar ou limpar os filtros para ver mais opções em Itajubá, ou fale diretamente com um de nossos corretores para encomendar o imóvel desejado.
                </p>

                <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
                  <button
                    type="button"
                    onClick={resetFilters}
                    className="px-5 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-xs rounded-lg transition-colors cursor-pointer"
                  >
                    Limpar Filtros de Busca
                  </button>
                  <a
                    href={generateWhatsAppLink()}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="px-5 py-2.5 bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold text-xs rounded-lg transition-colors flex items-center gap-2"
                  >
                    <MessageCircle className="w-4 h-4" />
                    <span>Falar com o Corretor</span>
                  </a>
                </div>
              </div>
            ) : (
              <>
                {/* Properties List/Grid */}
                <div className={
                  layout === 'grid' 
                    ? 'grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6'
                    : 'space-y-4'
                }>
                  {paginatedProps.map(property => (
                    <PropertyCard key={property.id} property={property} layout={layout} />
                  ))}
                </div>

                {/* Pagination */}
                {totalPages > 1 && (
                  <div className="pt-6 flex items-center justify-center gap-2">
                    <button
                      type="button"
                      disabled={currentPage === 1}
                      onClick={() => handlePageChange(currentPage - 1)}
                      className="p-2 rounded-lg border border-slate-300 bg-white text-slate-600 disabled:opacity-40 disabled:cursor-not-allowed hover:bg-slate-50"
                    >
                      <ChevronLeft className="w-4 h-4" />
                    </button>

                    {Array.from({ length: totalPages }).map((_, idx) => {
                      const pageNum = idx + 1;
                      return (
                        <button
                          key={pageNum}
                          type="button"
                          onClick={() => handlePageChange(pageNum)}
                          className={`w-9 h-9 rounded-lg text-xs font-bold transition-all ${
                            currentPage === pageNum
                              ? 'bg-[#0B2545] text-white shadow-xs'
                              : 'bg-white border border-slate-300 text-slate-700 hover:bg-slate-100'
                          }`}
                        >
                          {pageNum}
                        </button>
                      );
                    })}

                    <button
                      type="button"
                      disabled={currentPage === totalPages}
                      onClick={() => handlePageChange(currentPage + 1)}
                      className="p-2 rounded-lg border border-slate-300 bg-white text-slate-600 disabled:opacity-40 disabled:cursor-not-allowed hover:bg-slate-50"
                    >
                      <ChevronRight className="w-4 h-4" />
                    </button>
                  </div>
                )}
              </>
            )}
          </main>
        </div>
      </div>

      {/* Mobile Filters Slide-in Panel */}
      {mobileFilterOpen && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex justify-end">
          <div className="bg-white w-full max-w-sm h-full overflow-y-auto p-6 space-y-6 flex flex-col justify-between shadow-2xl">
            <div>
              <div className="flex items-center justify-between pb-4 border-b border-slate-200">
                <span className="font-heading font-bold text-base text-slate-900">
                  Filtros de Busca
                </span>
                <button onClick={() => setMobileFilterOpen(false)} className="p-1 text-slate-400">
                  <X className="w-6 h-6" />
                </button>
              </div>

              <div className="py-4 space-y-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Finalidade</label>
                  <select
                    value={filters.purpose}
                    onChange={e => updateFilter('purpose', e.target.value as any)}
                    className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg"
                  >
                    <option value="todos">Todos</option>
                    <option value="venda">Venda</option>
                    <option value="locacao">Locação</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Tipo de Imóvel</label>
                  <select
                    value={filters.type}
                    onChange={e => updateFilter('type', e.target.value)}
                    className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg"
                  >
                    <option value="todos">Todos os Tipos</option>
                    {Object.entries(PROPERTY_TYPES_LABELS).map(([k, v]) => (
                      <option key={k} value={k}>{v}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Bairro</label>
                  <select
                    value={filters.neighborhood}
                    onChange={e => updateFilter('neighborhood', e.target.value)}
                    className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg"
                  >
                    <option value="">Todos os Bairros</option>
                    {NEIGHBORHOODS_LIST.map(n => <option key={n} value={n}>{n}</option>)}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Código do Imóvel</label>
                  <input
                    type="text"
                    value={filters.code}
                    onChange={e => updateFilter('code', e.target.value)}
                    placeholder="Ex: JHS-101"
                    className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg"
                  />
                </div>
              </div>
            </div>

            <div className="pt-4 border-t border-slate-200 flex items-center gap-2">
              <button
                type="button"
                onClick={() => { resetFilters(); setMobileFilterOpen(false); }}
                className="w-1/2 py-2.5 bg-slate-100 text-slate-700 font-bold text-xs rounded-lg"
              >
                Limpar
              </button>
              <button
                type="button"
                onClick={() => setMobileFilterOpen(false)}
                className="w-1/2 py-2.5 bg-[#0B2545] text-white font-bold text-xs rounded-lg"
              >
                Ver Resultados
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
