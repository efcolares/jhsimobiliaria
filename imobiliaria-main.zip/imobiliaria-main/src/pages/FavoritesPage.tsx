import React from 'react';
import { Heart, Search, ArrowRight } from 'lucide-react';
import { useProperty } from '../context/PropertyContext';
import { PropertyCard } from '../components/PropertyCard';

export const FavoritesPage: React.FC = () => {
  const { properties, favorites, setCurrentView } = useProperty();

  const favoriteProperties = properties.filter(p => favorites.includes(p.id));

  return (
    <div className="bg-slate-50 min-h-screen py-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 space-y-6">
        <div className="flex items-center justify-between pb-6 border-b border-slate-200">
          <div>
            <div className="flex items-center gap-2 text-rose-600 text-xs font-bold uppercase tracking-wider mb-1">
              <Heart className="w-4 h-4 fill-rose-600" />
              <span>Lista de Desejos</span>
            </div>
            <h1 className="font-heading text-2xl sm:text-3xl font-extrabold text-[#0B2545]">
              Meus Imóveis Favoritos
            </h1>
          </div>

          <div className="text-xs text-slate-500 font-medium">
            <strong className="text-slate-900 font-bold">{favoriteProperties.length}</strong> {favoriteProperties.length === 1 ? 'imóvel salvo' : 'imóveis salvos'}
          </div>
        </div>

        {favoriteProperties.length === 0 ? (
          <div className="bg-white rounded-2xl border border-slate-200 p-12 text-center space-y-4 shadow-xs max-w-lg mx-auto">
            <div className="w-16 h-16 rounded-full bg-rose-50 text-rose-500 flex items-center justify-center mx-auto">
              <Heart className="w-8 h-8" />
            </div>
            <h3 className="font-heading text-xl font-bold text-slate-900">
              Você ainda não favoritou nenhum imóvel
            </h3>
            <p className="text-xs text-slate-500 leading-relaxed">
              Explore nossos imóveis à venda e para locação em Itajubá e clique no ícone de coração para salvar suas opções preferidas.
            </p>
            <button
              onClick={() => setCurrentView('search')}
              className="inline-flex items-center gap-2 px-6 py-2.5 bg-[#0B2545] hover:bg-[#133E68] text-white font-bold rounded-lg text-xs shadow-sm transition-colors"
            >
              <span>Explorar Imóveis</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {favoriteProperties.map(property => (
              <PropertyCard key={property.id} property={property} layout="grid" />
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
