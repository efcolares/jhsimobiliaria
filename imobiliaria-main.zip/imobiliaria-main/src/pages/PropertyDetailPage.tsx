import React, { useState } from 'react';
import { 
  ChevronLeft, 
  MapPin, 
  Heart, 
  Share2, 
  Bed, 
  Bath, 
  Car, 
  Maximize2, 
  Calendar, 
  MessageCircle, 
  Phone, 
  Mail, 
  Check, 
  ShieldCheck, 
  Clock, 
  CheckCircle2, 
  Building2,
  FileText,
  User,
  Sparkles
} from 'lucide-react';
import { useProperty } from '../context/PropertyContext';
import { PropertyGallery } from '../components/PropertyGallery';
import { PropertyMap } from '../components/PropertyMap';
import { PropertyCard } from '../components/PropertyCard';
import { formatCurrency, formatArea, generateWhatsAppLink, generateDirectCallLink } from '../utils/formatters';
import { PROPERTY_TYPES_LABELS } from '../data/mockProperties';

export const PropertyDetailPage: React.FC = () => {
  const { 
    selectedProperty, 
    setCurrentView, 
    isFavorite, 
    toggleFavorite, 
    openScheduleModal, 
    addLead,
    properties 
  } = useProperty();

  // Inquiry form states
  const [formName, setFormName] = useState('');
  const [formPhone, setFormPhone] = useState('');
  const [formEmail, setFormEmail] = useState('');
  const [formMessage, setFormMessage] = useState('');
  const [formSubmitted, setFormSubmitted] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);

  if (!selectedProperty) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-20 text-center space-y-4">
        <p className="text-sm text-slate-500">Nenhum imóvel selecionado.</p>
        <button
          onClick={() => setCurrentView('search')}
          className="px-5 py-2.5 bg-[#0B2545] text-white rounded-lg text-xs font-bold"
        >
          Voltar para a Busca
        </button>
      </div>
    );
  }

  const prop = selectedProperty;
  const isRent = prop.purpose === 'locacao';
  const favorited = isFavorite(prop.id);

  // Similar properties (same purpose or same type, excluding current)
  const similarProperties = properties
    .filter(p => p.id !== prop.id && (p.purpose === prop.purpose || p.type === prop.type))
    .slice(0, 3);

  const whatsAppLink = generateWhatsAppLink(
    prop.title,
    prop.code,
    prop.price,
    prop.purpose
  );

  const handleInquirySubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formName || !formPhone) return;

    addLead({
      name: formName,
      email: formEmail,
      phone: formPhone,
      propertyCode: prop.code,
      propertyTitle: prop.title,
      type: 'proposta',
      message: formMessage || 'Solicitação de informações detalhadas e proposta via formulário do site.'
    });

    setFormSubmitted(true);
  };

  const handleShare = () => {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(window.location.href);
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 3000);
    }
  };

  return (
    <div className="bg-slate-50 min-h-screen py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 space-y-8">
        {/* Navigation Breadcrumbs & Top Bar */}
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-2 text-xs text-slate-500">
            <button 
              onClick={() => setCurrentView('home')} 
              className="hover:text-slate-900 transition-colors cursor-pointer"
            >
              Início
            </button>
            <span>/</span>
            <button 
              onClick={() => setCurrentView('search')} 
              className="hover:text-slate-900 transition-colors cursor-pointer"
            >
              Imóveis
            </button>
            <span>/</span>
            <span className="font-semibold text-slate-800 capitalize">
              {PROPERTY_TYPES_LABELS[prop.type] || prop.type}
            </span>
            <span>/</span>
            <span className="text-amber-700 font-mono font-bold">{prop.code}</span>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleShare}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-white border border-slate-200 rounded-lg text-xs font-semibold text-slate-700 hover:bg-slate-100 transition-colors cursor-pointer shadow-2xs"
            >
              <Share2 className="w-3.5 h-3.5 text-slate-500" />
              <span>{copiedLink ? 'Link Copiado!' : 'Compartilhar'}</span>
            </button>

            <button
              type="button"
              onClick={() => toggleFavorite(prop.id)}
              className={`flex items-center gap-1.5 px-3 py-1.5 bg-white border rounded-lg text-xs font-semibold transition-colors cursor-pointer shadow-2xs ${
                favorited ? 'border-rose-300 text-rose-600 bg-rose-50' : 'border-slate-200 text-slate-700 hover:bg-slate-100'
              }`}
            >
              <Heart className={`w-3.5 h-3.5 ${favorited ? 'fill-rose-500 text-rose-500' : ''}`} />
              <span>{favorited ? 'Salvo nos Favoritos' : 'Favoritar'}</span>
            </button>

            <button
              type="button"
              onClick={() => setCurrentView('search')}
              className="flex items-center gap-1 px-3 py-1.5 bg-slate-200 hover:bg-slate-300 text-slate-800 rounded-lg text-xs font-bold transition-colors cursor-pointer"
            >
              <ChevronLeft className="w-4 h-4" />
              <span>Voltar</span>
            </button>
          </div>
        </div>

        {/* Property Header Banner */}
        <div className="bg-white rounded-2xl p-6 sm:p-8 border border-slate-200 shadow-xs">
          <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
            <div className="space-y-2">
              <div className="flex flex-wrap items-center gap-2">
                <span className={`text-[11px] font-bold px-2.5 py-0.5 rounded-sm uppercase tracking-wider text-white shadow-2xs ${
                  isRent ? 'bg-[#0B2545]' : 'bg-blue-800'
                }`}>
                  {isRent ? 'Para Alugar' : 'Para Venda'}
                </span>

                <span className="text-xs font-mono font-bold text-amber-800 bg-amber-50 px-2 py-0.5 rounded border border-amber-200">
                  CÓD: {prop.code}
                </span>

                {prop.badge === 'destaque' && (
                  <span className="text-[11px] font-bold px-2.5 py-0.5 bg-amber-400 text-slate-950 rounded uppercase flex items-center gap-1">
                    <Sparkles className="w-3 h-3" />
                    Destaque
                  </span>
                )}
              </div>

              <h1 className="font-heading text-2xl sm:text-3xl lg:text-4xl font-extrabold text-[#0B2545] tracking-tight leading-tight">
                {prop.title}
              </h1>

              <div className="flex items-center gap-2 text-xs sm:text-sm text-slate-500 font-medium">
                <MapPin className="w-4 h-4 text-amber-600 shrink-0" />
                <span>
                  {prop.neighborhood}, {prop.city} - {prop.state}
                  {prop.address ? ` · ${prop.address}` : ''}
                </span>
              </div>
            </div>

            {/* Price Box */}
            <div className="lg:text-right shrink-0 bg-slate-50 p-4 sm:p-5 rounded-xl border border-slate-200/80">
              <span className="text-xs text-slate-500 block font-medium">
                {isRent ? 'Valor do Aluguel Mensal' : 'Valor de Venda'}
              </span>
              <div className="font-heading text-3xl sm:text-4xl font-black text-[#0B2545] tabular-nums mt-0.5">
                {formatCurrency(prop.price)}
                {isRent && <span className="text-sm font-semibold text-slate-500">/mês</span>}
              </div>

              {(prop.condoFee || prop.iptu) && (
                <div className="text-xs text-slate-500 mt-1 space-x-2">
                  {prop.condoFee ? <span>Condomínio: {formatCurrency(prop.condoFee)}</span> : null}
                  {prop.condoFee && prop.iptu ? <span>·</span> : null}
                  {prop.iptu ? <span>IPTU: {formatCurrency(prop.iptu)}</span> : null}
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Gallery & Sidebar Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-start">
          {/* Main Visual & Content Column (2 spans) */}
          <div className="lg:col-span-2 space-y-8">
            {/* Gallery with Fullscreen Lightbox */}
            <PropertyGallery images={prop.images} title={prop.title} />

            {/* Technical Specs Key Highlights */}
            <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs">
              <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-4">
                Ficha Técnica do Imóvel
              </h3>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                <div className="p-3 rounded-xl bg-slate-50 border border-slate-200/80 flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-blue-50 text-[#0B2545] flex items-center justify-center shrink-0">
                    <Bed className="w-5 h-5 text-amber-600" />
                  </div>
                  <div>
                    <span className="text-xs text-slate-500 block">Dormitórios</span>
                    <strong className="text-base text-slate-900 font-heading">
                      {prop.bedrooms} {prop.bedrooms === 1 ? 'Quarto' : 'Quartos'}
                    </strong>
                    {prop.suites > 0 && (
                      <span className="text-[11px] text-slate-500 block">({prop.suites} suíte)</span>
                    )}
                  </div>
                </div>

                <div className="p-3 rounded-xl bg-slate-50 border border-slate-200/80 flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-blue-50 text-[#0B2545] flex items-center justify-center shrink-0">
                    <Bath className="w-5 h-5 text-amber-600" />
                  </div>
                  <div>
                    <span className="text-xs text-slate-500 block">Banheiros</span>
                    <strong className="text-base text-slate-900 font-heading">
                      {prop.bathrooms} {prop.bathrooms === 1 ? 'Banheiro' : 'Banheiros'}
                    </strong>
                  </div>
                </div>

                <div className="p-3 rounded-xl bg-slate-50 border border-slate-200/80 flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-blue-50 text-[#0B2545] flex items-center justify-center shrink-0">
                    <Car className="w-5 h-5 text-amber-600" />
                  </div>
                  <div>
                    <span className="text-xs text-slate-500 block">Garagem</span>
                    <strong className="text-base text-slate-900 font-heading">
                      {prop.garages} {prop.garages === 1 ? 'Vaga' : 'Vagas'}
                    </strong>
                  </div>
                </div>

                <div className="p-3 rounded-xl bg-slate-50 border border-slate-200/80 flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-blue-50 text-[#0B2545] flex items-center justify-center shrink-0">
                    <Maximize2 className="w-5 h-5 text-amber-600" />
                  </div>
                  <div>
                    <span className="text-xs text-slate-500 block">Área Total</span>
                    <strong className="text-base text-slate-900 font-heading">
                      {formatArea(prop.totalArea)}
                    </strong>
                    {prop.builtArea && (
                      <span className="text-[11px] text-slate-500 block">({prop.builtArea} m² const.)</span>
                    )}
                  </div>
                </div>
              </div>
            </div>

            {/* Full Architectural Description */}
            <div className="bg-white rounded-2xl border border-slate-200 p-6 sm:p-8 space-y-4 shadow-xs">
              <h3 className="font-heading text-lg font-bold text-slate-900">
                Sobre este Imóvel
              </h3>
              <div className="prose prose-slate max-w-none text-xs sm:text-sm text-slate-600 leading-relaxed space-y-3 whitespace-pre-line">
                {prop.description}
              </div>
            </div>

            {/* Amenities and Features Checklist */}
            <div className="bg-white rounded-2xl border border-slate-200 p-6 sm:p-8 space-y-4 shadow-xs">
              <h3 className="font-heading text-lg font-bold text-slate-900">
                Comodidades e Diferenciais
              </h3>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                {prop.features.map((feature: string, idx: number) => (
                  <div key={idx} className="flex items-center gap-2.5 p-3 rounded-xl bg-slate-50 border border-slate-200/80 text-xs">
                    <div className="w-5 h-5 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center shrink-0">
                      <Check className="w-3.5 h-3.5 stroke-[3]" />
                    </div>
                    <span className="font-semibold text-slate-800">{feature}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Location & Map */}
            <PropertyMap property={prop} />
          </div>

          {/* Sticky Sidebar: Lead Capture & Broker Contact */}
          <aside className="lg:col-span-1 space-y-6 lg:sticky lg:top-24">
            {/* Primary Actions Card */}
            <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-md space-y-4">
              <div className="text-center pb-2">
                <span className="text-xs text-slate-500">Valor para negociação</span>
                <div className="font-heading text-2xl font-black text-[#0B2545] tabular-nums">
                  {formatCurrency(prop.price)}
                  {isRent && <span className="text-xs font-semibold text-slate-500">/mês</span>}
                </div>
              </div>

              {/* Direct WhatsApp Action Button */}
              <a
                href={whatsAppLink}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full py-3.5 px-4 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl text-sm transition-all flex items-center justify-center gap-2 shadow-sm cursor-pointer"
              >
                <MessageCircle className="w-5 h-5" />
                <span>Conversar no WhatsApp</span>
              </a>

              {/* Schedule Visit Modal Trigger */}
              <button
                type="button"
                onClick={() => openScheduleModal(prop)}
                className="w-full py-3.5 px-4 bg-[#0B2545] hover:bg-[#133E68] text-white font-bold rounded-xl text-sm transition-all flex items-center justify-center gap-2 shadow-sm cursor-pointer"
              >
                <Calendar className="w-5 h-5 text-amber-400" />
                <span>Agendar uma Visita</span>
              </button>

              <div className="pt-2 text-center">
                <a
                  href={generateDirectCallLink()}
                  className="text-xs font-semibold text-slate-600 hover:text-slate-900 inline-flex items-center gap-1.5"
                >
                  <Phone className="w-3.5 h-3.5 text-amber-600" />
                  <span>Ou ligue: (35) 99743-5840</span>
                </a>
              </div>
            </div>

            {/* Quick Proposal / Inquiry Form */}
            <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-4">
              <div className="border-b border-slate-100 pb-3">
                <h4 className="font-heading font-bold text-sm text-slate-900">
                  Envie sua Mensagem ou Proposta
                </h4>
                <p className="text-[11px] text-slate-500 mt-0.5">
                  Receba atendimento prioritário do corretor responsável
                </p>
              </div>

              {formSubmitted ? (
                <div className="py-6 text-center space-y-2">
                  <div className="w-10 h-10 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto">
                    <CheckCircle2 className="w-6 h-6" />
                  </div>
                  <strong className="text-xs text-slate-900 block font-bold">Mensagem Enviada!</strong>
                  <p className="text-[11px] text-slate-500">
                    Retornaremos para {formPhone} em breve.
                  </p>
                  <button
                    type="button"
                    onClick={() => setFormSubmitted(false)}
                    className="text-[11px] text-[#0B2545] font-bold underline pt-2"
                  >
                    Enviar outra mensagem
                  </button>
                </div>
              ) : (
                <form onSubmit={handleInquirySubmit} className="space-y-3">
                  <div>
                    <label className="block text-[11px] font-bold text-slate-700 mb-1">
                      Seu Nome Completo *
                    </label>
                    <input
                      type="text"
                      required
                      value={formName}
                      onChange={e => setFormName(e.target.value)}
                      placeholder="Ex: Carlos Eduardo"
                      className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-slate-700 mb-1">
                      WhatsApp / Telefone *
                    </label>
                    <input
                      type="tel"
                      required
                      value={formPhone}
                      onChange={e => setFormPhone(e.target.value)}
                      placeholder="(35) 99999-9999"
                      className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-slate-700 mb-1">
                      E-mail
                    </label>
                    <input
                      type="email"
                      value={formEmail}
                      onChange={e => setFormEmail(e.target.value)}
                      placeholder="seu@email.com"
                      className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-slate-700 mb-1">
                      Mensagem ou Proposta
                    </label>
                    <textarea
                      rows={3}
                      value={formMessage}
                      onChange={e => setFormMessage(e.target.value)}
                      placeholder={`Gostaria de saber mais sobre o imóvel Cód: ${prop.code}...`}
                      className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 outline-none resize-none"
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full py-2.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded-lg text-xs shadow-xs transition-colors cursor-pointer"
                  >
                    Enviar Solicitação
                  </button>
                </form>
              )}
            </div>

            {/* Broker & Agency Credentials */}
            <div className="bg-slate-100 rounded-2xl p-5 border border-slate-200 space-y-3">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-[#0B2545] text-amber-400 flex items-center justify-center font-bold text-xs font-heading">
                  JHS
                </div>
                <div>
                  <h5 className="font-heading font-bold text-xs text-slate-900">
                    JHS Imobiliária LTDA
                  </h5>
                  <span className="text-[11px] text-slate-500">CRECI-MG 24.891</span>
                </div>
              </div>

              <div className="pt-2 border-t border-slate-200 text-xs text-slate-600 space-y-1.5">
                <div className="flex items-center gap-2">
                  <ShieldCheck className="w-3.5 h-3.5 text-amber-600" />
                  <span>Documentação 100% Auditada</span>
                </div>
                <div className="flex items-center gap-2">
                  <Clock className="w-3.5 h-3.5 text-amber-600" />
                  <span>Atendimento Seg a Sex 08:30 às 17:30</span>
                </div>
              </div>
            </div>
          </aside>
        </div>

        {/* Similar Properties Showcase */}
        {similarProperties.length > 0 && (
          <div className="pt-8 border-t border-slate-200 space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <span className="text-xs font-bold text-amber-700 uppercase tracking-wider block">
                  Sugestões
                </span>
                <h3 className="font-heading text-2xl font-bold text-[#0B2545]">
                  Imóveis Semelhantes em Itajubá
                </h3>
              </div>
              <button
                onClick={() => setCurrentView('search')}
                className="text-xs font-bold text-[#0B2545] hover:text-amber-700 underline"
              >
                Ver todos os imóveis
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {similarProperties.map(item => (
                <PropertyCard key={item.id} property={item} layout="grid" />
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
