import React, { createContext, useContext, useState, useEffect } from 'react';
import { Property, FilterState, LeadContact, OwnerSubmission } from '../types/property';
import { INITIAL_PROPERTIES } from '../data/mockProperties';

const DEFAULT_FILTERS: FilterState = {
  purpose: 'todos',
  type: 'todos',
  city: '',
  neighborhood: '',
  code: '',
  minPrice: null,
  maxPrice: null,
  bedrooms: null,
  bathrooms: null,
  garages: null,
  minArea: null,
  selectedFeatures: [],
  sortBy: 'relevance'
};

interface PropertyContextType {
  properties: Property[];
  addProperty: (newProp: Omit<Property, 'id' | 'createdAt'>) => void;
  updateProperty: (id: string, updatedFields: Partial<Property>) => void;
  deleteProperty: (id: string) => void;
  resetToInitialProperties: () => void;
  favorites: string[];
  toggleFavorite: (id: string) => void;
  isFavorite: (id: string) => boolean;
  leads: LeadContact[];
  addLead: (lead: Omit<LeadContact, 'id' | 'createdAt' | 'status'>) => void;
  updateLeadStatus: (id: string, status: LeadContact['status']) => void;
  ownerSubmissions: OwnerSubmission[];
  addOwnerSubmission: (sub: Omit<OwnerSubmission, 'id' | 'createdAt' | 'status'>) => void;
  filters: FilterState;
  setFilters: React.Dispatch<React.SetStateAction<FilterState>>;
  updateFilter: <K extends keyof FilterState>(key: K, value: FilterState[K]) => void;
  resetFilters: () => void;
  currentView: 'home' | 'search' | 'detail' | 'about' | 'favorites' | 'admin';
  setCurrentView: (view: 'home' | 'search' | 'detail' | 'about' | 'favorites' | 'admin') => void;
  selectedPropertyId: string | null;
  selectedProperty: Property | null;
  openPropertyDetail: (id: string) => void;
  isAdvancedSearchOpen: boolean;
  setIsAdvancedSearchOpen: (open: boolean) => void;
  isScheduleModalOpen: boolean;
  setIsScheduleModalOpen: (open: boolean) => void;
  isSubmitModalOpen: boolean;
  setIsSubmitModalOpen: (open: boolean) => void;
  schedulePropertyTarget: Property | null;
  openScheduleModal: (property: Property) => void;
  filteredProperties: Property[];
  featuredProperties: Property[];
  saleProperties: Property[];
  rentProperties: Property[];
}

const PropertyContext = createContext<PropertyContextType | undefined>(undefined);

const STORAGE_PROPS_KEY = 'jhs_properties_data_v2';
const STORAGE_FAVS_KEY = 'jhs_favorites_data_v1';
const STORAGE_LEADS_KEY = 'jhs_leads_data_v1';
const STORAGE_SUBS_KEY = 'jhs_submissions_data_v1';

export const PropertyProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [properties, setProperties] = useState<Property[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_PROPS_KEY);
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error('Failed to load properties from localStorage', e);
    }
    return INITIAL_PROPERTIES;
  });

  const [favorites, setFavorites] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_FAVS_KEY);
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error('Failed to load favorites', e);
    }
    return [];
  });

  const [leads, setLeads] = useState<LeadContact[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_LEADS_KEY);
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error('Failed to load leads', e);
    }
    return [
      {
        id: 'lead-init-1',
        name: 'Carlos Alberto Moreira',
        email: 'carlos.moreira@gmail.com',
        phone: '(35) 99876-1234',
        propertyCode: 'JHS-101',
        propertyTitle: 'Casa Contemporânea de Alto Padrão com Espaço Gourmet',
        type: 'agendamento',
        message: 'Gostaria de agendar uma visita presencial nesta sexta-feira pela manhã.',
        preferredDate: '2026-03-27',
        preferredPeriod: 'manha',
        status: 'novo',
        createdAt: '2026-03-22 10:15'
      },
      {
        id: 'lead-init-2',
        name: 'Dra. Fernanda Siqueira',
        email: 'fernanda.siqueira@medicina.br',
        phone: '(35) 99123-4567',
        propertyCode: 'JHS-104',
        propertyTitle: 'Apartamento Confortável para Locação próximo à Medicina (FMIt)',
        type: 'duvida',
        message: 'O valor do condomínio já inclui água e gás? Tenho interesse na locação imediata.',
        status: 'em_atendimento',
        createdAt: '2026-03-21 16:40'
      }
    ];
  });

  const [ownerSubmissions, setOwnerSubmissions] = useState<OwnerSubmission[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_SUBS_KEY);
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error('Failed to load submissions', e);
    }
    return [];
  });

  const [filters, setFilters] = useState<FilterState>(DEFAULT_FILTERS);
  const [currentView, setCurrentView] = useState<'home' | 'search' | 'detail' | 'about' | 'favorites' | 'admin'>('home');
  const [selectedPropertyId, setSelectedPropertyId] = useState<string | null>(null);

  const [isAdvancedSearchOpen, setIsAdvancedSearchOpen] = useState(false);
  const [isScheduleModalOpen, setIsScheduleModalOpen] = useState(false);
  const [isSubmitModalOpen, setIsSubmitModalOpen] = useState(false);
  const [schedulePropertyTarget, setSchedulePropertyTarget] = useState<Property | null>(null);

  // Sync to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_PROPS_KEY, JSON.stringify(properties));
    } catch (e) {
      console.error(e);
    }
  }, [properties]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_FAVS_KEY, JSON.stringify(favorites));
    } catch (e) {
      console.error(e);
    }
  }, [favorites]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_LEADS_KEY, JSON.stringify(leads));
    } catch (e) {
      console.error(e);
    }
  }, [leads]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_SUBS_KEY, JSON.stringify(ownerSubmissions));
    } catch (e) {
      console.error(e);
    }
  }, [ownerSubmissions]);

  // Handle browser back button or hash navigation if needed
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [currentView, selectedPropertyId]);

  const addProperty = (newProp: Omit<Property, 'id' | 'createdAt'>) => {
    const id = `prop-${Date.now()}`;
    const createdAt = new Date().toISOString().split('T')[0];
    const property: Property = {
      ...newProp,
      id,
      createdAt
    };
    setProperties(prev => [property, ...prev]);
  };

  const updateProperty = (id: string, updatedFields: Partial<Property>) => {
    setProperties(prev => prev.map(p => (p.id === id ? { ...p, ...updatedFields } : p)));
  };

  const deleteProperty = (id: string) => {
    setProperties(prev => prev.filter(p => p.id !== id));
    if (selectedPropertyId === id) {
      setSelectedPropertyId(null);
      setCurrentView('search');
    }
  };

  const resetToInitialProperties = () => {
    setProperties(INITIAL_PROPERTIES);
  };

  const toggleFavorite = (id: string) => {
    setFavorites(prev => 
      prev.includes(id) ? prev.filter(item => item !== id) : [...prev, id]
    );
  };

  const isFavorite = (id: string) => favorites.includes(id);

  const addLead = (leadData: Omit<LeadContact, 'id' | 'createdAt' | 'status'>) => {
    const newLead: LeadContact = {
      ...leadData,
      id: `lead-${Date.now()}`,
      status: 'novo',
      createdAt: new Date().toLocaleString('pt-BR', { dateStyle: 'short', timeStyle: 'short' })
    };
    setLeads(prev => [newLead, ...prev]);
  };

  const updateLeadStatus = (id: string, status: LeadContact['status']) => {
    setLeads(prev => prev.map(l => (l.id === id ? { ...l, status } : l)));
  };

  const addOwnerSubmission = (subData: Omit<OwnerSubmission, 'id' | 'createdAt' | 'status'>) => {
    const newSub: OwnerSubmission = {
      ...subData,
      id: `sub-${Date.now()}`,
      status: 'pendente',
      createdAt: new Date().toLocaleString('pt-BR', { dateStyle: 'short', timeStyle: 'short' })
    };
    setOwnerSubmissions(prev => [newSub, ...prev]);
  };

  const updateFilter = <K extends keyof FilterState>(key: K, value: FilterState[K]) => {
    setFilters(prev => ({ ...prev, [key]: value }));
  };

  const resetFilters = () => {
    setFilters(DEFAULT_FILTERS);
  };

  const openPropertyDetail = (id: string) => {
    setSelectedPropertyId(id);
    setCurrentView('detail');
  };

  const openScheduleModal = (property: Property) => {
    setSchedulePropertyTarget(property);
    setIsScheduleModalOpen(true);
  };

  // Filter computation
  const filteredProperties = properties.filter(prop => {
    // Purpose filter
    if (filters.purpose !== 'todos' && prop.purpose !== filters.purpose) {
      return false;
    }
    // Type filter
    if (filters.type && filters.type !== 'todos' && prop.type !== filters.type) {
      return false;
    }
    // City filter
    if (filters.city && !prop.city.toLowerCase().includes(filters.city.toLowerCase())) {
      return false;
    }
    // Neighborhood filter
    if (filters.neighborhood && !prop.neighborhood.toLowerCase().includes(filters.neighborhood.toLowerCase())) {
      return false;
    }
    // Code or text search filter
    if (filters.code.trim()) {
      const q = filters.code.trim().toLowerCase();
      const codeMatch = prop.code.toLowerCase().includes(q);
      const titleMatch = prop.title.toLowerCase().includes(q);
      const neighMatch = prop.neighborhood.toLowerCase().includes(q);
      const descMatch = prop.description.toLowerCase().includes(q);
      if (!codeMatch && !titleMatch && !neighMatch && !descMatch) {
        return false;
      }
    }
    // Price range
    if (filters.minPrice !== null && prop.price < filters.minPrice) {
      return false;
    }
    if (filters.maxPrice !== null && prop.price > filters.maxPrice) {
      return false;
    }
    // Bedrooms
    if (filters.bedrooms !== null && prop.bedrooms < filters.bedrooms) {
      return false;
    }
    // Bathrooms
    if (filters.bathrooms !== null && prop.bathrooms < filters.bathrooms) {
      return false;
    }
    // Garages
    if (filters.garages !== null && prop.garages < filters.garages) {
      return false;
    }
    // Area
    if (filters.minArea !== null && prop.totalArea < filters.minArea) {
      return false;
    }
    // Features check (must include all selected)
    if (filters.selectedFeatures.length > 0) {
      const hasAllFeatures = filters.selectedFeatures.every(feat => 
        prop.features.some(pf => pf.toLowerCase().includes(feat.toLowerCase()))
      );
      if (!hasAllFeatures) return false;
    }

    return true;
  }).sort((a, b) => {
    switch (filters.sortBy) {
      case 'price-asc':
        return a.price - b.price;
      case 'price-desc':
        return b.price - a.price;
      case 'recent':
        return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
      case 'area-desc':
        return b.totalArea - a.totalArea;
      case 'relevance':
      default:
        // Prioritize featured
        if (a.isFeatured && !b.isFeatured) return -1;
        if (!a.isFeatured && b.isFeatured) return 1;
        return 0;
    }
  });

  const featuredProperties = properties.filter(p => p.isFeatured && p.status === 'disponivel');
  const saleProperties = properties.filter(p => p.purpose === 'venda' && p.status === 'disponivel');
  const rentProperties = properties.filter(p => p.purpose === 'locacao' && p.status === 'disponivel');
  const selectedProperty = properties.find(p => p.id === selectedPropertyId) || null;

  return (
    <PropertyContext.Provider
      value={{
        properties,
        addProperty,
        updateProperty,
        deleteProperty,
        resetToInitialProperties,
        favorites,
        toggleFavorite,
        isFavorite,
        leads,
        addLead,
        updateLeadStatus,
        ownerSubmissions,
        addOwnerSubmission,
        filters,
        setFilters,
        updateFilter,
        resetFilters,
        currentView,
        setCurrentView,
        selectedPropertyId,
        selectedProperty,
        openPropertyDetail,
        isAdvancedSearchOpen,
        setIsAdvancedSearchOpen,
        isScheduleModalOpen,
        setIsScheduleModalOpen,
        isSubmitModalOpen,
        setIsSubmitModalOpen,
        schedulePropertyTarget,
        openScheduleModal,
        filteredProperties,
        featuredProperties,
        saleProperties,
        rentProperties
      }}
    >
      {children}
    </PropertyContext.Provider>
  );
};

export const useProperty = () => {
  const context = useContext(PropertyContext);
  if (!context) {
    throw new Error('useProperty must be used within a PropertyProvider');
  }
  return context;
};
