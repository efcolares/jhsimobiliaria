import React, { useEffect } from 'react';
import { PropertyProvider, useProperty } from './context/PropertyContext';
import { Header } from './components/Header';
import { Footer } from './components/Footer';
import { HomePage } from './pages/HomePage';
import { PropertiesPage } from './pages/PropertiesPage';
import { PropertyDetailPage } from './pages/PropertyDetailPage';
import { AboutPage } from './pages/AboutPage';
import { FavoritesPage } from './pages/FavoritesPage';
import { AdvancedSearchModal } from './components/AdvancedSearchModal';
import { ScheduleVisitModal } from './components/ScheduleVisitModal';
import { SubmitPropertyModal } from './components/SubmitPropertyModal';
import { AdminPanelModal } from './components/AdminPanelModal';
import { MessageCircle } from 'lucide-react';
import { generateWhatsAppLink } from './utils/formatters';

const AppContent: React.FC = () => {
  const { currentView, selectedProperty } = useProperty();

  // Scroll to top on view changes
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [currentView]);

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 text-slate-800 antialiased selection:bg-amber-400 selection:text-slate-950 font-sans">
      {/* Institutional Header */}
      <Header />

      {/* Main View Router */}
      <main className="flex-1">
        {(currentView === 'home' || currentView === 'admin') && <HomePage />}
        {currentView === 'search' && <PropertiesPage />}
        {currentView === 'detail' && <PropertyDetailPage />}
        {currentView === 'about' && <AboutPage />}
        {currentView === 'favorites' && <FavoritesPage />}
      </main>

      {/* Institutional Footer */}
      <Footer />

      {/* Floating WhatsApp Quick Action Button */}
      <a
        href={generateWhatsAppLink(
          selectedProperty?.title,
          selectedProperty?.code,
          selectedProperty?.price,
          selectedProperty?.purpose
        )}
        target="_blank"
        rel="noopener noreferrer"
        className="fixed bottom-6 right-6 z-40 bg-emerald-600 hover:bg-emerald-500 text-white p-3.5 sm:px-4 sm:py-3 rounded-full shadow-2xl flex items-center gap-2 hover:scale-105 active:scale-95 transition-all duration-200 border-2 border-white group cursor-pointer"
        aria-label="Falar no WhatsApp com a JHS Imobiliária"
        title="Falar no WhatsApp com a JHS Imobiliária"
      >
        <MessageCircle className="w-6 h-6 shrink-0 fill-current" />
        <span className="hidden sm:inline font-bold text-xs">
          WhatsApp JHS
        </span>
        <span className="w-2.5 h-2.5 rounded-full bg-emerald-300 animate-ping absolute top-1 right-1" />
      </a>

      {/* Modals & Drawers */}
      <AdvancedSearchModal />
      <ScheduleVisitModal />
      <SubmitPropertyModal />
      <AdminPanelModal />
    </div>
  );
};

export function App() {
  return (
    <PropertyProvider>
      <AppContent />
    </PropertyProvider>
  );
}

export default App;
