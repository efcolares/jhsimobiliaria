export type PropertyType = 
  | 'casa' 
  | 'apartamento' 
  | 'terreno' 
  | 'chacara' 
  | 'comercial' 
  | 'cobertura' 
  | 'galpao';

export type PropertyPurpose = 'venda' | 'locacao';

export type PropertyBadge = 'destaque' | 'lancamento' | 'oportunidade' | 'exclusivo' | 'nenhum';

export type PropertyStatus = 'disponivel' | 'reservado' | 'vendido' | 'alugado';

export interface PropertyAgent {
  name: string;
  creci: string;
  phone: string;
  whatsapp: string;
  email: string;
}

export interface Property {
  id: string;
  code: string;
  title: string;
  slug: string;
  type: PropertyType;
  purpose: PropertyPurpose;
  price: number;
  condoFee?: number;
  iptu?: number;
  city: string;
  state: string;
  neighborhood: string;
  address?: string;
  zipCode?: string;
  bedrooms: number;
  suites: number;
  bathrooms: number;
  garages: number;
  totalArea: number; // m²
  builtArea?: number; // m²
  description: string;
  features: string[];
  images: string[];
  badge: PropertyBadge;
  status: PropertyStatus;
  isFeatured: boolean;
  createdAt: string;
  agent: PropertyAgent;
}

export interface FilterState {
  purpose: 'todos' | 'venda' | 'locacao';
  type: string;
  city: string;
  neighborhood: string;
  code: string;
  minPrice: number | null;
  maxPrice: number | null;
  bedrooms: number | null;
  bathrooms: number | null;
  garages: number | null;
  minArea: number | null;
  selectedFeatures: string[];
  sortBy: 'relevance' | 'price-asc' | 'price-desc' | 'recent' | 'area-desc';
}

export interface LeadContact {
  id: string;
  name: string;
  email: string;
  phone: string;
  propertyCode?: string;
  propertyTitle?: string;
  type: 'duvida' | 'agendamento' | 'proposta' | 'anunciar';
  message: string;
  preferredDate?: string;
  preferredPeriod?: 'manha' | 'tarde';
  status: 'novo' | 'em_atendimento' | 'concluido';
  createdAt: string;
}

export interface OwnerSubmission {
  id: string;
  name: string;
  email: string;
  phone: string;
  propertyType: PropertyType;
  purpose: PropertyPurpose;
  city: string;
  neighborhood: string;
  estimatedPrice: string;
  bedrooms: number;
  bathrooms: number;
  garages: number;
  area: number;
  details: string;
  createdAt: string;
  status: 'pendente' | 'em_avaliacao' | 'aprovado';
}
