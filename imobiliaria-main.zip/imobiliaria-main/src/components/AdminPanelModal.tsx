import React, { useState } from 'react';
import { 
  X, 
  Building2, 
  Plus, 
  Trash2, 
  Edit3, 
  Sparkles, 
  MessageSquare, 
  Inbox, 
  RotateCcw,
  Search,
  CheckCircle,
  Eye,
  FileText
} from 'lucide-react';
import { useProperty } from '../context/PropertyContext';
import { Property, PropertyType, PropertyPurpose, PropertyBadge, PropertyStatus } from '../types/property';
import { createArchitecturalImage, PROPERTY_TYPES_LABELS, COMMON_FEATURES_LIST, CITIES_LIST, NEIGHBORHOODS_LIST } from '../data/mockProperties';
import { formatCurrency } from '../utils/formatters';

export const AdminPanelModal: React.FC = () => {
  const { 
    currentView, 
    setCurrentView, 
    properties, 
    addProperty, 
    updateProperty, 
    deleteProperty, 
    resetToInitialProperties,
    leads,
    updateLeadStatus,
    ownerSubmissions,
    openPropertyDetail
  } = useProperty();

  const [activeTab, setActiveTab] = useState<'list' | 'form' | 'leads' | 'submissions'>('list');
  const [editingPropertyId, setEditingPropertyId] = useState<string | null>(null);
  const [searchFilter, setSearchFilter] = useState('');

  // Form State
  const [formData, setFormData] = useState({
    code: '',
    title: '',
    type: 'casa' as PropertyType,
    purpose: 'venda' as PropertyPurpose,
    price: 500000,
    condoFee: 0,
    iptu: 0,
    city: 'Itajubá',
    state: 'MG',
    neighborhood: 'Morro Chic',
    address: '',
    zipCode: '37500-000',
    bedrooms: 3,
    suites: 1,
    bathrooms: 2,
    garages: 2,
    totalArea: 200,
    builtArea: 150,
    description: '',
    features: ['Churrasqueira', 'Portaria 24 horas', 'Jardim / Quintal'],
    badge: 'destaque' as PropertyBadge,
    status: 'disponivel' as PropertyStatus,
    isFeatured: true
  });

  if (currentView !== 'admin') return null;

  const handleStartAdd = () => {
    setEditingPropertyId(null);
    setFormData({
      code: `JHS-${Math.floor(100 + Math.random() * 900)}`,
      title: '',
      type: 'casa',
      purpose: 'venda',
      price: 650000,
      condoFee: 0,
      iptu: 0,
      city: 'Itajubá',
      state: 'MG',
      neighborhood: 'Centro',
      address: '',
      zipCode: '37500-000',
      bedrooms: 3,
      suites: 1,
      bathrooms: 2,
      garages: 2,
      totalArea: 250,
      builtArea: 180,
      description: '',
      features: ['Churrasqueira', 'Varanda / Sacada'],
      badge: 'destaque',
      status: 'disponivel',
      isFeatured: true
    });
    setActiveTab('form');
  };

  const handleStartEdit = (prop: Property) => {
    setEditingPropertyId(prop.id);
    setFormData({
      code: prop.code,
      title: prop.title,
      type: prop.type,
      purpose: prop.purpose,
      price: prop.price,
      condoFee: prop.condoFee || 0,
      iptu: prop.iptu || 0,
      city: prop.city,
      state: prop.state,
      neighborhood: prop.neighborhood,
      address: prop.address || '',
      zipCode: prop.zipCode || '',
      bedrooms: prop.bedrooms,
      suites: prop.suites,
      bathrooms: prop.bathrooms,
      garages: prop.garages,
      totalArea: prop.totalArea,
      builtArea: prop.builtArea || 0,
      description: prop.description,
      features: prop.features,
      badge: prop.badge,
      status: prop.status,
      isFeatured: prop.isFeatured
    });
    setActiveTab('form');
  };

  const handleSaveForm = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.title || !formData.code) return;

    if (editingPropertyId) {
      updateProperty(editingPropertyId, {
        ...formData,
        slug: formData.title.toLowerCase().replace(/[^a-z0-9]+/g, '-')
      });
    } else {
      const generatedImages = [
        createArchitecturalImage(formData.title, PROPERTY_TYPES_LABELS[formData.type] || formData.type, formData.type === 'apartamento' ? 'luxury_apt' : formData.type === 'chacara' ? 'chacara' : 'modern_house'),
        createArchitecturalImage('Área Gourmet & Convivência', 'Área Social', 'kitchen'),
        createArchitecturalImage('Dormitório Master', 'Suíte', 'bedroom')
      ];

      addProperty({
        ...formData,
        slug: formData.title.toLowerCase().replace(/[^a-z0-9]+/g, '-'),
        images: generatedImages,
        agent: {
          name: 'Equipe de Gestão JHS',
          creci: 'CRECI-MG 24.891',
          phone: '(35) 99743-5840',
          whatsapp: '5535997435840',
          email: 'contato@jhsimobiliaria.com.br'
        }
      });
    }

    setActiveTab('list');
  };

  const handleToggleFeatureInForm = (feat: string) => {
    setFormData(prev => ({
      ...prev,
      features: prev.features.includes(feat)
        ? prev.features.filter(f => f !== feat)
        : [...prev.features, feat]
    }));
  };

  const filteredAdminProps = properties.filter(p => {
    if (!searchFilter.trim()) return true;
    const q = searchFilter.toLowerCase();
    return p.code.toLowerCase().includes(q) || 
           p.title.toLowerCase().includes(q) || 
           p.neighborhood.toLowerCase().includes(q);
  });

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-2 sm:p-4">
      <div className="bg-white rounded-2xl shadow-2xl max-w-5xl w-full overflow-hidden border border-slate-200 flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 bg-[#0B2545] text-white">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-amber-500 text-slate-950 flex items-center justify-center font-bold">
              <Building2 className="w-5 h-5" />
            </div>
            <div>
              <h2 className="font-heading text-lg font-bold">
                Painel do Corretor & Gestão JHS
              </h2>
              <p className="text-xs text-slate-300">
                Gerencie catálogo de imóveis, status, contatos recebidos e propostas
              </p>
            </div>
          </div>

          <button
            onClick={() => setCurrentView('home')}
            className="p-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center px-6 border-b border-slate-200 bg-slate-50 gap-2 overflow-x-auto text-xs font-semibold">
          <button
            type="button"
            onClick={() => setActiveTab('list')}
            className={`py-3 px-3.5 border-b-2 transition-all whitespace-nowrap cursor-pointer ${
              activeTab === 'list'
                ? 'border-amber-500 text-[#0B2545] font-bold bg-white'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            Imóveis Cadastrados ({properties.length})
          </button>

          <button
            type="button"
            onClick={handleStartAdd}
            className={`py-3 px-3.5 border-b-2 transition-all whitespace-nowrap cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'form'
                ? 'border-amber-500 text-[#0B2545] font-bold bg-white'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            <Plus className="w-3.5 h-3.5 text-amber-600" />
            {editingPropertyId ? 'Editar Imóvel' : 'Cadastrar Novo Imóvel'}
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('leads')}
            className={`py-3 px-3.5 border-b-2 transition-all whitespace-nowrap cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'leads'
                ? 'border-amber-500 text-[#0B2545] font-bold bg-white'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            <MessageSquare className="w-3.5 h-3.5 text-amber-600" />
            Leads & Agendamentos ({leads.length})
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('submissions')}
            className={`py-3 px-3.5 border-b-2 transition-all whitespace-nowrap cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'submissions'
                ? 'border-amber-500 text-[#0B2545] font-bold bg-white'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            <Inbox className="w-3.5 h-3.5 text-amber-600" />
            Captações Recebidas ({ownerSubmissions.length})
          </button>
        </div>

        {/* Tab Contents */}
        <div className="p-6 flex-1 overflow-y-auto">
          {/* TAB 1: PROPERTIES LIST */}
          {activeTab === 'list' && (
            <div className="space-y-4">
              <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
                <div className="relative flex-1 max-w-md">
                  <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={searchFilter}
                    onChange={e => setSearchFilter(e.target.value)}
                    placeholder="Filtrar por código, título ou bairro..."
                    className="w-full pl-9 pr-3 py-2 text-xs border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 outline-none"
                  />
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={handleStartAdd}
                    className="px-3.5 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded-lg text-xs flex items-center gap-1.5 shadow-xs cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    Novo Imóvel
                  </button>

                  <button
                    onClick={() => {
                      if (confirm('Deseja restaurar a base de dados padrão da demonstração?')) {
                        resetToInitialProperties();
                      }
                    }}
                    className="px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-medium rounded-lg text-xs flex items-center gap-1.5 transition-colors cursor-pointer"
                    title="Restaurar dados de exemplo originais"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                    Restaurar Padrão
                  </button>
                </div>
              </div>

              {/* Table / List */}
              <div className="border border-slate-200 rounded-xl overflow-hidden bg-white shadow-2xs">
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs text-slate-600">
                    <thead className="bg-slate-50 text-slate-700 font-bold uppercase tracking-wider text-[10px] border-b border-slate-200">
                      <tr>
                        <th className="py-3 px-4">Código / Imóvel</th>
                        <th className="py-3 px-4">Tipo & Finalidade</th>
                        <th className="py-3 px-4">Localização</th>
                        <th className="py-3 px-4">Valor</th>
                        <th className="py-3 px-4">Status</th>
                        <th className="py-3 px-4 text-center">Destaque</th>
                        <th className="py-3 px-4 text-right">Ações</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {filteredAdminProps.map(prop => (
                        <tr key={prop.id} className="hover:bg-slate-50/80 transition-colors">
                          <td className="py-3 px-4 font-medium text-slate-900">
                            <span className="font-mono text-amber-700 font-bold block">{prop.code}</span>
                            <span className="line-clamp-1 max-w-xs">{prop.title}</span>
                          </td>
                          <td className="py-3 px-4">
                            <span className="capitalize font-semibold">{PROPERTY_TYPES_LABELS[prop.type] || prop.type}</span>
                            <span className="text-[10px] block text-slate-400 uppercase">{prop.purpose}</span>
                          </td>
                          <td className="py-3 px-4">
                            <span>{prop.neighborhood}</span>
                            <span className="text-[10px] block text-slate-400">{prop.city}</span>
                          </td>
                          <td className="py-3 px-4 font-bold text-slate-900 tabular-nums">
                            {formatCurrency(prop.price)}
                            {prop.purpose === 'locacao' && <span className="text-[10px] font-normal text-slate-400">/mês</span>}
                          </td>
                          <td className="py-3 px-4">
                            <select
                              value={prop.status}
                              onChange={e => updateProperty(prop.id, { status: e.target.value as PropertyStatus })}
                              className="text-xs font-semibold rounded px-2 py-1 border border-slate-300 bg-white"
                            >
                              <option value="disponivel">Disponível</option>
                              <option value="reservado">Reservado</option>
                              <option value="vendido">Vendido</option>
                              <option value="alugado">Alugado</option>
                            </select>
                          </td>
                          <td className="py-3 px-4 text-center">
                            <button
                              type="button"
                              onClick={() => updateProperty(prop.id, { isFeatured: !prop.isFeatured })}
                              className={`p-1 rounded transition-colors ${
                                prop.isFeatured ? 'text-amber-500 bg-amber-50' : 'text-slate-300 hover:text-slate-500'
                              }`}
                              title={prop.isFeatured ? 'Remover dos destaques' : 'Destacar na página inicial'}
                            >
                              <Sparkles className="w-4 h-4 fill-current" />
                            </button>
                          </td>
                          <td className="py-3 px-4 text-right space-x-1.5 whitespace-nowrap">
                            <button
                              type="button"
                              onClick={() => {
                                setCurrentView('detail');
                                openPropertyDetail(prop.id);
                              }}
                              className="p-1 text-slate-500 hover:text-slate-800 rounded hover:bg-slate-100"
                              title="Visualizar no site"
                            >
                              <Eye className="w-4 h-4" />
                            </button>
                            <button
                              type="button"
                              onClick={() => handleStartEdit(prop)}
                              className="p-1 text-blue-600 hover:text-blue-800 rounded hover:bg-blue-50"
                              title="Editar imóvel"
                            >
                              <Edit3 className="w-4 h-4" />
                            </button>
                            <button
                              type="button"
                              onClick={() => {
                                if (confirm(`Deseja excluir o imóvel ${prop.code}?`)) {
                                  deleteProperty(prop.id);
                                }
                              }}
                              className="p-1 text-rose-600 hover:text-rose-800 rounded hover:bg-rose-50"
                              title="Excluir imóvel"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: CREATE / EDIT FORM */}
          {activeTab === 'form' && (
            <form onSubmit={handleSaveForm} className="space-y-5 max-w-4xl mx-auto">
              <div className="flex items-center justify-between pb-3 border-b border-slate-200">
                <h3 className="font-heading text-base font-bold text-slate-900">
                  {editingPropertyId ? 'Editar Detalhes do Imóvel' : 'Cadastrar Novo Imóvel no Catálogo'}
                </h3>
                <button
                  type="button"
                  onClick={() => setActiveTab('list')}
                  className="text-xs font-semibold text-slate-500 hover:text-slate-800"
                >
                  Cancelar e Voltar
                </button>
              </div>

              {/* Basic Fields */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Código de Referência *</label>
                  <input
                    type="text"
                    required
                    value={formData.code}
                    onChange={e => setFormData({ ...formData, code: e.target.value.toUpperCase() })}
                    className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg font-mono font-bold"
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className="block text-xs font-bold text-slate-700 mb-1">Título do Anúncio *</label>
                  <input
                    type="text"
                    required
                    value={formData.title}
                    onChange={e => setFormData({ ...formData, title: e.target.value })}
                    placeholder="Ex: Casa Contemporânea com Piscina no Morro Chic"
                    className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg"
                  />
                </div>
              </div>

              {/* Type, Purpose, Price */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Finalidade</label>
                  <select
                    value={formData.purpose}
                    onChange={e => setFormData({ ...formData, purpose: e.target.value as PropertyPurpose })}
                    className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg bg-white"
                  >
                    <option value="venda">Venda</option>
                    <option value="locacao">Locação</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Tipo de Imóvel</label>
                  <select
                    value={formData.type}
                    onChange={e => setFormData({ ...formData, type: e.target.value as PropertyType })}
                    className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg bg-white"
                  >
                    {Object.entries(PROPERTY_TYPES_LABELS).map(([k, v]) => (
                      <option key={k} value={k}>{v}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Valor Principal (R$)</label>
                  <input
                    type="number"
                    value={formData.price}
                    onChange={e => setFormData({ ...formData, price: Number(e.target.value) })}
                    className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Condomínio Mensal (R$)</label>
                  <input
                    type="number"
                    value={formData.condoFee}
                    onChange={e => setFormData({ ...formData, condoFee: Number(e.target.value) })}
                    className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg"
                  />
                </div>
              </div>

              {/* Location */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Cidade</label>
                  <select
                    value={formData.city}
                    onChange={e => setFormData({ ...formData, city: e.target.value })}
                    className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg bg-white"
                  >
                    {CITIES_LIST.map(c => <option key={c} value={c}>{c}</option>)}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Bairro</label>
                  <select
                    value={formData.neighborhood}
                    onChange={e => setFormData({ ...formData, neighborhood: e.target.value })}
                    className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg bg-white"
                  >
                    {NEIGHBORHOODS_LIST.map(n => <option key={n} value={n}>{n}</option>)}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Endereço / Condomínio</label>
                  <input
                    type="text"
                    value={formData.address}
                    onChange={e => setFormData({ ...formData, address: e.target.value })}
                    placeholder="Ex: Rua São Paulo, 120"
                    className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg"
                  />
                </div>
              </div>

              {/* Specs */}
              <div className="grid grid-cols-2 sm:grid-cols-6 gap-3">
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">Quartos</label>
                  <input
                    type="number"
                    value={formData.bedrooms}
                    onChange={e => setFormData({ ...formData, bedrooms: Number(e.target.value) })}
                    className="w-full px-2.5 py-1.5 text-xs border border-slate-300 rounded-lg"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">Suítes</label>
                  <input
                    type="number"
                    value={formData.suites}
                    onChange={e => setFormData({ ...formData, suites: Number(e.target.value) })}
                    className="w-full px-2.5 py-1.5 text-xs border border-slate-300 rounded-lg"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">Banheiros</label>
                  <input
                    type="number"
                    value={formData.bathrooms}
                    onChange={e => setFormData({ ...formData, bathrooms: Number(e.target.value) })}
                    className="w-full px-2.5 py-1.5 text-xs border border-slate-300 rounded-lg"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">Vagas</label>
                  <input
                    type="number"
                    value={formData.garages}
                    onChange={e => setFormData({ ...formData, garages: Number(e.target.value) })}
                    className="w-full px-2.5 py-1.5 text-xs border border-slate-300 rounded-lg"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">Área Total (m²)</label>
                  <input
                    type="number"
                    value={formData.totalArea}
                    onChange={e => setFormData({ ...formData, totalArea: Number(e.target.value) })}
                    className="w-full px-2.5 py-1.5 text-xs border border-slate-300 rounded-lg"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">Área Construída</label>
                  <input
                    type="number"
                    value={formData.builtArea}
                    onChange={e => setFormData({ ...formData, builtArea: Number(e.target.value) })}
                    className="w-full px-2.5 py-1.5 text-xs border border-slate-300 rounded-lg"
                  />
                </div>
              </div>

              {/* Status and Badge */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Status Comercial</label>
                  <select
                    value={formData.status}
                    onChange={e => setFormData({ ...formData, status: e.target.value as PropertyStatus })}
                    className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg bg-white"
                  >
                    <option value="disponivel">Disponível</option>
                    <option value="reservado">Reservado</option>
                    <option value="vendido">Vendido</option>
                    <option value="alugado">Alugado</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Etiqueta Visual</label>
                  <select
                    value={formData.badge}
                    onChange={e => setFormData({ ...formData, badge: e.target.value as PropertyBadge })}
                    className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg bg-white"
                  >
                    <option value="nenhum">Nenhuma</option>
                    <option value="destaque">Destaque</option>
                    <option value="oportunidade">Oportunidade</option>
                    <option value="lancamento">Lançamento</option>
                    <option value="exclusivo">Exclusivo</option>
                  </select>
                </div>

                <div className="flex items-center gap-2 pt-6">
                  <input
                    type="checkbox"
                    id="featuredCheck"
                    checked={formData.isFeatured}
                    onChange={e => setFormData({ ...formData, isFeatured: e.target.checked })}
                    className="w-4 h-4 rounded text-amber-500 focus:ring-amber-400"
                  />
                  <label htmlFor="featuredCheck" className="text-xs font-bold text-slate-800 cursor-pointer">
                    Exibir na Vitrine de Destaques
                  </label>
                </div>
              </div>

              {/* Description */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Descrição Completa</label>
                <textarea
                  rows={4}
                  value={formData.description}
                  onChange={e => setFormData({ ...formData, description: e.target.value })}
                  placeholder="Descreva a arquitetura, iluminação, acabamentos, localização e pontos fortes do imóvel..."
                  className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg resize-none"
                />
              </div>

              {/* Features Toggle */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-2">Comodidades e Atributos</label>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  {COMMON_FEATURES_LIST.map(f => {
                    const checked = formData.features.includes(f);
                    return (
                      <button
                        type="button"
                        key={f}
                        onClick={() => handleToggleFeatureInForm(f)}
                        className={`text-left px-2.5 py-1.5 rounded text-xs border transition-all ${
                          checked
                            ? 'bg-amber-100 border-amber-300 text-amber-900 font-bold'
                            : 'bg-slate-50 border-slate-200 text-slate-600'
                        }`}
                      >
                        {checked ? '✓ ' : '+ '} {f}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Actions */}
              <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setActiveTab('list')}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-800"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 bg-[#0B2545] hover:bg-[#133E68] text-white font-bold rounded-lg text-xs shadow-md transition-colors"
                >
                  {editingPropertyId ? 'Salvar Alterações' : 'Cadastrar Imóvel'}
                </button>
              </div>
            </form>
          )}

          {/* TAB 3: LEADS & CONTACTS */}
          {activeTab === 'leads' && (
            <div className="space-y-4">
              <h3 className="font-heading text-base font-bold text-slate-900">
                Contatos e Solicitações de Agendamento Recebidas
              </h3>

              {leads.length === 0 ? (
                <div className="text-center py-12 text-slate-400 text-xs">
                  Nenhum contato ou lead registrado até o momento.
                </div>
              ) : (
                <div className="space-y-3">
                  {leads.map(lead => (
                    <div key={lead.id} className="p-4 rounded-xl border border-slate-200 bg-slate-50/50 space-y-2">
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-slate-900 text-sm">{lead.name}</span>
                          <span className="text-xs text-slate-500 font-mono">({lead.phone})</span>
                          <span className="text-[10px] px-2 py-0.5 rounded-full bg-slate-200 font-semibold uppercase text-slate-700">
                            {lead.type}
                          </span>
                        </div>

                        <div className="flex items-center gap-2">
                          <span className="text-[11px] text-slate-400">{lead.createdAt}</span>
                          <select
                            value={lead.status}
                            onChange={e => updateLeadStatus(lead.id, e.target.value as any)}
                            className="text-xs font-semibold rounded px-2 py-1 border border-slate-300 bg-white"
                          >
                            <option value="novo">Novo</option>
                            <option value="em_atendimento">Em Atendimento</option>
                            <option value="concluido">Concluído</option>
                          </select>
                        </div>
                      </div>

                      {lead.propertyTitle && (
                        <div className="text-xs text-amber-900 font-medium">
                          Ref: <strong className="font-mono">{lead.propertyCode}</strong> - {lead.propertyTitle}
                        </div>
                      )}

                      <p className="text-xs text-slate-700 bg-white p-2.5 rounded-lg border border-slate-200">
                        {lead.message}
                      </p>

                      <div className="flex items-center gap-4 text-xs pt-1">
                        <a
                          href={`https://wa.me/55${lead.phone.replace(/\D/g, '')}?text=${encodeURIComponent(`Olá, ${lead.name}! Aqui é da JHS Imobiliária referente ao seu contato.`)}`}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="font-bold text-emerald-600 hover:text-emerald-700 flex items-center gap-1"
                        >
                          Chamar no WhatsApp →
                        </a>
                        {lead.email && (
                          <a href={`mailto:${lead.email}`} className="text-blue-600 hover:underline">
                            {lead.email}
                          </a>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* TAB 4: OWNER SUBMISSIONS */}
          {activeTab === 'submissions' && (
            <div className="space-y-4">
              <h3 className="font-heading text-base font-bold text-slate-900">
                Imóveis Enviados por Proprietários ("Anuncie seu Imóvel")
              </h3>

              {ownerSubmissions.length === 0 ? (
                <div className="text-center py-12 text-slate-400 text-xs">
                  Nenhuma captação pendente. Use o botão "Anunciar Imóvel" no cabeçalho para testar a recepção de imóveis!
                </div>
              ) : (
                <div className="space-y-3">
                  {ownerSubmissions.map(sub => (
                    <div key={sub.id} className="p-4 rounded-xl border border-slate-200 bg-white space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-slate-900 text-sm">{sub.name}</span>
                        <span className="text-xs text-slate-400">{sub.createdAt}</span>
                      </div>
                      <div className="text-xs text-slate-600 grid grid-cols-2 sm:grid-cols-4 gap-2 bg-slate-50 p-2.5 rounded-lg">
                        <div><strong>Finalidade:</strong> {sub.purpose}</div>
                        <div><strong>Tipo:</strong> {PROPERTY_TYPES_LABELS[sub.propertyType]}</div>
                        <div><strong>Local:</strong> {sub.neighborhood}, {sub.city}</div>
                        <div><strong>Preço Est.:</strong> {sub.estimatedPrice || 'A combinar'}</div>
                      </div>
                      {sub.details && (
                        <p className="text-xs text-slate-700">
                          <strong>Observações:</strong> {sub.details}
                        </p>
                      )}
                      <div className="pt-1 flex items-center gap-3 text-xs">
                        <a
                          href={`https://wa.me/55${sub.phone.replace(/\D/g, '')}?text=${encodeURIComponent(`Olá, ${sub.name}! Aqui é da JHS Imobiliária para conversarmos sobre a captação do seu imóvel em ${sub.neighborhood}.`)}`}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="font-bold text-emerald-600 hover:text-emerald-700"
                        >
                          Contatar Proprietário no WhatsApp ({sub.phone}) →
                        </a>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
