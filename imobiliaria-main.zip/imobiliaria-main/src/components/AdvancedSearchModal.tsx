import React from 'react';
import { X, SlidersHorizontal, RotateCcw, Check } from 'lucide-react';
import { useProperty } from '../context/PropertyContext';
import { COMMON_FEATURES_LIST } from '../data/mockProperties';

export const AdvancedSearchModal: React.FC = () => {
  const { 
    isAdvancedSearchOpen, 
    setIsAdvancedSearchOpen, 
    filters, 
    updateFilter, 
    resetFilters,
    filteredProperties,
    setCurrentView
  } = useProperty();

  if (!isAdvancedSearchOpen) return null;

  const handleToggleFeature = (feature: string) => {
    const current = filters.selectedFeatures;
    if (current.includes(feature)) {
      updateFilter('selectedFeatures', current.filter(f => f !== feature));
    } else {
      updateFilter('selectedFeatures', [...current, feature]);
    }
  };

  const handleApply = () => {
    setIsAdvancedSearchOpen(false);
    setCurrentView('search');
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full overflow-hidden border border-slate-200 animate-in fade-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 bg-slate-50">
          <div className="flex items-center gap-2">
            <SlidersHorizontal className="w-5 h-5 text-amber-600" />
            <h3 className="font-heading text-lg font-bold text-slate-900">
              Filtros Avançados de Busca
            </h3>
          </div>
          <button
            onClick={() => setIsAdvancedSearchOpen(false)}
            className="p-1 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-200 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <div className="p-6 space-y-6 max-h-[75vh] overflow-y-auto">
          {/* Price Range */}
          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
              Faixa de Preço (R$)
            </label>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <span className="text-[11px] text-slate-500 block mb-1">Preço Mínimo</span>
                <input
                  type="number"
                  placeholder="Ex: 200.000"
                  value={filters.minPrice ?? ''}
                  onChange={e => updateFilter('minPrice', e.target.value ? Number(e.target.value) : null)}
                  className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:outline-none"
                />
              </div>
              <div>
                <span className="text-[11px] text-slate-500 block mb-1">Preço Máximo</span>
                <input
                  type="number"
                  placeholder="Ex: 1.500.000"
                  value={filters.maxPrice ?? ''}
                  onChange={e => updateFilter('maxPrice', e.target.value ? Number(e.target.value) : null)}
                  className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:outline-none"
                />
              </div>
            </div>
          </div>

          {/* Bedrooms Selector */}
          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
              Número Mínimo de Quartos
            </label>
            <div className="grid grid-cols-5 gap-2">
              {[null, 1, 2, 3, 4].map(num => (
                <button
                  key={num ?? 'all'}
                  type="button"
                  onClick={() => updateFilter('bedrooms', num)}
                  className={`py-2 text-xs font-bold rounded-lg border transition-all ${
                    filters.bedrooms === num
                      ? 'bg-[#0B2545] text-white border-[#0B2545]'
                      : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                  }`}
                >
                  {num === null ? 'Todos' : `${num}+`}
                </button>
              ))}
            </div>
          </div>

          {/* Garages & Bathrooms */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
                Vagas de Garagem
              </label>
              <div className="grid grid-cols-4 gap-2">
                {[null, 1, 2, 3].map(num => (
                  <button
                    key={num ?? 'all'}
                    type="button"
                    onClick={() => updateFilter('garages', num)}
                    className={`py-1.5 text-xs font-bold rounded-lg border transition-all ${
                      filters.garages === num
                        ? 'bg-[#0B2545] text-white border-[#0B2545]'
                        : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                    }`}
                  >
                    {num === null ? 'Todas' : `${num}+`}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
                Área Mínima (m²)
              </label>
              <input
                type="number"
                placeholder="Ex: 80"
                value={filters.minArea ?? ''}
                onChange={e => updateFilter('minArea', e.target.value ? Number(e.target.value) : null)}
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:outline-none"
              />
            </div>
          </div>

          {/* Amenities / Features Checklist */}
          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
              Comodidades e Diferenciais
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
              {COMMON_FEATURES_LIST.map(feature => {
                const checked = filters.selectedFeatures.includes(feature);
                return (
                  <button
                    key={feature}
                    type="button"
                    onClick={() => handleToggleFeature(feature)}
                    className={`flex items-center gap-2 p-2.5 text-xs text-left rounded-lg border transition-all ${
                      checked
                        ? 'bg-amber-50 border-amber-400 text-amber-900 font-semibold shadow-2xs'
                        : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                    }`}
                  >
                    <div className={`w-4 h-4 rounded flex items-center justify-center border text-[10px] ${
                      checked ? 'bg-amber-500 border-amber-600 text-white' : 'border-slate-300 bg-white'
                    }`}>
                      {checked && <Check className="w-3 h-3 stroke-[3]" />}
                    </div>
                    <span>{feature}</span>
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between px-6 py-4 border-t border-slate-200 bg-slate-50">
          <button
            type="button"
            onClick={resetFilters}
            className="flex items-center gap-1.5 text-xs font-semibold text-slate-600 hover:text-slate-900 cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Limpar Filtros</span>
          </button>

          <div className="flex items-center gap-3">
            <span className="text-xs text-slate-500 font-medium">
              <strong className="text-slate-800">{filteredProperties.length}</strong> encontrados
            </span>
            <button
              type="button"
              onClick={handleApply}
              className="px-5 py-2.5 bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold rounded-lg text-xs sm:text-sm shadow-sm transition-colors cursor-pointer"
            >
              Ver Resultados
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
