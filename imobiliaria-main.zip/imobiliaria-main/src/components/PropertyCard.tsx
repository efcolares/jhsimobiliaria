import React from 'react';
import { 
  MapPin, 
  Bed, 
  Bath, 
  Car, 
  Maximize2, 
  ArrowRight,
  Heart
} from 'lucide-react';
import { Property } from '../types/property';
import { useProperty } from '../context/PropertyContext';
import { formatCurrency, formatArea } from '../utils/formatters';

interface PropertyCardProps {
  property: Property;
  layout?: 'grid' | 'list';
}

export const PropertyCard: React.FC<PropertyCardProps> = ({ 
  property,
  layout = 'grid'
}) => {
  const { openPropertyDetail, toggleFavorite, isFavorite } = useProperty();

  const isRent = property.purpose === 'locacao';
  const favorited = isFavorite(property.id);

  const mainImage = property.images[0] || 'https://images.unsplash.com/photo-1568605117036-5fe5e7bab0b7?auto=format&fit=crop&w=800&q=80';

  if (layout === 'list') {
    return (
      <div 
        onClick={() => openPropertyDetail(property.id)}
        className="group bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-xs hover:shadow-md transition-all duration-200 flex flex-col md:flex-row cursor-pointer"
      >
        <div className="relative md:w-72 h-52 shrink-0 overflow-hidden bg-slate-100">
          <img
            src={mainImage}
            alt={property.title}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
            loading="lazy"
          />

          {/* Badge Venda / Aluguel */}
          <div className="absolute top-3 left-3">
            <span className={`px-3 py-1 rounded-sm text-[11px] font-black tracking-wider uppercase text-white shadow-md ${
              isRent ? 'bg-[#0284c7]' : 'bg-[#FF7A00]'
            }`}>
              {isRent ? 'ALUGUEL' : 'VENDA'}
            </span>
          </div>

          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              toggleFavorite(property.id);
            }}
            className="absolute top-3 right-3 p-2 rounded-full bg-white/80 hover:bg-white text-slate-700 shadow-sm transition-colors"
          >
            <Heart className={`w-4 h-4 ${favorited ? 'fill-rose-500 text-rose-500' : ''}`} />
          </button>
        </div>

        <div className="p-5 flex-1 flex flex-col justify-between space-y-4">
          <div>
            <div className="flex items-center justify-between mb-1">
              <span className="text-[11px] font-mono font-bold text-slate-400">
                {property.code}
              </span>
              <span className="text-xs text-slate-500 flex items-center gap-1 font-medium">
                <MapPin className="w-3.5 h-3.5 text-amber-600" />
                {property.neighborhood}, {property.city} - {property.state}
              </span>
            </div>

            <h3 className="font-heading text-lg font-extrabold text-slate-900 group-hover:text-[#0B2545] transition-colors line-clamp-1">
              {property.title}
            </h3>
          </div>

          {/* Specs */}
          <div className="flex items-center gap-4 text-xs text-slate-600 py-2 border-y border-slate-100">
            {property.bedrooms > 0 && (
              <span className="flex items-center gap-1">
                <Bed className="w-3.5 h-3.5 text-slate-400" />
                {property.bedrooms} qtos
              </span>
            )}
            {property.bathrooms > 0 && (
              <span className="flex items-center gap-1">
                <Bath className="w-3.5 h-3.5 text-slate-400" />
                {property.bathrooms} banh
              </span>
            )}
            {property.garages > 0 && (
              <span className="flex items-center gap-1">
                <Car className="w-3.5 h-3.5 text-slate-400" />
                {property.garages} vagas
              </span>
            )}
            <span className="flex items-center gap-1">
              <Maximize2 className="w-3.5 h-3.5 text-slate-400" />
              {formatArea(property.totalArea)}
            </span>
          </div>

          <div className="flex items-center justify-between pt-1">
            <div className="font-heading text-xl font-black text-slate-900">
              {formatCurrency(property.price)}
              {isRent && <span className="text-xs font-normal text-slate-500">/mês</span>}
            </div>

            <button
              type="button"
              className="px-5 py-2 rounded-lg bg-[#071F3D] hover:bg-[#0C2B4E] text-white font-bold text-xs flex items-center gap-1.5 transition-colors"
            >
              <span>VER DETALHES</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>
    );
  }

  // Grid Layout - Direct Match to Reference Image
  return (
    <div 
      onClick={() => openPropertyDetail(property.id)}
      className="group bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-xs hover:shadow-lg transition-all duration-200 flex flex-col cursor-pointer"
    >
      {/* Property Image Container */}
      <div className="relative aspect-16/11 w-full overflow-hidden bg-slate-100">
        <img
          src={mainImage}
          alt={property.title}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
          loading="lazy"
        />

        {/* Badge Venda (Orange) / Aluguel (Blue) */}
        <div className="absolute top-3 left-3">
          <span className={`px-3 py-1 rounded-sm text-[11px] font-black tracking-wider uppercase text-white shadow-md ${
            isRent ? 'bg-[#0284c7]' : 'bg-[#FF7A00]'
          }`}>
            {isRent ? 'ALUGUEL' : 'VENDA'}
          </span>
        </div>

        {/* Favorite Heart Button */}
        <button
          type="button"
          onClick={(e) => {
            e.stopPropagation();
            toggleFavorite(property.id);
          }}
          className="absolute top-3 right-3 p-1.5 rounded-full bg-white/80 hover:bg-white text-slate-700 shadow-sm transition-colors"
          title="Favoritar"
        >
          <Heart className={`w-4 h-4 ${favorited ? 'fill-rose-500 text-rose-500' : 'text-slate-600'}`} />
        </button>
      </div>

      {/* Property Body Information */}
      <div className="p-4 sm:p-5 flex-1 flex flex-col justify-between space-y-3">
        <div className="space-y-1">
          <h3 className="font-heading text-base sm:text-lg font-black text-slate-900 line-clamp-1 group-hover:text-[#FF7A00] transition-colors">
            {property.title}
          </h3>

          <div className="flex items-center gap-1 text-xs text-slate-500 font-medium">
            <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
            <span>{property.neighborhood ? `${property.neighborhood}, ` : ''}{property.city} - {property.state}</span>
          </div>
        </div>

        {/* Technical Specs Row */}
        <div className="flex items-center gap-3 text-xs text-slate-600 py-2 border-y border-slate-100 font-medium">
          {property.type === 'terreno' ? (
            <span className="flex items-center gap-1.5">
              <Maximize2 className="w-3.5 h-3.5 text-slate-500" />
              <span>{property.totalArea} m²</span>
            </span>
          ) : (
            <>
              {property.bedrooms > 0 && (
                <span className="flex items-center gap-1">
                  <Bed className="w-3.5 h-3.5 text-slate-500" />
                  <span>{property.bedrooms}</span>
                </span>
              )}
              {property.bedrooms > 0 && property.bathrooms > 0 && (
                <span className="text-slate-300">|</span>
              )}
              {property.bathrooms > 0 && (
                <span className="flex items-center gap-1">
                  <Bath className="w-3.5 h-3.5 text-slate-500" />
                  <span>{property.bathrooms}</span>
                </span>
              )}
              {property.garages > 0 && (
                <span className="text-slate-300">|</span>
              )}
              {property.garages > 0 && (
                <span className="flex items-center gap-1">
                  <Car className="w-3.5 h-3.5 text-slate-500" />
                  <span>{property.garages}</span>
                </span>
              )}
            </>
          )}
        </div>

        {/* Price Row */}
        <div className="font-heading text-lg sm:text-xl font-black text-slate-900 tracking-tight">
          {formatCurrency(property.price)}
          {isRent && <span className="text-xs font-semibold text-slate-500">/mês</span>}
        </div>

        {/* VER DETALHES Dark Blue Button */}
        <button
          type="button"
          className="w-full py-2.5 px-4 rounded-md bg-[#071F3D] hover:bg-[#0C2B4E] group-hover:bg-[#FF7A00] text-white font-heading font-black text-xs tracking-wider uppercase flex items-center justify-center gap-2 transition-all duration-200 cursor-pointer shadow-xs"
        >
          <span>VER DETALHES</span>
          <ArrowRight className="w-3.5 h-3.5" />
        </button>
      </div>
    </div>
  );
};
