import React from 'react';
import { 
  ShieldCheck, 
  Award, 
  Users, 
  FileCheck2, 
  MapPin, 
  Phone, 
  Mail, 
  Clock, 
  MessageCircle, 
  CheckCircle2,
  Building,
  Scale
} from 'lucide-react';
import { generateWhatsAppLink, generateDirectCallLink } from '../utils/formatters';

export const AboutSection: React.FC = () => {
  const testimonials = [
    {
      name: 'Dr. Leonardo Vasconcelos',
      role: 'Médico no Hospital das Clínicas',
      text: 'Comprei meu primeiro apartamento no Morro Chic através da JHS. Toda a negociação e conferência de certidões no cartório foram feitas com total transparência e segurança jurídica. Recomendo de olhos fechados!',
      location: 'Itajubá - MG'
    },
    {
      name: 'Mariana Duarte Prado',
      role: 'Proprietária de Imóveis para Locação',
      text: 'A JHS administra meus três imóveis no Centro de Itajubá há mais de 4 anos. Repasse sempre rigorosamente em dia, vistoria detalhada de entrada e saída e inquilinos muito bem qualificados.',
      location: 'Itajubá - MG'
    },
    {
      name: 'Eng. Ricardo Silveira',
      role: 'Professor UNIFEI',
      text: 'Excelente consultoria na compra de um sítio na Serra da Mantiqueira. A equipe da JHS conhece cada palmo da região e nos orientou com muita paciência e ética.',
      location: 'Piranguinho / Itajubá'
    }
  ];

  return (
    <section className="py-16 bg-white border-t border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        {/* Section Header */}
        <div className="max-w-3xl mx-auto text-center mb-16">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-50 border border-amber-200 text-amber-800 text-xs font-semibold mb-3">
            <Award className="w-3.5 h-3.5 text-amber-600" />
            <span>Tradição, Segurança e Ética no Sul de Minas</span>
          </div>

          <h2 className="font-heading text-3xl sm:text-4xl font-extrabold text-[#0B2545] tracking-tight">
            Sobre a JHS Imobiliária
          </h2>

          <p className="mt-4 text-base text-slate-600 leading-relaxed">
            Consolidada no mercado imobiliário de Itajubá e região, a JHS Imobiliária oferece uma experiência completa e segura em transações imobiliárias, unindo conhecimento de mercado e assessoria jurídica integral.
          </p>
        </div>

        {/* 2-Column Presentation */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center mb-16">
          {/* Visual Presentation Card */}
          <div className="relative">
            <div className="rounded-2xl overflow-hidden bg-gradient-to-br from-[#0B2545] to-[#133E68] p-8 text-white shadow-xl relative">
              <div className="absolute top-0 right-0 w-64 h-64 bg-amber-500/10 rounded-full blur-2xl pointer-events-none" />

              <div className="flex items-center gap-3 mb-6">
                <div className="w-12 h-12 rounded-xl bg-amber-400 text-slate-950 flex items-center justify-center font-black text-xl font-heading shadow-md">
                  JHS
                </div>
                <div>
                  <h3 className="font-heading text-xl font-bold">JHS Imobiliária & Consultoria</h3>
                  <p className="text-xs text-amber-300 font-medium">CRECI-MG 24.891 · Registro Oficial</p>
                </div>
              </div>

              <p className="text-sm text-slate-200 leading-relaxed mb-6">
                Nossa missão é transformar a busca pelo imóvel ideal em uma jornada tranquila, clara e juridicamente respaldada. Atuamos fortemente na comercialização e locação de residências em bairros nobres, apartamentos próximos às faculdades e hospitais, imóveis comerciais e chácaras em toda a Serra da Mantiqueira.
              </p>

              <div className="grid grid-cols-2 gap-4 pt-6 border-t border-white/10 text-xs">
                <div>
                  <span className="block text-2xl font-black text-amber-400 font-heading">17+</span>
                  <span className="text-slate-300">Anos de experiência no Sul de Minas</span>
                </div>
                <div>
                  <span className="block text-2xl font-black text-amber-400 font-heading">1.200+</span>
                  <span className="text-slate-300">Contratos firmados com sucesso</span>
                </div>
              </div>
            </div>

            {/* Floating Trust Card */}
            <div className="mt-4 sm:absolute sm:-bottom-6 sm:-right-6 bg-white p-4 rounded-xl shadow-lg border border-slate-200 flex items-center gap-3 max-w-xs">
              <div className="w-10 h-10 rounded-lg bg-emerald-100 text-emerald-700 flex items-center justify-center shrink-0">
                <CheckCircle2 className="w-6 h-6" />
              </div>
              <div className="text-xs">
                <strong className="block text-slate-900 font-bold">Documentação 100% Auditada</strong>
                <span className="text-slate-500">Certidões e matrícula verificadas antes da assinatura</span>
              </div>
            </div>
          </div>

          {/* Pillars and Services */}
          <div className="space-y-6">
            <h3 className="font-heading text-2xl font-bold text-slate-900">
              Nossos Serviços Especializados
            </h3>

            <div className="space-y-4">
              <div className="flex items-start gap-3.5">
                <div className="w-9 h-9 rounded-lg bg-blue-50 text-[#0B2545] flex items-center justify-center shrink-0 mt-0.5 border border-blue-100">
                  <Building className="w-5 h-5 text-amber-600" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-slate-900">Venda e Locação Residencial & Comercial</h4>
                  <p className="text-xs text-slate-600 mt-0.5 leading-relaxed">
                    Divulgação direcionada, fotos profissionais, análise criteriosa de fichas cadastrais e garantias locatícias seguras.
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3.5">
                <div className="w-9 h-9 rounded-lg bg-blue-50 text-[#0B2545] flex items-center justify-center shrink-0 mt-0.5 border border-blue-100">
                  <Scale className="w-5 h-5 text-amber-600" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-slate-900">Assessoria Jurídica e Despachante</h4>
                  <p className="text-xs text-slate-600 mt-0.5 leading-relaxed">
                    Acompanhamento completo desde a elaboração da proposta, levantamento de certidões, escritura e registro no Cartório de Imóveis.
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3.5">
                <div className="w-9 h-9 rounded-lg bg-blue-50 text-[#0B2545] flex items-center justify-center shrink-0 mt-0.5 border border-blue-100">
                  <FileCheck2 className="w-5 h-5 text-amber-600" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-slate-900">Administração de Imóveis com Repasse Pontual</h4>
                  <p className="text-xs text-slate-600 mt-0.5 leading-relaxed">
                    Tranquilidade para o proprietário: controle rigoroso de pagamentos de condomínio, IPTU e manutenções preventivas.
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3.5">
                <div className="w-9 h-9 rounded-lg bg-blue-50 text-[#0B2545] flex items-center justify-center shrink-0 mt-0.5 border border-blue-100">
                  <Award className="w-5 h-5 text-amber-600" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-slate-900">Avaliação Mercadológica Técnica</h4>
                  <p className="text-xs text-slate-600 mt-0.5 leading-relaxed">
                    Precificação justa baseada no histórico real de transações e valorização de cada bairro de Itajubá.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Testimonials */}
        <div className="mt-16 pt-12 border-t border-slate-200">
          <div className="text-center max-w-xl mx-auto mb-10">
            <span className="text-xs font-bold text-amber-700 uppercase tracking-wider block mb-1">Depoimentos Reais</span>
            <h3 className="font-heading text-2xl font-bold text-[#0B2545]">
              A Palavra de Quem Confia na JHS
            </h3>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {testimonials.map((t, idx) => (
              <div key={idx} className="bg-slate-50 rounded-xl p-6 border border-slate-200/80 shadow-2xs flex flex-col justify-between">
                <p className="text-xs text-slate-700 leading-relaxed italic mb-4">
                  "{t.text}"
                </p>
                <div className="pt-3 border-t border-slate-200 flex items-center justify-between text-xs">
                  <div>
                    <span className="font-bold text-slate-900 block">{t.name}</span>
                    <span className="text-[11px] text-slate-500">{t.role}</span>
                  </div>
                  <span className="text-[10px] text-amber-700 font-semibold">{t.location}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Physical Office Contact Banner */}
        <div className="mt-16 bg-[#0B2545] rounded-2xl p-8 text-white flex flex-col lg:flex-row items-center justify-between gap-6 shadow-xl">
          <div className="space-y-2 text-center lg:text-left">
            <h3 className="font-heading text-xl sm:text-2xl font-bold">
              Venha tomar um café em nossa sede em Itajubá
            </h3>
            <p className="text-xs sm:text-sm text-slate-300 max-w-xl">
              Rua Oscar de Souza, 29 - Bairro São Vicente, Itajubá - MG · Estacionamento e atendimento com hora marcada.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3 shrink-0">
            <a
              href={generateDirectCallLink()}
              className="px-5 py-2.5 bg-white/10 hover:bg-white/20 text-white font-bold rounded-lg text-xs transition-colors flex items-center gap-2 border border-white/20"
            >
              <Phone className="w-4 h-4 text-amber-400" />
              <span>(35) 99743-5840</span>
            </a>

            <a
              href={generateWhatsAppLink()}
              target="_blank"
              rel="noopener noreferrer"
              className="px-6 py-2.5 bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold rounded-lg text-xs transition-colors flex items-center gap-2 shadow-md"
            >
              <MessageCircle className="w-4 h-4" />
              <span>Falar com o Corretor</span>
            </a>
          </div>
        </div>
      </div>
    </section>
  );
};
