import React from 'react';
import { 
  Instagram, 
  Facebook, 
  MapPin, 
  Phone, 
  Mail, 
  ShieldCheck,
  Building2
} from 'lucide-react';
import { useProperty } from '../context/PropertyContext';
import { JhsLogo } from './JhsLogo';

export const Footer: React.FC = () => {
  const { setCurrentView, setIsSubmitModalOpen } = useProperty();

  return (
    <footer className="bg-[#030E1C] text-white border-t border-[#09223D]">
      {/* Top Main Footer Information Bar directly matching screenshot */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6">
        <div className="flex flex-col md:flex-row items-center justify-between gap-4 text-xs text-slate-300">
          {/* Left: Social Media */}
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2">
              <a
                href="https://facebook.com"
                target="_blank"
                rel="noopener noreferrer"
                className="w-8 h-8 rounded-full bg-[#1877F2] text-white flex items-center justify-center hover:opacity-90 transition-opacity"
                title="Facebook JHS Imóveis"
              >
                <Facebook className="w-4 h-4 fill-current" />
              </a>
              <a
                href="https://instagram.com/jhsimoveis"
                target="_blank"
                rel="noopener noreferrer"
                className="w-8 h-8 rounded-full bg-gradient-to-tr from-[#f09433] via-[#e6683c] to-[#bc1888] text-white flex items-center justify-center hover:opacity-90 transition-opacity"
                title="Instagram @jhsimoveis"
              >
                <Instagram className="w-4 h-4" />
              </a>
            </div>
            <span className="font-semibold text-slate-300">
              Siga nossas redes sociais <strong className="text-white font-bold">@jhsimoveis</strong>
            </span>
          </div>

          {/* Center: Tagline */}
          <div className="hidden lg:flex items-center gap-4 text-slate-400">
            <span className="h-4 w-px bg-slate-700" />
            <span className="tracking-widest uppercase font-semibold text-[11px] text-amber-400">
              Confiança em cada negócio
            </span>
            <span className="h-4 w-px bg-slate-700" />
          </div>

          {/* Right: Address */}
          <div className="flex items-center gap-2 text-slate-300">
            <MapPin className="w-4 h-4 text-[#FF9E2C] shrink-0" />
            <span>
              Rua Oscar de Souza, 29 <span className="text-slate-500 mx-1">|</span> São Vicente - Itajubá/MG
            </span>
          </div>
        </div>
      </div>

      {/* Institutional Legal & Quick Links Ribbon */}
      <div className="border-t border-[#09223D] bg-[#020A14] py-4 text-[11px] text-slate-500">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 flex flex-col sm:flex-row items-center justify-between gap-3 text-center sm:text-left">
          <div>
            © {new Date().getFullYear()} JHS Corretor de Imóveis · CRECI-MG 24.891 · Todos os direitos reservados.
          </div>
          <div className="flex items-center gap-4">
            <button 
              onClick={() => { setCurrentView('search'); window.scrollTo({ top: 0, behavior: 'smooth' }); }}
              className="hover:text-slate-300 transition-colors"
            >
              Catálogo de Imóveis
            </button>
            <button 
              onClick={() => { setCurrentView('about'); window.scrollTo({ top: 0, behavior: 'smooth' }); }}
              className="hover:text-slate-300 transition-colors"
            >
              Sobre Nós
            </button>
            <button 
              onClick={() => setIsSubmitModalOpen(true)}
              className="hover:text-slate-300 transition-colors"
            >
              Anunciar Imóvel
            </button>
            <button 
              onClick={() => { setCurrentView('admin'); window.scrollTo({ top: 0, behavior: 'smooth' }); }}
              className="hover:text-amber-400 transition-colors text-amber-500 font-semibold"
            >
              Acesso Corretor
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
};
