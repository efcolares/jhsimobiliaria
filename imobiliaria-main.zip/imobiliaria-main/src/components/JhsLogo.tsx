import React from 'react';

interface JhsLogoProps {
  variant?: 'full' | 'compact' | 'hero';
  className?: string;
}

export const JhsLogo: React.FC<JhsLogoProps> = ({ variant = 'full', className = '' }) => {
  if (variant === 'hero') {
    return (
      <div className={`flex flex-col items-center select-none text-center ${className}`}>
        {/* Large Hero Stylized Winged Emblem */}
        <div className="relative flex items-center justify-center">
          <svg viewBox="0 0 360 180" className="w-72 sm:w-80 md:w-96 h-auto drop-shadow-2xl">
            <defs>
              {/* Cyan / Blue Left Wing Gradient */}
              <linearGradient id="leftWingGrad" x1="100%" y1="100%" x2="0%" y2="0%">
                <stop offset="0%" stopColor="#0284c7" />
                <stop offset="50%" stopColor="#06b6d4" />
                <stop offset="100%" stopColor="#38bdf8" />
              </linearGradient>

              {/* Orange / Gold / Red Right Wing Gradient */}
              <linearGradient id="rightWingGrad" x1="0%" y1="100%" x2="100%" y2="0%">
                <stop offset="0%" stopColor="#ea580c" />
                <stop offset="50%" stopColor="#f59e0b" />
                <stop offset="100%" stopColor="#fbbf24" />
              </linearGradient>

              {/* Golden 3D Text Gradient */}
              <linearGradient id="goldTextGrad" x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" stopColor="#fef08a" />
                <stop offset="25%" stopColor="#f59e0b" />
                <stop offset="60%" stopColor="#d97706" />
                <stop offset="100%" stopColor="#92400e" />
              </linearGradient>

              <filter id="goldBevel" x="-20%" y="-20%" width="140%" height="140%">
                <feDropShadow dx="0" dy="3" stdDeviation="3" floodColor="#000" floodOpacity="0.6" />
              </filter>
            </defs>

            {/* Left Wing (Cyan/Blue Feathered Curves) */}
            <g transform="translate(10, 5)">
              <path
                d="M 68 85 C 40 50, 15 20, 5 5 C 18 24, 38 48, 55 70 Z"
                fill="url(#leftWingGrad)"
                opacity="0.9"
              />
              <path
                d="M 72 88 C 45 55, 20 30, 15 15 C 32 38, 52 64, 68 80 Z"
                fill="url(#leftWingGrad)"
              />
              <path
                d="M 78 92 C 55 68, 30 46, 25 32 C 45 52, 65 74, 76 86 Z"
                fill="url(#leftWingGrad)"
              />
              <path
                d="M 85 96 C 65 80, 42 60, 38 50 C 58 68, 75 84, 82 92 Z"
                fill="url(#leftWingGrad)"
                opacity="0.85"
              />
            </g>

            {/* Right Wing (Orange/Gold/Red Feathered Curves) */}
            <g transform="translate(10, 5)">
              <path
                d="M 272 85 C 300 50, 325 20, 335 5 C 322 24, 302 48, 285 70 Z"
                fill="url(#rightWingGrad)"
                opacity="0.9"
              />
              <path
                d="M 268 88 C 295 55, 320 30, 325 15 C 308 38, 288 64, 272 80 Z"
                fill="url(#rightWingGrad)"
              />
              <path
                d="M 262 92 C 285 68, 310 46, 315 32 C 295 52, 275 74, 264 86 Z"
                fill="url(#rightWingGrad)"
              />
              <path
                d="M 255 96 C 275 80, 298 60, 302 50 C 282 68, 265 84, 258 92 Z"
                fill="url(#rightWingGrad)"
                opacity="0.85"
              />
            </g>

            {/* Center "JHS" Golden Letters */}
            <text
              x="170"
              y="102"
              textAnchor="middle"
              fill="url(#goldTextGrad)"
              fontSize="68"
              fontFamily="'Outfit', serif"
              fontWeight="900"
              letterSpacing="2"
              filter="url(#goldBevel)"
              stroke="#451a03"
              strokeWidth="1.5"
            >
              JHS
            </text>

            {/* Bottom Subtitle Texts */}
            <text
              x="170"
              y="130"
              textAnchor="middle"
              fill="#FFFFFF"
              fontSize="13"
              fontFamily="'Plus Jakarta Sans', sans-serif"
              fontWeight="800"
              letterSpacing="4"
            >
              CORRETOR DE IMÓVEIS
            </text>

            {/* Line separator with PERITO AVALIADOR */}
            <line x1="45" y1="145" x2="110" y2="145" stroke="#f59e0b" strokeWidth="1.5" />
            <text
              x="170"
              y="149"
              textAnchor="middle"
              fill="#f59e0b"
              fontSize="10"
              fontFamily="'Plus Jakarta Sans', sans-serif"
              fontWeight="700"
              letterSpacing="2.5"
            >
              PERITO AVALIADOR
            </text>
            <line x1="230" y1="145" x2="295" y2="145" stroke="#f59e0b" strokeWidth="1.5" />

            <text
              x="170"
              y="166"
              textAnchor="middle"
              fill="#cbd5e1"
              fontSize="8.5"
              fontFamily="'Plus Jakarta Sans', sans-serif"
              fontWeight="600"
              letterSpacing="2"
            >
              CONFIANÇA EM CADA NEGÓCIO
            </text>
          </svg>
        </div>
      </div>
    );
  }

  // Header / Standard Nav Variant
  return (
    <div className={`flex items-center gap-2.5 select-none ${className}`}>
      <svg viewBox="0 0 160 70" className="h-11 sm:h-12 w-auto">
        <defs>
          <linearGradient id="headerLeftWing" x1="100%" y1="100%" x2="0%" y2="0%">
            <stop offset="0%" stopColor="#0284c7" />
            <stop offset="100%" stopColor="#38bdf8" />
          </linearGradient>
          <linearGradient id="headerRightWing" x1="0%" y1="100%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="#ea580c" />
            <stop offset="100%" stopColor="#f59e0b" />
          </linearGradient>
          <linearGradient id="headerGoldText" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="#fef08a" />
            <stop offset="40%" stopColor="#f59e0b" />
            <stop offset="100%" stopColor="#b45309" />
          </linearGradient>
        </defs>

        {/* Left Wing Small */}
        <g>
          <path d="M 28 35 C 18 20, 8 8, 2 2 C 8 10, 16 20, 24 30 Z" fill="url(#headerLeftWing)" />
          <path d="M 30 38 C 20 25, 12 15, 8 8 C 16 18, 24 28, 28 34 Z" fill="url(#headerLeftWing)" />
          <path d="M 34 40 C 24 30, 15 22, 12 16 C 20 24, 28 32, 32 37 Z" fill="url(#headerLeftWing)" />
        </g>

        {/* Right Wing Small */}
        <g>
          <path d="M 132 35 C 142 20, 152 8, 158 2 C 152 10, 144 20, 136 30 Z" fill="url(#headerRightWing)" />
          <path d="M 130 38 C 140 25, 148 15, 152 8 C 144 18, 136 28, 132 34 Z" fill="url(#headerRightWing)" />
          <path d="M 126 40 C 136 30, 145 22, 148 16 C 140 24, 132 32, 128 37 Z" fill="url(#headerRightWing)" />
        </g>

        {/* JHS Letters */}
        <text
          x="80"
          y="41"
          textAnchor="middle"
          fill="url(#headerGoldText)"
          fontSize="32"
          fontFamily="'Outfit', serif"
          fontWeight="900"
          letterSpacing="1.5"
          stroke="#451a03"
          strokeWidth="0.8"
        >
          JHS
        </text>

        {/* Subtitle */}
        <text
          x="80"
          y="52"
          textAnchor="middle"
          fill="#FFFFFF"
          fontSize="6.5"
          fontFamily="'Plus Jakarta Sans', sans-serif"
          fontWeight="800"
          letterSpacing="2"
        >
          CORRETOR DE IMÓVEIS
        </text>

        <line x1="25" y1="58" x2="52" y2="58" stroke="#f59e0b" strokeWidth="0.8" />
        <text
          x="80"
          y="60"
          textAnchor="middle"
          fill="#f59e0b"
          fontSize="5"
          fontFamily="'Plus Jakarta Sans', sans-serif"
          fontWeight="700"
          letterSpacing="1.2"
        >
          PERITO AVALIADOR
        </text>
        <line x1="108" y1="58" x2="135" y2="58" stroke="#f59e0b" strokeWidth="0.8" />
      </svg>
    </div>
  );
};
