import React, { useState } from 'react';
import { X, Calendar, Clock, User, Phone, Mail, CheckCircle2, MessageCircle } from 'lucide-react';
import { useProperty } from '../context/PropertyContext';
import { generateWhatsAppLink } from '../utils/formatters';

export const ScheduleVisitModal: React.FC = () => {
  const { 
    isScheduleModalOpen, 
    setIsScheduleModalOpen, 
    schedulePropertyTarget,
    addLead
  } = useProperty();

  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [date, setDate] = useState('');
  const [period, setPeriod] = useState<'manha' | 'tarde'>('manha');
  const [visitType, setVisitType] = useState<'presencial' | 'video'>('presencial');
  const [notes, setNotes] = useState('');
  const [submitted, setSubmitted] = useState(false);

  if (!isScheduleModalOpen || !schedulePropertyTarget) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !phone) return;

    addLead({
      name,
      email,
      phone,
      propertyCode: schedulePropertyTarget.code,
      propertyTitle: schedulePropertyTarget.title,
      type: 'agendamento',
      preferredDate: date,
      preferredPeriod: period,
      message: `Agendamento de visita (${visitType === 'presencial' ? 'Presencial' : 'Vídeo/Tour Online'}). Data sugerida: ${date || 'A combinar'} (${period === 'manha' ? 'Período Manhã' : 'Período Tarde'}). Obs: ${notes || 'Nenhuma'}`
    });

    setSubmitted(true);
  };

  const handleClose = () => {
    setIsScheduleModalOpen(false);
    setSubmitted(false);
    setName('');
    setPhone('');
    setEmail('');
    setDate('');
    setNotes('');
  };

  const directWhatsMessage = `Olá, JHS Imobiliária! Gostaria de confirmar o agendamento de visita para o imóvel "${schedulePropertyTarget.title}" (Cód: ${schedulePropertyTarget.code}). Meu nome é ${name || 'Cliente'}.`;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-2xl max-w-lg w-full overflow-hidden border border-slate-200 animate-in fade-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 bg-slate-50">
          <div className="flex items-center gap-2">
            <Calendar className="w-5 h-5 text-amber-600" />
            <h3 className="font-heading text-lg font-bold text-slate-900">
              Agendar Visita com a JHS
            </h3>
          </div>
          <button
            onClick={handleClose}
            className="p-1 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-200 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6">
          {submitted ? (
            <div className="text-center py-6 space-y-4">
              <div className="w-14 h-14 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto">
                <CheckCircle2 className="w-8 h-8" />
              </div>
              <h4 className="font-heading text-xl font-bold text-slate-900">
                Solicitação de Visita Enviada!
              </h4>
              <p className="text-xs text-slate-600 leading-relaxed max-w-sm mx-auto">
                Obrigado, <strong className="text-slate-900">{name}</strong>! Nosso corretor responsável entrará em contato em instantes no telefone <strong className="text-slate-900">{phone}</strong> para confirmar a data e o horário.
              </p>

              <div className="pt-2 flex flex-col gap-2">
                <a
                  href={`https://wa.me/5535997435840?text=${encodeURIComponent(directWhatsMessage)}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full py-2.5 px-4 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-lg text-xs transition-colors flex items-center justify-center gap-2"
                >
                  <MessageCircle className="w-4 h-4" />
                  <span>Confirmar agora no WhatsApp</span>
                </a>
                <button
                  type="button"
                  onClick={handleClose}
                  className="w-full py-2 text-xs font-semibold text-slate-600 hover:text-slate-900"
                >
                  Fechar janela
                </button>
              </div>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              {/* Target Property Summary */}
              <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 text-xs">
                <span className="text-[10px] text-amber-700 font-bold uppercase tracking-wider block">Imóvel Selecionado:</span>
                <span className="font-bold text-slate-900 block truncate">{schedulePropertyTarget.title}</span>
                <span className="text-slate-500 font-mono">REF: {schedulePropertyTarget.code} · {schedulePropertyTarget.neighborhood}, {schedulePropertyTarget.city}</span>
              </div>

              {/* Visit Type */}
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setVisitType('presencial')}
                  className={`py-2 px-3 text-xs font-bold rounded-lg border text-center transition-all cursor-pointer ${
                    visitType === 'presencial'
                      ? 'bg-[#0B2545] text-white border-[#0B2545]'
                      : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                  }`}
                >
                  Visita Presencial
                </button>
                <button
                  type="button"
                  onClick={() => setVisitType('video')}
                  className={`py-2 px-3 text-xs font-bold rounded-lg border text-center transition-all cursor-pointer ${
                    visitType === 'video'
                      ? 'bg-[#0B2545] text-white border-[#0B2545]'
                      : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                  }`}
                >
                  Tour Online (Vídeo)
                </button>
              </div>

              {/* Name & Phone */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Seu Nome Completo *
                </label>
                <div className="relative">
                  <User className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={e => setName(e.target.value)}
                    placeholder="Ex: João da Silva"
                    className="w-full pl-9 pr-3 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    WhatsApp / Telefone *
                  </label>
                  <div className="relative">
                    <Phone className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                    <input
                      type="tel"
                      required
                      value={phone}
                      onChange={e => setPhone(e.target.value)}
                      placeholder="(35) 99999-9999"
                      className="w-full pl-9 pr-3 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 outline-none"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    E-mail (Opcional)
                  </label>
                  <div className="relative">
                    <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                    <input
                      type="email"
                      value={email}
                      onChange={e => setEmail(e.target.value)}
                      placeholder="seu@email.com"
                      className="w-full pl-9 pr-3 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 outline-none"
                    />
                  </div>
                </div>
              </div>

              {/* Date & Period */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Data Desejada
                  </label>
                  <input
                    type="date"
                    value={date}
                    onChange={e => setDate(e.target.value)}
                    className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Melhor Período
                  </label>
                  <select
                    value={period}
                    onChange={e => setPeriod(e.target.value as 'manha' | 'tarde')}
                    className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 outline-none bg-white"
                  >
                    <option value="manha">Manhã (08:30 - 12:00)</option>
                    <option value="tarde">Tarde (13:30 - 17:30)</option>
                  </select>
                </div>
              </div>

              {/* Notes */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Observações ou Dúvidas
                </label>
                <textarea
                  rows={2}
                  value={notes}
                  onChange={e => setNotes(e.target.value)}
                  placeholder="Alguma necessidade específica sobre o horário ou imóvel?"
                  className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 outline-none resize-none"
                />
              </div>

              <div className="pt-2">
                <button
                  type="submit"
                  className="w-full py-3 bg-[#0B2545] hover:bg-[#133E68] text-white font-bold rounded-lg text-sm shadow-md transition-all cursor-pointer"
                >
                  Solicitar Agendamento
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
