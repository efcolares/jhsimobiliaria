import React, { useState } from 'react';
import { 
  Menu, 
  X, 
  Phone, 
  MessageCircle,
  Building2,
  PlusCircle,
  Heart
} from 'lucide-react';
import { useProperty } from '../context/PropertyContext';
import { JhsLogo } from './JhsLogo';
import { generateWhatsAppLink } from '../utils/formatters';

export const Header: React.FC = () => {
  const { 
    currentView, 
    setCurrentView, 
    favorites, 
    updateFilter,
    setIsSubmitModalOpen,
    leads 
  } = useProperty();

  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const handleNav = (view: 'home' | 'search' | 'about' | 'favorites' | 'admin', purpose?: 'venda' | 'locacao') => {
    if (purpose) {
      updateFilter('purpose', purpose);
      setCurrentView('search');
    } else {
      setCurrentView(view);
    }
    setMobileMenuOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const newLeadsCount = leads.filter(l => l.status === 'novo').length;

  return (
    <header className="sticky top-0 z-50 bg-[#06182C] border-b border-[#0f2c4c] shadow-lg text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="flex items-center justify-between h-20 sm:h-22">
          {/* Logo Zone */}
          <button 
            onClick={() => handleNav('home')}
            className="flex items-center gap-2 group text-left focus:outline-none cursor-pointer"
            title="JHS Corretor de Imóveis - Início"
          >
            <JhsLogo variant="compact" />
          </button>

          {/* Desktop Navigation Links */}
          <nav className="hidden lg:flex items-center gap-8 text-xs font-bold tracking-wider uppercase">
            <button
              onClick={() => handleNav('home')}
              className={`transition-colors cursor-pointer ${
                currentView === 'home' ? 'text-[#38bdf8] border-b-2 border-[#38bdf8] pb-1' : 'text-slate-200 hover:text-white'
              }`}
            >
              Início
            </button>
            <button
              onClick={() => handleNav('search')}
              className={`transition-colors cursor-pointer ${
                currentView === 'search' ? 'text-[#38bdf8] border-b-2 border-[#38bdf8] pb-1' : 'text-slate-200 hover:text-white'
              }`}
            >
              Imóveis
            </button>
            <button
              onClick={() => handleNav('about')}
              className={`transition-colors cursor-pointer ${
                currentView === 'about' ? 'text-[#38bdf8] border-b-2 border-[#38bdf8] pb-1' : 'text-slate-200 hover:text-white'
              }`}
            >
              Sobre Nós
            </button>
            <button
              onClick={() => {
                updateFilter('code', '');
                updateFilter('type', 'todos');
                setCurrentView('about');
                setTimeout(() => {
                  const el = document.getElementById('avaliacoes-section');
                  if (el) el.scrollIntoView({ behavior: 'smooth' });
                }, 100);
              }}
              className="text-slate-200 hover:text-white transition-colors cursor-pointer"
            >
              Avaliações
            </button>
            <button
              onClick={() => {
                const el = document.getElementById('contato-bar');
                if (el) el.scrollIntoView({ behavior: 'smooth' });
                else handleNav('about');
              }}
              className="text-slate-200 hover:text-white transition-colors cursor-pointer"
            >
              Contato
            </button>
          </nav>

          {/* Action Button: FALE CONOSCO (Orange Pill) */}
          <div className="hidden sm:flex items-center gap-3">
            {/* Favorites Icon */}
            <button
              onClick={() => handleNav('favorites')}
              className="relative p-2 text-slate-300 hover:text-rose-400 transition-colors cursor-pointer"
              title="Meus Imóveis Favoritos"
            >
              <Heart className={`w-5 h-5 ${favorites.length > 0 ? 'fill-rose-500 text-rose-500' : ''}`} />
              {favorites.length > 0 && (
                <span className="absolute 0 top-0 right-0 w-4 h-4 bg-rose-600 text-white rounded-full text-[10px] font-bold flex items-center justify-center">
                  {favorites.length}
                </span>
              )}
            </button>

            {/* Gestão Corretor button */}
            <button
              onClick={() => handleNav('admin')}
              className="relative px-3 py-1.5 bg-[#0e294b] hover:bg-[#133765] text-slate-300 hover:text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer border border-[#1e4470]"
              title="Painel de Gestão"
            >
              <Building2 className="w-3.5 h-3.5 text-amber-400" />
              <span>Gestão</span>
              {newLeadsCount > 0 && (
                <span className="w-2 h-2 rounded-full bg-amber-400" />
              )}
            </button>

            {/* Orange Pill Fale Conosco Button */}
            <a
              href={generateWhatsAppLink()}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full bg-gradient-to-r from-[#FF7A00] to-[#FF5500] hover:from-[#FF8A1A] hover:to-[#FF661A] text-white font-bold text-xs tracking-wider uppercase shadow-lg shadow-orange-950/40 transition-transform active:scale-95 cursor-pointer"
            >
              <Phone className="w-3.5 h-3.5 fill-current" />
              <span>Fale Conosco</span>
            </a>
          </div>

          {/* Mobile Hamburger */}
          <div className="flex items-center gap-2 lg:hidden">
            <a
              href={generateWhatsAppLink()}
              target="_blank"
              rel="noopener noreferrer"
              className="p-2 rounded-full bg-[#FF7A00] text-white"
            >
              <Phone className="w-4 h-4" />
            </a>

            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 text-slate-200 hover:text-white"
              aria-label="Abrir Menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-[#071F3D] border-t border-[#133765] px-4 py-6 space-y-3">
          <nav className="flex flex-col gap-2 text-sm font-bold uppercase tracking-wider text-slate-200">
            <button onClick={() => handleNav('home')} className="text-left py-2 px-3 rounded hover:bg-white/5">
              Início
            </button>
            <button onClick={() => handleNav('search')} className="text-left py-2 px-3 rounded hover:bg-white/5">
              Imóveis
            </button>
            <button onClick={() => handleNav('about')} className="text-left py-2 px-3 rounded hover:bg-white/5">
              Sobre Nós
            </button>
            <button 
              onClick={() => {
                handleNav('about');
                setTimeout(() => {
                  const el = document.getElementById('avaliacoes-section');
                  if (el) el.scrollIntoView({ behavior: 'smooth' });
                }, 100);
              }} 
              className="text-left py-2 px-3 rounded hover:bg-white/5"
            >
              Avaliações
            </button>
            <button 
              onClick={() => {
                const el = document.getElementById('contato-bar');
                if (el) el.scrollIntoView({ behavior: 'smooth' });
                setMobileMenuOpen(false);
              }} 
              className="text-left py-2 px-3 rounded hover:bg-white/5"
            >
              Contato
            </button>
            <button onClick={() => handleNav('favorites')} className="text-left py-2 px-3 rounded hover:bg-white/5 flex items-center justify-between">
              <span>Favoritos</span>
              <span className="text-xs bg-rose-600 text-white px-2 py-0.5 rounded-full">{favorites.length}</span>
            </button>
            <button onClick={() => handleNav('admin')} className="text-left py-2 px-3 rounded bg-[#0A274E] text-amber-400 flex items-center gap-2">
              <Building2 className="w-4 h-4" />
              Painel de Gestão JHS
            </button>
          </nav>

          <div className="pt-4 border-t border-[#133765] space-y-2">
            <button
              onClick={() => { setIsSubmitModalOpen(true); setMobileMenuOpen(false); }}
              className="w-full py-2.5 px-4 bg-white/10 hover:bg-white/20 text-white font-bold rounded-lg text-xs flex items-center justify-center gap-2"
            >
              <PlusCircle className="w-4 h-4 text-amber-400" />
              Anunciar Meu Imóvel
            </button>
            <a
              href={generateWhatsAppLink()}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full py-2.5 px-4 bg-gradient-to-r from-[#FF7A00] to-[#FF5500] text-white font-bold rounded-lg text-xs flex items-center justify-center gap-2 uppercase tracking-wider"
            >
              <MessageCircle className="w-4 h-4" />
              Fale Conosco no WhatsApp
            </a>
          </div>
        </div>
      )}
    </header>
  );
};
