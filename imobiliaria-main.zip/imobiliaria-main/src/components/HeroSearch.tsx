import React from 'react';
import { 
  Search, 
  Home, 
  BarChart3, 
  Users
} from 'lucide-react';
import { useProperty } from '../context/PropertyContext';
import { JhsLogo } from './JhsLogo';
import { CITIES_LIST, NEIGHBORHOODS_LIST, PROPERTY_TYPES_LABELS } from '../data/mockProperties';
import { HERO_WATERFRONT_ILLUSTRATION } from '../utils/illustrationAssets';

export const HeroSearch: React.FC = () => {
  const { filters, updateFilter, setCurrentView } = useProperty();

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setCurrentView('search');
    window.scrollTo({ top: 400, behavior: 'smooth' });
  };

  return (
    <div className="relative bg-[#06182C] text-white overflow-hidden">
      {/* Background with Dusk Waterfront & Street Lamp visual feel */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden select-none">
        <img
          src={HERO_WATERFRONT_ILLUSTRATION}
          alt="JHS Imóveis Panorama Noturno Orla Itajubá"
          className="w-full h-full object-cover object-bottom opacity-75"
        />
        {/* Soft gradient overlay for text readability on left */}
        <div className="absolute inset-0 bg-gradient-to-r from-[#06182C]/95 via-[#06182C]/75 to-transparent" />
        <div className="absolute inset-0 bg-gradient-to-t from-[#06182C] via-transparent to-[#06182C]/60" />
      </div>

      {/* Main Hero Content Area */}
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 pt-10 pb-16 lg:pt-14 lg:pb-20">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          {/* Left Column: Headings and Features */}
          <div className="lg:col-span-7 space-y-6 text-left">
            <span className="inline-block text-xs sm:text-sm font-black text-[#FF9E2C] tracking-widest uppercase">
              SEU NOVO LAR ESTÁ AQUI
            </span>

            <h1 className="font-heading text-3xl sm:text-4xl lg:text-5xl font-black text-white leading-tight tracking-tight">
              Encontre o imóvel <br className="hidden sm:inline" />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#FFB800] via-[#FF8A00] to-[#FF6B00]">
                ideal para você!
              </span>
            </h1>

            <p className="text-slate-300 text-sm sm:text-base leading-relaxed max-w-xl font-normal">
              Casas, apartamentos, terrenos e muito mais. Com a experiência e credibilidade da JHS, você compra, vende ou aluga com segurança.
            </p>

            {/* 3 Icons Feature Row */}
            <div className="grid grid-cols-3 gap-3 sm:gap-6 pt-4 border-t border-white/10 max-w-xl">
              {/* Feature 1: VENDA */}
              <div className="space-y-1">
                <div className="flex items-center gap-1.5 text-[#FF9E2C]">
                  <Home className="w-5 h-5 text-[#FF9E2C]" />
                  <span className="font-heading font-black text-xs sm:text-sm tracking-wide text-white uppercase">
                    VENDA
                  </span>
                </div>
                <p className="text-[11px] sm:text-xs text-slate-400 leading-snug">
                  Seu imóvel no melhor negócio
                </p>
              </div>

              {/* Feature 2: AVALIAÇÕES */}
              <div className="space-y-1">
                <div className="flex items-center gap-1.5 text-[#FF9E2C]">
                  <BarChart3 className="w-5 h-5 text-[#FF9E2C]" />
                  <span className="font-heading font-black text-xs sm:text-sm tracking-wide text-white uppercase">
                    AVALIAÇÕES
                  </span>
                </div>
                <p className="text-[11px] sm:text-xs text-slate-400 leading-snug">
                  Laudos com precisão e credibilidade
                </p>
              </div>

              {/* Feature 3: ADMINISTRAÇÃO */}
              <div className="space-y-1">
                <div className="flex items-center gap-1.5 text-[#FF9E2C]">
                  <Users className="w-5 h-5 text-[#FF9E2C]" />
                  <span className="font-heading font-black text-xs sm:text-sm tracking-wide text-white uppercase">
                    ADMINISTRAÇÃO
                  </span>
                </div>
                <p className="text-[11px] sm:text-xs text-slate-400 leading-snug">
                  Seu patrimônio em boas mãos
                </p>
              </div>
            </div>
          </div>

          {/* Right Column: Prominent JHS Logo + Cursive Signature */}
          <div className="lg:col-span-5 flex flex-col items-center justify-center text-center py-4 lg:py-0">
            <JhsLogo variant="hero" />

            {/* Handwritten cursive script "Seu imóvel, novas histórias." */}
            <div className="mt-4 transform -rotate-3 select-none">
              <span 
                className="text-2xl sm:text-3xl text-amber-200/90 drop-shadow-md font-serif italic tracking-wide"
                style={{ fontFamily: "'Dancing Script', 'Playfair Display', cursive, serif" }}
              >
                Seu imóvel, novas histórias.
              </span>
            </div>
          </div>
        </div>

        {/* BUSQUE SEU IMÓVEL Search Bar Card */}
        <div className="mt-12 bg-[#071F3D] rounded-2xl shadow-2xl p-4 sm:p-5 border border-[#133765] max-w-6xl mx-auto">
          {/* Top Title with Search Icon */}
          <div className="flex items-center gap-2 pb-3 mb-1 text-white font-heading font-extrabold text-xs sm:text-sm uppercase tracking-wider">
            <Search className="w-4 h-4 text-[#FF9E2C]" />
            <span>BUSQUE SEU IMÓVEL</span>
          </div>

          {/* Inner White Container with 4 Selects + Orange Buscar Button */}
          <form onSubmit={handleSearchSubmit}>
            <div className="bg-white rounded-xl p-2 sm:p-2.5 shadow-inner flex flex-col lg:flex-row items-stretch gap-2 text-slate-800">
              {/* 1. Tipo de Imóvel */}
              <div className="flex-1 px-3 py-1.5 border-b lg:border-b-0 lg:border-r border-slate-200">
                <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-0.5">
                  Tipo de imóvel
                </label>
                <select
                  value={filters.type}
                  onChange={e => updateFilter('type', e.target.value)}
                  className="w-full bg-transparent text-xs sm:text-sm font-semibold text-slate-800 outline-none cursor-pointer"
                >
                  <option value="todos">Todos</option>
                  {Object.entries(PROPERTY_TYPES_LABELS).map(([k, v]) => (
                    <option key={k} value={k}>{v}</option>
                  ))}
                </select>
              </div>

              {/* 2. Cidade */}
              <div className="flex-1 px-3 py-1.5 border-b lg:border-b-0 lg:border-r border-slate-200">
                <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-0.5">
                  Cidade
                </label>
                <select
                  value={filters.city}
                  onChange={e => updateFilter('city', e.target.value)}
                  className="w-full bg-transparent text-xs sm:text-sm font-semibold text-slate-800 outline-none cursor-pointer"
                >
                  <option value="">Todas</option>
                  {CITIES_LIST.map(c => (
                    <option key={c} value={c}>{c}</option>
                  ))}
                </select>
              </div>

              {/* 3. Bairro */}
              <div className="flex-1 px-3 py-1.5 border-b lg:border-b-0 lg:border-r border-slate-200">
                <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-0.5">
                  Bairro
                </label>
                <select
                  value={filters.neighborhood}
                  onChange={e => updateFilter('neighborhood', e.target.value)}
                  className="w-full bg-transparent text-xs sm:text-sm font-semibold text-slate-800 outline-none cursor-pointer"
                >
                  <option value="">Todos</option>
                  {NEIGHBORHOODS_LIST.map(n => (
                    <option key={n} value={n}>{n}</option>
                  ))}
                </select>
              </div>

              {/* 4. Faixa de Preço */}
              <div className="flex-1 px-3 py-1.5">
                <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-0.5">
                  Faixa de preço
                </label>
                <select
                  value={
                    filters.maxPrice === 200000 ? '200k' :
                    filters.maxPrice === 400000 ? '400k' :
                    filters.maxPrice === 800000 ? '800k' :
                    filters.maxPrice === 1500000 ? '1.5m' : 'todos'
                  }
                  onChange={e => {
                    const v = e.target.value;
                    if (v === '200k') updateFilter('maxPrice', 200000);
                    else if (v === '400k') updateFilter('maxPrice', 400000);
                    else if (v === '800k') updateFilter('maxPrice', 800000);
                    else if (v === '1.5m') updateFilter('maxPrice', 1500000);
                    else updateFilter('maxPrice', null);
                  }}
                  className="w-full bg-transparent text-xs sm:text-sm font-semibold text-slate-800 outline-none cursor-pointer"
                >
                  <option value="todos">Todos</option>
                  <option value="200k">Até R$ 200.000</option>
                  <option value="400k">Até R$ 400.000</option>
                  <option value="800k">Até R$ 800.000</option>
                  <option value="1.5m">Até R$ 1.500.000</option>
                </select>
              </div>

              {/* 5. Orange BUSCAR Button */}
              <button
                type="submit"
                className="px-8 py-3.5 bg-gradient-to-r from-[#FF7A00] to-[#FF5500] hover:from-[#FF8A1A] hover:to-[#FF661A] text-white font-heading font-black text-xs sm:text-sm tracking-wider uppercase rounded-lg shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer shrink-0"
              >
                <Search className="w-4 h-4 stroke-[3]" />
                <span>BUSCAR</span>
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};
