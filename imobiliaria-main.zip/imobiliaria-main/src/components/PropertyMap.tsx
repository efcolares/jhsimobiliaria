import React from 'react';
import { MapPin, Navigation, School, Hospital, ShoppingBag, TreePine } from 'lucide-react';
import { Property } from '../types/property';

interface PropertyMapProps {
  property: Property;
}

export const PropertyMap: React.FC<PropertyMapProps> = ({ property }) => {
  const nearbyPoints = [
    { name: 'Centro Comercial de Itajubá', type: 'shopping', distance: '1.2 km', icon: ShoppingBag },
    { name: 'Faculdade de Medicina (FMIt)', type: 'education', distance: '1.8 km', icon: School },
    { name: 'Universidade Federal (UNIFEI)', type: 'education', distance: '2.5 km', icon: School },
    { name: 'Hospital das Clínicas de Itajubá', type: 'health', distance: '1.4 km', icon: Hospital },
    { name: 'Parque Ecológico da Mantiqueira', type: 'park', distance: '3.0 km', icon: TreePine },
  ];

  const fullAddress = property.address 
    ? `${property.address}, ${property.neighborhood}, ${property.city} - ${property.state}`
    : `${property.neighborhood}, ${property.city} - ${property.state}`;

  return (
    <div className="bg-white rounded-2xl border border-slate-200 p-6 space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-100">
        <div>
          <h3 className="font-heading text-lg font-bold text-slate-900 flex items-center gap-2">
            <MapPin className="w-5 h-5 text-amber-600" />
            Localização e Entorno
          </h3>
          <p className="text-xs text-slate-500 mt-0.5">
            {fullAddress}
          </p>
        </div>

        <a
          href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(fullAddress)}`}
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex items-center gap-2 px-3.5 py-2 text-xs font-bold text-[#0B2545] bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors"
        >
          <Navigation className="w-3.5 h-3.5 text-amber-600" />
          <span>Abrir no Google Maps</span>
        </a>
      </div>

      {/* Stylized Visual Map Representation */}
      <div className="relative aspect-16/8 sm:aspect-16/7 w-full rounded-xl overflow-hidden bg-slate-900 border border-slate-200 shadow-inner">
        {/* Vector Schematic Map of Itajubá Valley */}
        <svg className="w-full h-full" viewBox="0 0 800 350" preserveAspectRatio="none">
          <defs>
            <linearGradient id="mapBg" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stop-color="#0f172a" />
              <stop offset="100%" stop-color="#1e293b" />
            </linearGradient>
            <linearGradient id="river" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stop-color="#0284c7" />
              <stop offset="100%" stop-color="#0369a1" />
            </linearGradient>
          </defs>

          <rect width="100%" height="100%" fill="url(#mapBg)" />

          {/* Grid lines */}
          <g stroke="rgba(255,255,255,0.06)" strokeWidth="1">
            <line x1="100" y1="0" x2="100" y2="350" />
            <line x1="200" y1="0" x2="200" y2="350" />
            <line x1="300" y1="0" x2="300" y2="350" />
            <line x1="400" y1="0" x2="400" y2="350" />
            <line x1="500" y1="0" x2="500" y2="350" />
            <line x1="600" y1="0" x2="600" y2="350" />
            <line x1="700" y1="0" x2="700" y2="350" />
            <line x1="0" y1="70" x2="800" y2="70" />
            <line x1="0" y1="140" x2="800" y2="140" />
            <line x1="0" y1="210" x2="800" y2="210" />
            <line x1="0" y1="280" x2="800" y2="280" />
          </g>

          {/* Rio Sapucaí curving across Itajubá */}
          <path
            d="M 0 160 Q 200 120 400 180 T 800 140"
            fill="none"
            stroke="url(#river)"
            strokeWidth="14"
            opacity="0.7"
          />
          <text x="710" y="125" fill="#38bdf8" fontSize="11" fontFamily="'Plus Jakarta Sans', sans-serif" fontWeight="600" opacity="0.6">
            Rio Sapucaí
          </text>

          {/* Roads & Avenues */}
          <path d="M 150 0 L 150 350" stroke="#475569" strokeWidth="4" />
          <path d="M 0 240 L 800 240" stroke="#475569" strokeWidth="4" />
          <path d="M 280 40 L 680 320" stroke="#334155" strokeWidth="3" strokeDasharray="6,4" />
          <path d="M 0 80 Q 300 100 500 0" stroke="#334155" strokeWidth="3" />

          {/* Nearby District Labels */}
          <text x="180" y="55" fill="#94a3b8" fontSize="12" fontWeight="bold">MORRO CHIC</text>
          <text x="320" y="270" fill="#94a3b8" fontSize="12" fontWeight="bold">CENTRO HISTÓRICO</text>
          <text x="560" y="90" fill="#94a3b8" fontSize="12" fontWeight="bold">SÃO VICENTE</text>
          <text x="480" y="320" fill="#94a3b8" fontSize="12" fontWeight="bold">VARGINHA / MEDICINA</text>

          {/* Property Pin */}
          <g transform="translate(420, 140)">
            {/* Pulsing ring */}
            <circle cx="0" cy="0" r="28" fill="rgba(201,154,62,0.25)" className="animate-ping" />
            <circle cx="0" cy="0" r="14" fill="#C99A3E" stroke="#ffffff" strokeWidth="3" />
            <circle cx="0" cy="0" r="5" fill="#0B2545" />

            {/* Tooltip Card */}
            <rect x="-90" y="-65" width="180" height="42" rx="8" fill="#0B2545" stroke="#C99A3E" strokeWidth="1.5" />
            <text x="0" y="-46" fill="#F8FAFC" fontSize="12" fontWeight="bold" textAnchor="middle" fontFamily="'Outfit', sans-serif">
              {property.neighborhood}
            </text>
            <text x="0" y="-30" fill="#C99A3E" fontSize="10" fontWeight="600" textAnchor="middle" fontFamily="'Plus Jakarta Sans', sans-serif">
              IMÓVEL LOCALIZADO
            </text>
            {/* Tooltip triangle */}
            <polygon points="-6,-23 6,-23 0,-16" fill="#0B2545" />
          </g>
        </svg>

        <div className="absolute bottom-2.5 left-3 text-[11px] bg-slate-950/80 backdrop-blur-xs text-slate-300 px-2.5 py-1 rounded border border-slate-700 font-medium">
          Região de {property.neighborhood} · {property.city} - MG
        </div>
      </div>

      {/* Nearby Points of Interest */}
      <div>
        <h4 className="text-xs font-bold text-slate-700 uppercase tracking-wider mb-3">
          Proximidades e Facilidades
        </h4>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {nearbyPoints.map((item, idx) => {
            const Icon = item.icon;
            return (
              <div
                key={idx}
                className="flex items-center justify-between p-3 rounded-xl bg-slate-50 border border-slate-200/80 text-xs"
              >
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-lg bg-white border border-slate-200 flex items-center justify-center text-slate-600">
                    <Icon className="w-4 h-4 text-amber-600" />
                  </div>
                  <span className="font-semibold text-slate-800">{item.name}</span>
                </div>
                <span className="font-bold text-[#0B2545] font-mono tabular-nums">{item.distance}</span>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
