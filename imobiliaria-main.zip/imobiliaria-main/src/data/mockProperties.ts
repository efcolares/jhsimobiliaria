import { Property } from '../types/property';
import { 
  CASA_NO_CENTRO_ILLUSTRATION, 
  APARTAMENTO_ILLUSTRATION, 
  CASA_TEMPORADA_ILLUSTRATION, 
  TERRENO_ILLUSTRATION 
} from '../utils/illustrationAssets';

// Helper to create resilient, high-aesthetic architectural SVG image data URLs
export function createArchitecturalImage(
  title: string,
  type: string,
  theme: 'modern_house' | 'luxury_apt' | 'penthouse' | 'chacara' | 'commercial' | 'terreno' | 'kitchen' | 'bedroom' | 'pool' | 'suite'
): string {
  const configs = {
    modern_house: {
      bg: 'linear-gradient(135deg, #0f2b48 0%, #1a365d 40%, #2b6cb0 100%)',
      sky: '#3182ce',
      accent: '#ecc94b',
      label: 'Fachada Contemporânea',
      icon: 'M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6'
    },
    luxury_apt: {
      bg: 'linear-gradient(135deg, #1e293b 0%, #334155 50%, #475569 100%)',
      sky: '#64748b',
      accent: '#38bdf8',
      label: 'Living Integrado & Varanda',
      icon: 'M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4'
    },
    penthouse: {
      bg: 'linear-gradient(135deg, #1e1b4b 0%, #312e81 40%, #4338ca 100%)',
      sky: '#818cf8',
      accent: '#fbbf24',
      label: 'Terraço Panorâmico Exclusivo',
      icon: 'M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z'
    },
    chacara: {
      bg: 'linear-gradient(135deg, #064e3b 0%, #065f46 45%, #047857 100%)',
      sky: '#34d399',
      accent: '#fef08a',
      label: 'Área Verde & Vista Mantiqueira',
      icon: 'M3.055 11H5a2 2 0 012 2v1a2 2 0 002 2 2 2 0 012 2v2.945M8 3.935V5.5A2.5 2.5 0 0010.5 8h.5a2 2 0 012 2 2 2 0 104 0 2 2 0 012-2h1.064M15 20.488V18a2 2 0 012-2h3.064'
    },
    commercial: {
      bg: 'linear-gradient(135deg, #0f172a 0%, #1e293b 50%, #0369a1 100%)',
      sky: '#0284c7',
      accent: '#38bdf8',
      label: 'Espaço Corporativo Prime',
      icon: 'M21 13.255A23.931 23.931 0 0112 15c-3.183 0-6.22-.62-9-1.745M16 6V4a2 2 0 00-2-2h-4a2 2 0 00-2 2v2m4 6h.01M5 20h14a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z'
    },
    terreno: {
      bg: 'linear-gradient(135deg, #1c1917 0%, #292524 50%, #44403c 100%)',
      sky: '#78716c',
      accent: '#eab308',
      label: 'Lote Plano & Topografia Privilegiada',
      icon: 'M9 20l-5.447-2.724A1 1 0 013 16.382V5.618a1 1 0 011.447-.894L9 7m0 13l6-3m-6 3V7m6 10l4.553 2.276A1 1 0 0021 18.382V7.618a1 1 0 00-.553-.894L15 4m0 13V4m0 0L9 7'
    },
    kitchen: {
      bg: 'linear-gradient(135deg, #18181b 0%, #27272a 50%, #3f3f46 100%)',
      sky: '#71717a',
      accent: '#fb923c',
      label: 'Cozinha Gourmet Planejada',
      icon: 'M4 6h16M4 10h16M4 14h16M4 18h16'
    },
    bedroom: {
      bg: 'linear-gradient(135deg, #1e1b4b 0%, #2e1065 50%, #3b0764 100%)',
      sky: '#a855f7',
      accent: '#e9d5ff',
      label: 'Suíte Master Confort',
      icon: 'M20 12V8H6a2 2 0 00-2 2v12m16-10H4m16 0a2 2 0 012 2v6a2 2 0 01-2 2H4'
    },
    pool: {
      bg: 'linear-gradient(135deg, #083344 0%, #155e75 50%, #0e7490 100%)',
      sky: '#38bdf8',
      accent: '#67e8f9',
      label: 'Piscina & Solarium',
      icon: 'M12 3v1m0 16v1m9-9h-1M4 12H3m15.364 6.364l-.707-.707M6.343 6.343l-.707-.707m12.728 0l-.707.707M6.343 17.657l-.707.707M16 12a4 4 0 11-8 0 4 4 0 018 0z'
    },
    suite: {
      bg: 'linear-gradient(135deg, #0f172a 0%, #334155 60%, #1e293b 100%)',
      sky: '#94a3b8',
      accent: '#cbd5e1',
      label: 'Acabamentos de Alto Padrão',
      icon: 'M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z'
    }
  };

  const c = configs[theme] || configs.modern_house;

  const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1200 800" width="100%" height="100%">
    <defs>
      <linearGradient id="g_${theme}" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stop-color="#091b2c" />
        <stop offset="50%" stop-color="#143454" />
        <stop offset="100%" stop-color="#0a1827" />
      </linearGradient>
      <linearGradient id="overlay" x1="0%" y1="0%" x2="0%" y2="100%">
        <stop offset="0%" stop-color="rgba(0,0,0,0.15)" />
        <stop offset="60%" stop-color="rgba(0,0,0,0.3)" />
        <stop offset="100%" stop-color="rgba(6,18,31,0.95)" />
      </linearGradient>
      <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
        <path d="M 40 0 L 0 0 0 40" fill="none" stroke="rgba(255,255,255,0.04)" stroke-width="1"/>
      </pattern>
    </defs>
    
    <rect width="100%" height="100%" fill="url(#g_${theme})" />
    <rect width="100%" height="100%" fill="url(#grid)" />
    
    <!-- Architectural lines -->
    <g opacity="0.3" stroke="${c.sky}" stroke-width="1.5" fill="none">
      <path d="M 100 650 L 350 250 L 850 250 L 1100 650 Z" />
      <path d="M 350 250 L 350 650" />
      <path d="M 850 250 L 850 650" />
      <path d="M 225 450 L 975 450" />
      <path d="M 150 550 L 1050 550" />
      <circle cx="600" cy="350" r="180" stroke="${c.accent}" stroke-dasharray="6,6" opacity="0.4" />
    </g>

    <!-- Warm interior glow effect -->
    <ellipse cx="600" cy="500" rx="360" ry="180" fill="rgba(201,154,62,0.12)" filter="blur(40px)" />

    <rect width="100%" height="100%" fill="url(#overlay)" />

    <!-- Brand Watermark Crest -->
    <g transform="translate(60, 60)">
      <rect x="0" y="0" width="110" height="38" rx="6" fill="#0B2545" stroke="#C99A3E" stroke-width="1.5" />
      <text x="55" y="24" fill="#C99A3E" font-family="'Outfit', sans-serif" font-weight="700" font-size="16" letter-spacing="2" text-anchor="middle">JHS</text>
    </g>

    <!-- Center Icon & Presentation -->
    <g transform="translate(600, 340)" text-anchor="middle">
      <circle cx="0" cy="0" r="54" fill="rgba(11,37,69,0.85)" stroke="#C99A3E" stroke-width="2" />
      <g transform="translate(-24, -24)" stroke="#C99A3E" fill="none" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <path d="${c.icon}" />
      </g>
      <text x="0" y="90" fill="#F8FAFC" font-family="'Outfit', sans-serif" font-weight="700" font-size="28" letter-spacing="1">
        ${title}
      </text>
      <text x="0" y="125" fill="#94A3B8" font-family="'Plus Jakarta Sans', sans-serif" font-size="17" font-weight="500">
        ${c.label} · ${type.toUpperCase()}
      </text>
    </g>

    <!-- Bottom Footer Bar in Image -->
    <rect x="0" y="740" width="1200" height="60" fill="rgba(11,37,69,0.9)" />
    <text x="60" y="776" fill="#94A3B8" font-family="'Plus Jakarta Sans', sans-serif" font-size="14" font-weight="500">
      JHS IMOBILIÁRIA · CRECI-MG · ITAJUBÁ E REGIÃO
    </text>
    <text x="1140" y="776" fill="#C99A3E" font-family="'Outfit', sans-serif" font-size="14" font-weight="600" text-anchor="end">
      FOTOGRAFIA & CADASTRO OFICIAL
    </text>
  </svg>`;

  return `data:image/svg+xml;charset=utf-8,${encodeURIComponent(svg)}`;
}

export const INITIAL_PROPERTIES: Property[] = [
  {
    id: 'prop-1',
    code: 'JHS-101',
    title: 'Casa no Centro',
    slug: 'casa-no-centro-itajuba',
    type: 'casa',
    purpose: 'venda',
    price: 650000,
    condoFee: 0,
    iptu: 1200,
    city: 'Itajubá',
    state: 'MG',
    neighborhood: 'Centro',
    address: 'Rua Coronel Rennó, Centro',
    zipCode: '37500-000',
    bedrooms: 3,
    suites: 1,
    bathrooms: 2,
    garages: 2,
    totalArea: 240,
    builtArea: 180,
    description: 'Excelente casa no Centro de Itajubá com 3 quartos, sala ampla para dois ambientes, cozinha planejada, quintal com espaço gourmet e 2 vagas de garagem. Localização privilegiada com fácil acesso a escolas, bancos e comércio.',
    features: [
      'Espaço Gourmet com Churrasqueira',
      'Quintal Privativo',
      'Garagem Coberta para 2 Carros',
      'Armários Planejados na Cozinha',
      'Localização Central Privilegiada'
    ],
    images: [
      CASA_NO_CENTRO_ILLUSTRATION,
      'https://images.unsplash.com/photo-1568605117036-5fe5e7bab0b7?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1512917774080-9991f1c4c750?auto=format&fit=crop&w=800&q=80'
    ],
    badge: 'destaque',
    status: 'disponivel',
    isFeatured: true,
    createdAt: '2026-03-01',
    agent: {
      name: 'José Hélio',
      creci: 'CRECI MGF 11.606',
      phone: '(35) 99104-2131',
      whatsapp: '5535991042131',
      email: 'josehelio@jhsimobiliaria.com.br'
    }
  },
  {
    id: 'prop-2',
    code: 'JHS-102',
    title: 'Apartamento',
    slug: 'apartamento-centro-itajuba',
    type: 'apartamento',
    purpose: 'venda',
    price: 320000,
    condoFee: 280,
    iptu: 650,
    city: 'Itajubá',
    state: 'MG',
    neighborhood: 'Centro',
    address: 'Av. Cesário Alvim, Centro',
    zipCode: '37500-010',
    bedrooms: 2,
    suites: 0,
    bathrooms: 1,
    garages: 1,
    totalArea: 75,
    builtArea: 70,
    description: 'Belo apartamento em ótima localização em Itajubá. Composto por 2 dormitórios arejados, sala de estar com sacada, cozinha com bancada em granito, área de serviço e 1 vaga de garagem coberta. Edifício seguro e tranquilo.',
    features: [
      'Sacada com Vista Livre',
      'Cozinha com Bancada em Granito',
      'Portão Eletrônico e Interfone',
      '1 Vaga de Garagem Coberta',
      'Próximo a Universidades e Hospitais'
    ],
    images: [
      APARTAMENTO_ILLUSTRATION,
      'https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1502672260266-1c1ef2d93688?auto=format&fit=crop&w=800&q=80'
    ],
    badge: 'destaque',
    status: 'disponivel',
    isFeatured: true,
    createdAt: '2026-03-02',
    agent: {
      name: 'Dayana',
      creci: 'CRECI MGF 30.881',
      phone: '(35) 99743-5840',
      whatsapp: '5535997435840',
      email: 'dayana@jhsimobiliaria.com.br'
    }
  },
  {
    id: 'prop-3',
    code: 'JHS-103',
    title: 'Casa de Temporada',
    slug: 'casa-de-temporada-itajuba',
    type: 'casa',
    purpose: 'locacao',
    price: 1500,
    condoFee: 0,
    iptu: 0,
    city: 'Itajubá',
    state: 'MG',
    neighborhood: 'Morro Chic',
    address: 'Rua das Palmeiras, Morro Chic',
    zipCode: '37500-115',
    bedrooms: 4,
    suites: 2,
    bathrooms: 3,
    garages: 3,
    totalArea: 420,
    builtArea: 260,
    description: 'Charmosa casa de temporada mobiliada com ampla piscina, espreguiçadeiras, área de churrasqueira completa, 4 quartos espaçosos, 3 banheiros e garagem para 3 carros. Excelente para lazer em família ou temporada na Serra da Mantiqueira.',
    features: [
      'Piscina Privativa com Solarium',
      'Área Gourmet com Churrasqueira',
      'Mobiliada e Equipada',
      '3 Vagas de Garagem',
      'Bairro Residencial Nobre'
    ],
    images: [
      CASA_TEMPORADA_ILLUSTRATION,
      'https://images.unsplash.com/photo-1580587771525-78b9dba3b914?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1576013551627-0cc20b96c2a7?auto=format&fit=crop&w=800&q=80'
    ],
    badge: 'destaque',
    status: 'disponivel',
    isFeatured: true,
    createdAt: '2026-03-03',
    agent: {
      name: 'José Hélio',
      creci: 'CRECI MGF 11.606',
      phone: '(35) 99104-2131',
      whatsapp: '5535991042131',
      email: 'josehelio@jhsimobiliaria.com.br'
    }
  },
  {
    id: 'prop-4',
    code: 'JHS-104',
    title: 'Terreno',
    slug: 'terreno-itajuba-mg',
    type: 'terreno',
    purpose: 'venda',
    price: 180000,
    condoFee: 0,
    iptu: 450,
    city: 'Itajubá',
    state: 'MG',
    neighborhood: 'Pinheirinho',
    address: 'Loteamento Nova Itajubá',
    zipCode: '37502-200',
    bedrooms: 0,
    suites: 0,
    bathrooms: 0,
    garages: 0,
    totalArea: 360,
    builtArea: 0,
    description: 'Excelente terreno residencial com 360 m² (12x30m), topografia privilegiada com leve aclive, vista deslumbrante para as montanhas e documentação 100% regularizada com escritura e registro. Pronto para construir.',
    features: [
      'Área Total de 360 m²',
      'Topografia Excelente',
      'Escritura e Registro no CRI',
      'Água, Luz e Asfalto na Porta',
      'Vista Panorâmica da Serra'
    ],
    images: [
      TERRENO_ILLUSTRATION,
      'https://images.unsplash.com/photo-1500382017468-9049fed747ef?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=800&q=80'
    ],
    badge: 'oportunidade',
    status: 'disponivel',
    isFeatured: true,
    createdAt: '2026-03-04',
    agent: {
      name: 'Dayana',
      creci: 'CRECI MGF 30.881',
      phone: '(35) 99743-5840',
      whatsapp: '5535997435840',
      email: 'dayana@jhsimobiliaria.com.br'
    }
  },
  {
    id: 'prop-2',
    code: 'JHS-102',
    title: 'Apartamento de Luxo com Vista Panorâmica no Centro',
    slug: 'apartamento-luxo-vista-panoramica-centro-itajuba',
    type: 'apartamento',
    purpose: 'venda',
    price: 780000,
    condoFee: 620,
    iptu: 1450,
    city: 'Itajubá',
    state: 'MG',
    neighborhood: 'Centro',
    address: 'Av. Paulo Chiaradia, 180',
    zipCode: '37500-035',
    bedrooms: 3,
    suites: 1,
    bathrooms: 3,
    garages: 2,
    totalArea: 142,
    builtArea: 125,
    description: 'Apartamento impecável em localização privilegiada no centro de Itajubá, com fácil acesso ao comércio, bancos e escolas. Sala ampla para dois ambientes integrada à varanda gourmet envidraçada com cortina de vidro e churrasqueira a gás. Cozinha planejada repleta de armários de marcenaria de alta qualidade. Edifício moderno com 2 elevadores inteligentes, salão de festas decorado, academia completa e portaria presencial.',
    features: [
      'Varanda Gourmet Envidraçada',
      'Churrasqueira a Gás',
      'Móveis Planejados Florense',
      'Edifício com 2 Elevadores',
      'Academia Equipada',
      'Salão de Festas Climatizado',
      'Portaria 24 horas',
      '2 Vagas Livres e Cobertas'
    ],
    images: [
      createArchitecturalImage('Living & Varanda Panorâmica', 'Apartamento Centro', 'luxury_apt'),
      createArchitecturalImage('Cozinha Gourmet Planejada', 'Cozinha', 'kitchen'),
      createArchitecturalImage('Suíte com Armários Embutidos', 'Suíte', 'bedroom'),
      createArchitecturalImage('Varanda com Cortina de Vidro', 'Varanda', 'suite')
    ],
    badge: 'oportunidade',
    status: 'disponivel',
    isFeatured: true,
    createdAt: '2026-03-05',
    agent: {
      name: 'Equipe de Vendas JHS',
      creci: 'CRECI-MG 24.891',
      phone: '(35) 99743-5840',
      whatsapp: '5535997435840',
      email: 'contato@jhsimobiliaria.com.br'
    }
  },
  {
    id: 'prop-3',
    code: 'JHS-103',
    title: 'Cobertura Duplex Exclusiva com Ofurô e Terraço Privativo',
    slug: 'cobertura-duplex-exclusiva-morro-chic',
    type: 'cobertura',
    purpose: 'venda',
    price: 1290000,
    condoFee: 790,
    iptu: 2300,
    city: 'Itajubá',
    state: 'MG',
    neighborhood: 'Morro Chic',
    address: 'Rua São Paulo, Edifício Bellagio',
    zipCode: '37500-110',
    bedrooms: 3,
    suites: 3,
    bathrooms: 4,
    garages: 3,
    totalArea: 250,
    builtArea: 220,
    description: 'Uma verdadeira obra de arte no topo do Morro Chic. Cobertura duplex com vista 360° para as montanhas de Itajubá. Pavimento superior inteiramente dedicado ao lazer particular: terraço ensolarado com deck de madeira, ofurô para 6 pessoas, churrasqueira gourmet e sala íntima de TV. No pavimento inferior, 3 suítes amplas com persianas automatizadas, lavabo e cozinha americana.',
    features: [
      'Terraço Privativo com Ofurô',
      'Vista 360 Graus para Mantiqueira',
      '3 Suítes Independentes',
      '3 Vagas de Garagem Cobertas',
      'Persianas Elétricas Blackout',
      'Acabamento em Mármore Travertino',
      'Hall Privativo com Senha',
      'Depósito Individual no Subsolo'
    ],
    images: [
      createArchitecturalImage('Terraço & Ofurô Privativo', 'Cobertura Duplex', 'penthouse'),
      createArchitecturalImage('Living Duplo com Pé-direito', 'Living', 'luxury_apt'),
      createArchitecturalImage('Espaço Gourmet no Deck', 'Lazer Privativo', 'kitchen'),
      createArchitecturalImage('Suíte Principal com Closet', 'Suíte Master', 'bedroom')
    ],
    badge: 'lancamento',
    status: 'disponivel',
    isFeatured: true,
    createdAt: '2026-03-10',
    agent: {
      name: 'Equipe de Vendas JHS',
      creci: 'CRECI-MG 24.891',
      phone: '(35) 99743-5840',
      whatsapp: '5535997435840',
      email: 'contato@jhsimobiliaria.com.br'
    }
  },
  {
    id: 'prop-4',
    code: 'JHS-104',
    title: 'Apartamento Confortável para Locação próximo à Medicina (FMIt)',
    slug: 'apartamento-locacao-medicina-itajuba',
    type: 'apartamento',
    purpose: 'locacao',
    price: 2400,
    condoFee: 380,
    iptu: 110,
    city: 'Itajubá',
    state: 'MG',
    neighborhood: 'Varginha',
    address: 'Rua Renó Júnior, 320',
    zipCode: '37501-140',
    bedrooms: 2,
    suites: 1,
    bathrooms: 2,
    garages: 1,
    totalArea: 78,
    builtArea: 72,
    description: 'Excelente oportunidade para estudantes, médicos residentes e famílias! Apartamento muito arejado e iluminado, a poucos passos da Faculdade de Medicina de Itajubá (FMIt) e do Hospital das Clínicas. Conta com sala para 2 ambientes, sacada com vista aberta, quartos com armários embutidos, cozinha com gabinete planejado e área de serviço separada.',
    features: [
      'A 300m da Faculdade de Medicina (FMIt)',
      'Armários Embutidos nos Quartos',
      'Cozinha com Armários',
      'Gás Encanado Individual',
      'Vaga de Garagem Coberta',
      'Portão Eletrônico e Interfone',
      'Excelente Iluminação Natural'
    ],
    images: [
      createArchitecturalImage('Apartamento Conforto Próximo à FMIt', 'Apartamento Locação', 'luxury_apt'),
      createArchitecturalImage('Quarto Principal com Armários', 'Dormitório', 'bedroom'),
      createArchitecturalImage('Cozinha Funcional', 'Cozinha', 'kitchen'),
      createArchitecturalImage('Sacada com Vista Livre', 'Sacada', 'suite')
    ],
    badge: 'oportunidade',
    status: 'disponivel',
    isFeatured: true,
    createdAt: '2026-03-12',
    agent: {
      name: 'Locações JHS',
      creci: 'CRECI-MG 24.891',
      phone: '(35) 99743-5840',
      whatsapp: '5535997435840',
      email: 'locacao@jhsimobiliaria.com.br'
    }
  },
  {
    id: 'prop-5',
    code: 'JHS-105',
    title: 'Chácara Cinematográfica com Lago e Pomar em Piranguinho',
    slug: 'chacara-cinematografica-lago-pomar-piranguinho',
    type: 'chacara',
    purpose: 'venda',
    price: 950000,
    condoFee: 0,
    iptu: 650,
    city: 'Piranguinho',
    state: 'MG',
    neighborhood: 'Zona Rural / Santa Bárbara',
    address: 'Estrada Ecológica da Mantiqueira, Km 4',
    zipCode: '37508-000',
    bedrooms: 4,
    suites: 2,
    bathrooms: 4,
    garages: 6,
    totalArea: 5000,
    builtArea: 350,
    description: 'Paraíso na Serra da Mantiqueira a apenas 12 minutos do centro de Itajubá. Terreno de 5.000m² totalmente aproveitável com topografia suave, lago particular de peixes ornamentais e nascente de água cristalina. Sede em estilo rústico moderno com ampla varanda em toda a volta, fogão a lenha colonial com forno, piscina com quiosque, pomar produzindo diversas frutas e campo de futebol gramado.',
    features: [
      'Lago com Nascente Própria',
      'Piscina com Quiosque e Churrasqueira',
      'Fogão a Lenha e Forno de Pizza',
      'Pomar com Frutíferas e Horta Orgânica',
      'Campo de Futebol Society',
      'Casa de Caseiro Independente',
      'Internet Fibra Óptica Rural Instalada',
      'Totalmente Cercada e Gramada'
    ],
    images: [
      createArchitecturalImage('Sede Rústica & Lago de Peixes', 'Chácara Mantiqueira', 'chacara'),
      createArchitecturalImage('Área de Lazer com Piscina & Deck', 'Lazer Chácara', 'pool'),
      createArchitecturalImage('Cozinha Caipira com Fogão a Lenha', 'Cozinha Colonial', 'kitchen'),
      createArchitecturalImage('Vista Panorâmica da Serra', 'Natureza', 'terreno')
    ],
    badge: 'destaque',
    status: 'disponivel',
    isFeatured: true,
    createdAt: '2026-02-28',
    agent: {
      name: 'Equipe de Vendas JHS',
      creci: 'CRECI-MG 24.891',
      phone: '(35) 99743-5840',
      whatsapp: '5535997435840',
      email: 'contato@jhsimobiliaria.com.br'
    }
  },
  {
    id: 'prop-6',
    code: 'JHS-106',
    title: 'Casa Térrea Moderna em Bairro Nobre de Itajubá',
    slug: 'casa-terrea-moderna-sao-vicente-itajuba',
    type: 'casa',
    purpose: 'venda',
    price: 690000,
    condoFee: 0,
    iptu: 1200,
    city: 'Itajubá',
    state: 'MG',
    neighborhood: 'São Vicente',
    address: 'Rua Oscar de Souza, próximo à sede JHS',
    zipCode: '37502-012',
    bedrooms: 3,
    suites: 1,
    bathrooms: 2,
    garages: 2,
    totalArea: 250,
    builtArea: 165,
    description: 'Belíssima casa térrea, perfeita para quem busca acessibilidade, conforto e localização tradicional. Bairro tranquilo e seguro, próximo a supermercados, farmácias e serviços. Possui sala com teto rebaixado em gesso e iluminação em LED, jardim de inverno trazendo frescor e luz natural, cozinha espaçosa com bancada em granito São Gabriel e quintal privativo com churrasqueira.',
    features: [
      'Casa Térrea sem Degraus',
      'Jardim de Inverno Central',
      'Churrasqueira no Quintal',
      'Acabamento em Porcelanato Retificado',
      'Esquadrias em Alumínio Branco',
      'Portão Eletrônico com Interfone',
      'Garagem Coberta para 2 Carros'
    ],
    images: [
      createArchitecturalImage('Fachada Térrea Contemporânea', 'Casa São Vicente', 'modern_house'),
      createArchitecturalImage('Sala com Iluminação LED & Gesso', 'Sala de Estar', 'luxury_apt'),
      createArchitecturalImage('Cozinha com Granito São Gabriel', 'Cozinha', 'kitchen'),
      createArchitecturalImage('Espaço Gourmet no Quintal', 'Churrasqueira', 'suite')
    ],
    badge: 'nenhum',
    status: 'disponivel',
    isFeatured: false,
    createdAt: '2026-03-08',
    agent: {
      name: 'Equipe de Vendas JHS',
      creci: 'CRECI-MG 24.891',
      phone: '(35) 99743-5840',
      whatsapp: '5535997435840',
      email: 'contato@jhsimobiliaria.com.br'
    }
  },
  {
    id: 'prop-7',
    code: 'JHS-107',
    title: 'Sala Comercial Pronta para Consultório ou Escritório',
    slug: 'sala-comercial-consultorio-medicina-itajuba',
    type: 'comercial',
    purpose: 'locacao',
    price: 1800,
    condoFee: 320,
    iptu: 95,
    city: 'Itajubá',
    state: 'MG',
    neighborhood: 'Centro',
    address: 'Rua Cel. Francisco Braz, Centro Empresarial',
    zipCode: '37500-020',
    bedrooms: 0,
    suites: 0,
    bathrooms: 2,
    garages: 1,
    totalArea: 48,
    builtArea: 48,
    description: 'Imóvel corporativo ideal para médicos, dentistas, psicólogos, advogados ou consultorias. Sala dividida em recepção com lavabo para clientes, sala de atendimento principal com banheiro privativo e copa de apoio. Piso vinílico de alta resistência, ar-condicionado inverter instalado e fiação de rede estruturada. Prédio com recepção central, controle de acesso e 3 elevadores.',
    features: [
      'Recepção com Lavabo Próprio',
      'Ar-condicionado Inverter Instalado',
      'Prédio com Acessibilidade e Elevadores',
      'Controle de Acesso por Catraca',
      '1 Vaga Privativa no Edifício',
      'Copa com Bancada de Apoio'
    ],
    images: [
      createArchitecturalImage('Recepção & Consultório Executivo', 'Sala Comercial', 'commercial'),
      createArchitecturalImage('Sala de Atendimento Privativa', 'Atendimento', 'suite'),
      createArchitecturalImage('Copa Integrada', 'Copa', 'kitchen'),
      createArchitecturalImage('Hall de Entrada do Centro Empresarial', 'Prédio Comercial', 'commercial')
    ],
    badge: 'oportunidade',
    status: 'disponivel',
    isFeatured: false,
    createdAt: '2026-03-14',
    agent: {
      name: 'Locações Corporativas JHS',
      creci: 'CRECI-MG 24.891',
      phone: '(35) 99743-5840',
      whatsapp: '5535997435840',
      email: 'locacao@jhsimobiliaria.com.br'
    }
  },
  {
    id: 'prop-8',
    code: 'JHS-108',
    title: 'Terreno Plano em Condomínio Fechado Alto dos Pinheiros',
    slug: 'terreno-plano-condominio-alto-dos-pinheiros-itajuba',
    type: 'terreno',
    purpose: 'venda',
    price: 320000,
    condoFee: 290,
    iptu: 450,
    city: 'Itajubá',
    state: 'MG',
    neighborhood: 'Pinheirinho',
    address: 'Alameda das Araucárias, Lote 14 - Quadra B',
    zipCode: '37501-280',
    bedrooms: 0,
    suites: 0,
    bathrooms: 0,
    garages: 0,
    totalArea: 420,
    builtArea: 0,
    description: 'Excelente lote 100% plano com 14 metros de frente por 30 metros de profundidade, pronto para construir. Condomínio residencial consolidado com clube privativo contendo piscina, quadra de tênis de saibro, quadra poliesportiva, salão de festas e pista de cooper arborizada. Infraestrutura completa com asfalto, rede de água, esgoto e iluminação em LED.',
    features: [
      'Topografia 100% Plana',
      '14 metros de Frente',
      'Condomínio Fechado com Segurança 24h',
      'Quadra de Tênis em Saibro',
      'Piscina Coletiva Adulto e Infantil',
      'Pronto para Construir com Matrícula OK'
    ],
    images: [
      createArchitecturalImage('Lote Residencial Plano 420m²', 'Terreno em Condomínio', 'terreno'),
      createArchitecturalImage('Clube Privativo do Condomínio', 'Área de Lazer', 'pool'),
      createArchitecturalImage('Vista para a Serra dos Pinheiros', 'Topografia', 'chacara'),
      createArchitecturalImage('Portaria e Acesso Monitorado', 'Segurança', 'modern_house')
    ],
    badge: 'exclusivo',
    status: 'disponivel',
    isFeatured: true,
    createdAt: '2026-03-03',
    agent: {
      name: 'Equipe de Vendas JHS',
      creci: 'CRECI-MG 24.891',
      phone: '(35) 99743-5840',
      whatsapp: '5535997435840',
      email: 'contato@jhsimobiliaria.com.br'
    }
  },
  {
    id: 'prop-9',
    code: 'JHS-109',
    title: 'Apartamento Studio Moderno Mobiliado próximo à UNIFEI',
    slug: 'apartamento-studio-mobiliado-unifei-itajuba',
    type: 'apartamento',
    purpose: 'locacao',
    price: 1750,
    condoFee: 260,
    iptu: 75,
    city: 'Itajubá',
    state: 'MG',
    neighborhood: 'Borda da Mata',
    address: 'Av. BPS, próximo ao portão principal UNIFEI',
    zipCode: '37500-903',
    bedrooms: 1,
    suites: 0,
    bathrooms: 1,
    garages: 1,
    totalArea: 42,
    builtArea: 40,
    description: 'Studio conceito aberto totalmente decorado e mobiliado para locação ágil. Perfeito para estudantes, pesquisadores e docentes da UNIFEI. Inclui cama box de casal, bancada de estudos com cadeira ergonômica, guarda-roupa espelhado, cozinha compacta com frigobar, micro-ondas e cooktop elétrico. Condomínio com lavanderia compartilhada OMO, coworking e bicicletário.',
    features: [
      'Totalmente Mobiliado e Equipado',
      'Ao Lado do Campus da UNIFEI',
      'Lavanderia Compartilhada OMO',
      'Espaço Coworking com Wi-Fi High Speed',
      'Bicicletário e Vaga de Garagem',
      'Elevador e Fechadura Digital'
    ],
    images: [
      createArchitecturalImage('Studio Integrado Conceito Aberto', 'Apartamento Studio', 'luxury_apt'),
      createArchitecturalImage('Bancada de Estudos & Coworking', 'Ambiente de Trabalho', 'suite'),
      createArchitecturalImage('Cozinha Compacta Planejada', 'Cozinha', 'kitchen'),
      createArchitecturalImage('Banheiro com Blindex & Ducha', 'Banheiro', 'bedroom')
    ],
    badge: 'oportunidade',
    status: 'disponivel',
    isFeatured: false,
    createdAt: '2026-03-16',
    agent: {
      name: 'Locações Estudantis JHS',
      creci: 'CRECI-MG 24.891',
      phone: '(35) 99743-5840',
      whatsapp: '5535997435840',
      email: 'locacao@jhsimobiliaria.com.br'
    }
  },
  {
    id: 'prop-10',
    code: 'JHS-110',
    title: 'Galpão Industrial e Logístico com Pátio para Manobras',
    slug: 'galpao-industrial-logistico-distrito-itajuba',
    type: 'galpao',
    purpose: 'locacao',
    price: 16500,
    condoFee: 0,
    iptu: 1800,
    city: 'Itajubá',
    state: 'MG',
    neighborhood: 'Distrito Industrial',
    address: 'Rodovia BR-459, Km 162',
    zipCode: '37504-000',
    bedrooms: 0,
    suites: 0,
    bathrooms: 6,
    garages: 15,
    totalArea: 2800,
    builtArea: 1400,
    description: 'Estrutura logística e industrial de primeira linha às margens da BR-459 com ligação rápida para Pouso Alegre, São Paulo e Rio de Janeiro. Pé-direito livre de 9 metros, piso industrial de alta resistência com capacidade de 6 ton/m² polido com laser. Duas docas elevadas para carga e descarga, portão para carretas, mezanino administrativo com 4 salas de escritório climatizadas, vestiários masculinos e femininos e refeitório.',
    features: [
      'Pé-direito Livre de 9 Metros',
      'Piso com Carga de 6 Toneladas/m²',
      '2 Docas para Carretas e Caminhões',
      'Mezanino Administrativo com Salas',
      'Vestiários e Refeitório Completo',
      'Pátio com 1.400m² para Estacionamento e Manobras',
      'Transformador Dedicado de Alta Capacidade'
    ],
    images: [
      createArchitecturalImage('Pátio & Fachada Logística', 'Galpão Industrial', 'commercial'),
      createArchitecturalImage('Área Fabril Livre com Pé-direito 9m', 'Interior Galpão', 'terreno'),
      createArchitecturalImage('Docas de Carga e Descarga', 'Docas Logísticas', 'commercial'),
      createArchitecturalImage('Mezanino Administrativo com Escritórios', 'Escritórios', 'suite')
    ],
    badge: 'nenhum',
    status: 'disponivel',
    isFeatured: false,
    createdAt: '2026-03-02',
    agent: {
      name: 'JHS Corporativo & Industrial',
      creci: 'CRECI-MG 24.891',
      phone: '(35) 99743-5840',
      whatsapp: '5535997435840',
      email: 'corporativo@jhsimobiliaria.com.br'
    }
  },
  {
    id: 'prop-11',
    code: 'JHS-111',
    title: 'Casa Espaçosa com Quintal Verde e Pomar no Bairro Santo Antônio',
    slug: 'casa-espacosa-quintal-santo-antonio-itajuba',
    type: 'casa',
    purpose: 'locacao',
    price: 3600,
    condoFee: 0,
    iptu: 280,
    city: 'Itajubá',
    state: 'MG',
    neighborhood: 'Santo Antônio',
    address: 'Rua Dr. Américo de Oliveira, 245',
    zipCode: '37503-010',
    bedrooms: 4,
    suites: 2,
    bathrooms: 3,
    garages: 3,
    totalArea: 400,
    builtArea: 240,
    description: 'Ampla residência tradicional em rua estritamente residencial e arborizada. Excelente para famílias que valorizam espaço livre e conforto. Ampla sala de estar com lareira para as noites frias de Minas, copa com cozinha planejada, varanda aos fundos com quintal gramado e árvores frutíferas como jabuticabeira e limoeiro. Garagem espaçosa para 3 veículos.',
    features: [
      'Sala com Lareira Aconchegante',
      'Quintal Verde com Jabuticabeira',
      '4 Quartos sendo 2 Suítes',
      'Portão Eletrônico com Interfone',
      'Varanda Ampla de Convivência',
      'Copa Cozinha com Armários'
    ],
    images: [
      createArchitecturalImage('Residência Tradicional com Varanda', 'Casa para Locação', 'modern_house'),
      createArchitecturalImage('Quintal Verde com Pomar', 'Quintal Gramado', 'chacara'),
      createArchitecturalImage('Sala de Estar com Lareira', 'Living Lareira', 'luxury_apt'),
      createArchitecturalImage('Cozinha Copa Espaçosa', 'Copa Cozinha', 'kitchen')
    ],
    badge: 'nenhum',
    status: 'disponivel',
    isFeatured: false,
    createdAt: '2026-03-15',
    agent: {
      name: 'Locações JHS',
      creci: 'CRECI-MG 24.891',
      phone: '(35) 99743-5840',
      whatsapp: '5535997435840',
      email: 'locacao@jhsimobiliaria.com.br'
    }
  },
  {
    id: 'prop-12',
    code: 'JHS-112',
    title: 'Sítio Produtivo com Cafezal e Água de Mina em Delfim Moreira',
    slug: 'sitio-produtivo-cafezal-delfim-moreira',
    type: 'chacara',
    purpose: 'venda',
    price: 1650000,
    condoFee: 0,
    iptu: 420,
    city: 'Delfim Moreira',
    state: 'MG',
    neighborhood: 'Serra da Mantiqueira',
    address: 'Estrada Real dos Tropeiros, Km 18',
    zipCode: '37514-000',
    bedrooms: 3,
    suites: 1,
    bathrooms: 3,
    garages: 4,
    totalArea: 48000, // quase 2 alqueires
    builtArea: 280,
    description: 'Propriedade rural de alto valor agronômico e turístico a 1.400 metros de altitude na Serra da Mantiqueira. Produção ativa de café especial com selo de origem, mata nativa preservada com cachoeira particular dentro da propriedade e duas nascentes de água mineral. Casa sede colonial restaurada com fogão a lenha de cobre, varandão panorâmico, terreiro de café concretado e tulha.',
    features: [
      'Cachoeira Particular e 2 Nascentes',
      'Cafezal Ativo de Café Especial',
      'Altitude 1.400m - Clima Serrano Nobre',
      'Sede Colonial Restaurada',
      'Terreiro de Secagem de Café e Tulha',
      'Documentação 100% Regularizada no CAR',
      'Fácil Acesso por Estrada Cascalhada'
    ],
    images: [
      createArchitecturalImage('Sede na Serra & Cafezal Produtivo', 'Sítio Mantiqueira', 'chacara'),
      createArchitecturalImage('Cachoeira & Água de Mina', 'Cachoeira Natural', 'pool'),
      createArchitecturalImage('Sede Colonial com Fogão a Lenha', 'Sede Histórica', 'kitchen'),
      createArchitecturalImage('Vista das Montanhas de Minas', 'Altitude 1400m', 'terreno')
    ],
    badge: 'destaque',
    status: 'disponivel',
    isFeatured: true,
    createdAt: '2026-03-01',
    agent: {
      name: 'Equipe de Vendas JHS',
      creci: 'CRECI-MG 24.891',
      phone: '(35) 99743-5840',
      whatsapp: '5535997435840',
      email: 'contato@jhsimobiliaria.com.br'
    }
  }
];

export const CITIES_LIST = [
  'Itajubá',
  'Piranguinho',
  'Delfim Moreira',
  'Maria da Fé',
  'Wenceslau Braz',
  'Brasópolis',
  'Pouso Alegre'
];

export const NEIGHBORHOODS_LIST = [
  'Morro Chic',
  'Centro',
  'São Vicente',
  'Varginha',
  'Pinheirinho',
  'Borda da Mata',
  'Santo Antônio',
  'Medicina',
  'Santa Rosa',
  'Distrito Industrial',
  'Zona Rural'
];

export const PROPERTY_TYPES_LABELS: Record<string, string> = {
  casa: 'Casa',
  apartamento: 'Apartamento',
  terreno: 'Terreno / Lote',
  chacara: 'Chácara / Sítio',
  comercial: 'Comercial / Sala',
  cobertura: 'Cobertura',
  galpao: 'Galpão Industrial'
};

export const COMMON_FEATURES_LIST = [
  'Piscina',
  'Espaço Gourmet',
  'Churrasqueira',
  'Portaria 24 horas',
  'Elevador',
  'Aceita Pet',
  'Ar-condicionado',
  'Móveis Planejados',
  'Jardim / Quintal',
  'Varanda / Sacada',
  'Energia Solar',
  'Academia'
];
